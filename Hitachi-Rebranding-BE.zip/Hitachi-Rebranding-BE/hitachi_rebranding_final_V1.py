# rebranding_pipeline.py  
from __future__ import annotations  
  
import io  
import logging  
import math  
import os  
import sys  
import warnings  
import zipfile  
import tempfile  
import uuid  
import inspect  
import pathlib  
import re  
import datetime  
from pathlib import Path  
from typing import Dict, List, Tuple, Set, Optional  
logging.disable(logging.CRITICAL) 
# ─────────────────────────────  AZURE (optional)  ────────────────────────────  
try:  
    from azure.storage.blob import BlobServiceClient  # type: ignore  
except ImportError:  
    BlobServiceClient = None   
  
  
try:  
    from azure.storage.blob import ContentSettings  # type: ignore  
except Exception:  
    ContentSettings = None  # type: ignore  
  
 
INPUT_DIR = "input_branding2"  
OUTPUT_DIR = "output_branding2"  
  
###### Azure Blob I/O ########
USE_AZURE_BLOB: bool = True   
AZURE_STORAGE_CONNECTION_STRING = os.getenv(  
    "AZURE_STORAGE_CONNECTION_STRING",  
    "DefaultEndpointsProtocol=https;AccountName=saaicoepoc011;AccountKey=W+P65IDd03XhMnpZqQ7LMwnGdOfTjgLkIHyh7mdX1AyhY+bZe4ZklFoRtLFFW+Y+SeOn6SFZ3xKH+ASt3tupsg==;EndpointSuffix=core.windows.net",  
)  
AZURE_CONTAINER_INPUT = os.getenv("AZURE_CONTAINER_INPUT", "rebranding-input")  
AZURE_CONTAINER_OUTPUT = os.getenv("AZURE_CONTAINER_OUTPUT", "rebranding-output")  
KEEP_LOCAL_COPY = True    
  
# ─────────────────────────── LOGGING ─────────────────────────────────────────  
logging.basicConfig(  
    level=logging.INFO,  
    format="%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s",  
    handlers=[  
        logging.StreamHandler(sys.stdout),  
        logging.FileHandler("/tmp/hitachi_rebranding.log", mode="a")  
        if os.path.exists("/tmp")  
        else logging.StreamHandler(sys.stdout),  
    ],  
)  
logger = logging.getLogger(__name__)  
  
# Add environment detection  
IS_AZURE = os.getenv("WEBSITE_SITE_NAME") is not None  
IS_LOCAL = not IS_AZURE  
logger.info(f"🚀 APPLICATION STARTUP - Environment: {'Azure WebApp' if IS_AZURE else 'Local'}")  
logger.info(f"📍 Current working directory: {os.getcwd()}")  
logger.info(f"📁 Python executable: {sys.executable}")  
logger.info(f"🔧 Python path: {sys.path}")  
  
warnings.filterwarnings("ignore", category=UserWarning)  
os.environ["TOKENIZERS_PARALLELISM"] = "false"  
  
# ─────────────────────────── CORE DEPENDENCIES ───────────────────────────────  
try:  
    import cv2  
    import fitz  # PyMuPDF  
    import numpy as np  
    import requests  
    from PIL import Image  
    import pytesseract  
    from pytesseract import Output  
    logger.info("✅ Core dependencies imported successfully")  
except ImportError as e:  
    logger.error(f"❌ Failed to import core dependencies: {e}")  
    raise  
  
####### HuggingFace Hub (optional)  
# try:  
#     import huggingface_hub as _hf  
#     if not hasattr(_hf, "cached_download"):  
#         from huggingface_hub import hf_hub_download  
#         _hf.cached_download = hf_hub_download  
#     logger.info("✅ HuggingFace Hub imported")  
# except ImportError:  
#     logger.warning("⚠️ HuggingFace Hub not available")  
#     pass  
  
############################## AZURE GPT-Image-1 ##############################  
AZURE_OPENAI_KEY = os.getenv(  
    "AZURE_OPENAI_KEY",  
    "DYHNOW22gxruqjtpiFCpec1ftaJKb96Tvex2ue26gnVrwBNlvKwQJQQJ99BEACMsfrFXJ3w3AAAAACOG1QC8",  
)  
AZURE_OPENAI_ENDPOINT = "https://ramku-mb6ic4fp-westus3.cognitiveservices.azure.com"  
AZURE_OPENAI_DEPLOYMENT = "gpt-image-1"  
AZURE_OPENAI_API_VERSION = "2025-04-01-preview"  
INPAINT_PROMPT = (  
    "Fill the masked area so it blends seamlessly with the surrounding page. "  
    "Match colours, shading and texture. "  
    "Do not introduce any additional elements."  
)  
INPAINT_PROMPT1 = (  
    "Fill the masked area so it blends seamlessly/perfectly with the surrounding page without any border/patch lines around the area. "  
    "Match exact surrounding background colours, pattern, shading and texture making it perfectly indinstiguishable with respect to the background of the page irrespective of the complexity. "  
    "Do not introduce any additional elements. There should not be any wiped/blurr/halo effect/texture"  
)  
INPAINT_PROMPT3 = (  
    "Reconstruct ONLY the pixels inside the mask so the area is completely "  
    "indistinguishable from the immediately surrounding background. "  
    "Seamlessly continue the exact colours, lighting, grain, perspective and "  
    "texture (grass hillside / natural landscape) that are already present. "  
    "Remove every trace of the previous logo. "  
    "Do NOT introduce or write any text, shapes, watermarks, objects or new "  
    "details. Do NOT soften, blur, smudge or stylise the image. "  
    "Keep neighbouring pixels untouched and avoid visible seams, borders, "  
    "banding, tiling or repeating patterns. The result must look like the "  
    "original photograph with nothing ever placed there."  
)  
NEGATIVE_PROMPT = (  
    "text, letters, logos, symbols, pattern repetition, blurring, smearing, "  
    "halo, colour bands, low-resolution artefacts, watermark, patch border"  
)  
HTTP_TIMEOUT = 120  
ENABLE_AZURE_GPT_INPAINT = bool(AZURE_OPENAI_KEY)  
logger.info(f"🔑 Azure OpenAI Key configured: {bool(AZURE_OPENAI_KEY)}")  
  
############################## Stable-Diffusion Loader ########################  
_SD_PIPE = None  
try:  
    import torch  
    from diffusers import StableDiffusionInpaintPipeline  
    _SD_DEVICE = "cuda" if torch.cuda.is_available() else "cpu"  
    _DTYPE = torch.float16 if _SD_DEVICE == "cuda" else torch.float32  
    logger.info("Loading SD-Inpaint …")  
    _SD_PIPE = StableDiffusionInpaintPipeline.from_pretrained(  
        "runwayml/stable-diffusion-inpainting",  
        torch_dtype=_DTYPE,  
        safety_checker=None,  
        local_files_only=False,  
    ).to(_SD_DEVICE)  
    _SD_PIPE.enable_attention_slicing()  
    logger.info(f"✓  SD-Inpaint ready on {_SD_DEVICE}")  
except Exception as e:  
    logger.warning(f"Stable-Diffusion NOT available – fallback chain continues. ({e})")  
    _SD_PIPE = None  
  
############################## LaMa loader ###################################  
_LAMA_MODEL = None  
_LAMA_CFG_OBJ = None  
try:  
    from lama_cleaner.model_manager import ModelManager  
    from lama_cleaner.schema import Config as LamaConfig  
    _LAMA_MODEL = ModelManager(  
        name="lama",  
        device="cuda" if cv2.cuda.getCudaEnabledDeviceCount() else "cpu",  
        model_path="/home/site/wwwroot/big-lama.pt",  

    )  
    _LAMA_CFG_OBJ = LamaConfig(  
        ldm_steps=25,  
        hd_strategy="Crop",  
        hd_strategy_crop_margin=32,  
        hd_strategy_crop_trigger_size=800,  
        hd_strategy_resize_limit=2000,  
        prompt=INPAINT_PROMPT1,  
    )  
    logger.info(f"✓  LaMa ready on {_LAMA_MODEL.device}")  
except Exception as e:  
    logger.warning(f"LaMa NOT available – fallback to OpenCV. ({e})")  
    _LAMA_MODEL = None  
  
############################## Google GenAI (optional) ########################  
try:  
    from google import genai  
    from google.oauth2 import service_account  
    from google.genai.types import (  
        Image as VertexImage,  
        EditImageConfig,  
        RawReferenceImage,  
        MaskReferenceConfig,  
        MaskReferenceImage,  
    )  
    logger.info("✅ Google GenAI imported")  
except Exception:  
    logger.warning("⚠️ Google GenAI not available")  
    genai = None  
  
############################## DOCX Libraries ################################  
try:  
    import docx  
    from docx import Document  
    from docx.shared import Pt, Inches  
    from docx.oxml import OxmlElement  
    from docx.oxml.ns import qn, nsmap  
    from docx.enum.style import WD_STYLE_TYPE  
    from docx.opc.constants import RELATIONSHIP_TYPE as RT  
    logger.info("✅ DOCX libraries imported")  
except ImportError:  
    logger.warning("⚠️ DOCX libraries not available")  
    docx = None  
  
############################## Font tools ####################################  
try:  
    from fontTools.ttLib import TTFont  
    from lxml import etree  
    logger.info("✅ Font tools imported")  
except ImportError:  
    logger.warning("⚠️ Font tools not available")  
    TTFont = None  
    etree = None  # type: ignore  
  
############################## User Settings/CONFIGURATION ####################  
DEBUG = True  
  
####### Step 1 Configuration (Pattern Detection)  ######
REF_ANGLE = 45.0  
ANGLE_TOLERANCE = 8.0  
MIN_STRIPE_LENGTH = 20.0  
MIN_TOTAL_LEN = 120.0  
MIN_STRIPES_IN_CLUSTER = 3  
MAX_HV_RATIO = 0.4  
RED_MIN_R, RED_MAX_G, RED_MAX_B = 0.60, 0.35, 0.35  
  
####### Step 2 Configuration (Logo Detection & Replacement)  ######
AZURE_VISION_KEY = "2Is5XLYBpspoD24Fbw2si6FfpM2buW1Tki7kwGNMrYYiWm8BE01tJQQJ99BEACYeBjFXJ3w3AAAFACOGZjh2"  
AZURE_VISION_ENDPOINT = "https://cv-hitachi-rebranding.cognitiveservices.azure.com/"  
logger.info(f"🔑 Azure Vision Key configured: {bool(AZURE_VISION_KEY)}")  
  
#######Tesseract configuration  ######
try:  
    if os.name == "nt":  
        possible_paths = [  
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",  
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe", 
            r"C:\Tools\tesseract\tesseract.exe",  
        ]  
        for path in possible_paths:  
            if os.path.exists(path):  
                pytesseract.pytesseract.tesseract_cmd = path  
                logger.info(f"✅ Tesseract found at: {path}")  
                break  
    ENABLE_TESSERACT = True  
    logger.info("✅ Tesseract OCR enabled")  
except Exception as e:  
    logger.warning(f"⚠️ Tesseract OCR not available: {e}")  
    ENABLE_TESSERACT = False  
  
ENABLE_TESSERACT = True  
TESS_MIN_CONF = 50  
SKIP_NEW_HITACHI = True  
  
####### Replacement logos  ######
REPLACEMENT_LOGOS: Dict[str, str] = {  
    "hitachi_inspire": "Hitachi_Inspire1.png",  
    "hitachi_energy": "Transparent_logo1.png",  
}  
  
logger.info("🔍 REPLACEMENT LOGO CONFIGURATION:")  
for key, filename in REPLACEMENT_LOGOS.items():  
    logger.info(f"  {key}: {filename}")  
    possible_paths = [  
        Path(filename),  
        Path.cwd() / filename,  
        Path(__file__).resolve().parent / filename if "__file__" in globals() else None,  
        Path("/home/site/wwwroot") / filename,  
    ]  
    found = False  
    for path in possible_paths:  
        if path and path.exists():  
            logger.info(f"    ✅ Found at: {path}")  
            found = True  
            break  
    if not found:  
        logger.error("    ❌ NOT FOUND - Searched:")  
        for path in possible_paths:  
            if path:  
                logger.error(f"      - {path}")  
  
TEMPLATE_DIR = "templates"  
USE_TEMPLATE_DET = True  
DETECTION_BACKEND = "azure"  
  
####### Logo detection constants  ######
LOGO_CONF_THRESHOLD = 0.50  
MIN_DIM, MAX_DIM = 50, 16_000  
MIN_LOGO_HEIGHT_PX = 45  
HEADER_FOOTER_PCT = 0.22  
FOOTER_OCR_PCT = 0.25  
MIN_HITACHI_WIDTH_RATIO = 3.2  
IOU_DUP_THRESHOLD = 0.67  
  
MIN_RED_RATIO = 0.003  
MIN_LEFT_RED_RATIO = 0.015  
MIN_SYMBOL_AREA_PX = 180  
MIN_SYMBOL_AREA_RATIO = 0.05  
MIN_SYMBOL_ASPECT = 0.50  
MAX_SYMBOL_ASPECT = 1.60  
  
EDGE_RING_PCT = 0.20  
MAX_EDGE_DENSITY = 0.06  
MIN_SOLO_INK_RATIO = 0.001  
MAX_SOLO_INK_RATIO = 0.08  
  
PAD_PCT, MAX_PAD_PX = 0.12, 12  
DILATE_PCT, MAX_DILATE_PX = 0.18, 15  
INPAINT_PCT, MAX_INPAINT_RADIUS = 0.07, 7  
SCALE_COVERAGE = 1.01  
SEAMLESS_CLONE_TRIES = (cv2.MIXED_CLONE, cv2.NORMAL_CLONE)  
KEYWORDS_HITACHI = ("hitachi", "inspire", "next", "energy")  
  
TEMPLATE_THRESHOLDS = {  
    "hitachi inspire the next": 0.63,  
    "hitachi energy": 0.50,  
}  
  
####### Typography settings  ######
ENABLE_PDF_FONT_REBRAND = True  
ENABLE_DOCX_FONT_REBRAND = True  
HITACHI_SANS_TTF = "HitachiSans.ttf"  
VERDANA_TTF = "Verdana.ttf"  
FONT_FACTOR_PDF = 1.02  
FONT_FACTOR_DOCX = 1.00  
  
####### Font rebranding settings  ######
FONT_FILE = pathlib.Path("HitachiSans.ttf")  
SHRINK_PT = 3  
SIZE_DELTA = -SHRINK_PT if SHRINK_PT else 0  
REMOVE_STRATEGY = os.getenv("REMOVE_STRATEGY", "redact")  
  
####### DOCX settings  ######
DOCX_BITMAP_EXTS: set[str] = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}  
DOCX_VECTOR_EXTS: set[str] = {".svg", ".emf", ".wmf"}  
DOCX_FORCE_DELETE_ENERGY = True  
DELETE_STYLE = "transparent"  
  
####### Force black color for all Hitachi Inspire logos######  
FORCE_BLACK_INSPIRE_LOGOS = True  
  
####### Add logo to DOCX cover pages  ######
ADD_COVER_LOGO_DOCX = False  
COVER_LOGO_SIZE = (120, 40)  
COVER_LOGO_MARGIN_RIGHT = 20  
COVER_LOGO_MARGIN_TOP = 20  
  
####### Font rebranding constants for DOCX  ######
TARGET_NAME = "Verdana"  
REDUCE_THRESHOLD_PT = 29.0  
REDUCE_BY_PT_LARGE = 2.0  
REDUCE_BY_PT_SMALL = 2.5  
MIN_SIZE_THRESHOLD_PT = 7.1  
  
PRESERVE_BULLET_FONTS = {  
    "Symbol", "Wingdings", "Wingdings 2", "Wingdings 3",  
    "Webdings", "MS Gothic", "Arial Unicode MS", "OpenSymbol"  
}  
UNICODE_BULLETS = {  
    "•", "◦", "▪", "▫", "►", "‣", "⁃", "∙", "⚫", "⚪", "✓", "✗",  
    "■", "◼", "◾", "⬧"  
}  
  
####### Namespaces  ######
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"  
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"  
CT = "http://schemas.openxmlformats.org/package/2006/content-types"  
NS = {"w": W}  
  
 
REDACT_LINE_ART_OPTION = getattr(  
    fitz,  
    "PDF_REDACT_LINE_ART_REMOVE_IF_COVERED",  
    getattr(fitz, "PDF_REDACT_REMOVE_GRAPHICS_IF_COVERED", 0),  
)  
  
if not hasattr(fitz.Page, "cluster_drawings"):  
    from typing import List as _List  
  
    def _cluster_drawings(self, gap: float = 2.0) -> _List["fitz.Rect"]:  
        drawings = self.get_drawings()  
        clusters: _List[fitz.Rect] = []  
        for d in drawings:  
            rect = d.get("rect")  
            if rect is None or rect.is_empty:  
                continue  
            r = fitz.Rect(rect.x0 - gap, rect.y0 - gap, rect.x1 + gap, rect.y1 + gap)  
            merged = False  
            for i, c in enumerate(clusters):  
                if r.intersects(c):  
                    clusters[i] = c | rect  
                    merged = True  
                    break  
            if not merged:  
                clusters.append(fitz.Rect(rect))  
        return clusters  
  
    fitz.Page.cluster_drawings = _cluster_drawings  # type: ignore  
    logger.info("✅ Added cluster_drawings shim for PyMuPDF")  
else:  
    _cluster_drawings = fitz.Page.cluster_drawings  # type: ignore  
    logger.info("✅ Using native cluster_drawings from PyMuPDF")  
  
# ────────────────────────── COVER-IMAGE HELPERS ──────────────────────────────  
def cover_image_bbox_pdf(page) -> Optional["fitz.Rect"]:  
    logger.info(f"🔍 Searching for cover image on page {page.number}")  
    imgs = page.get_images(full=True)  
    if not imgs:  
        logger.info("📷 No images found on page")  
        return None  
  
    page_area = page.rect.width * page.rect.height  
    best_bbox, best_area = None, 0  
    logger.info(f"📊 Page area: {page_area}, Found {len(imgs)} images")  
  
    for i, (xref, *_) in enumerate(imgs):  
        try:  
            rects = page.get_image_rects(xref)  
        except Exception as e:  
            logger.warning(f"⚠️ Could not get rects for image {i}: {e}")  
            continue  
        if not rects:  
            continue  
        bbox = rects[0]  
        area = bbox.width * bbox.height  
        area_ratio = area / page_area  
        width_ratio = bbox.width / page.rect.width  
        height_ratio = bbox.height / page.rect.height  
        logger.info(  
            f"📷 Image {i}: area_ratio={area_ratio:.3f}, width_ratio={width_ratio:.3f}, height_ratio={height_ratio:.3f}"  
        )  
        if (area_ratio >= 0.80 or width_ratio >= 0.90 or height_ratio >= 0.90):  
            if area > best_area:  
                logger.info(f"✅ Found better cover image candidate: area={area}")  
                best_bbox, best_area = bbox, area  
  
    if best_bbox:  
        logger.info(f"✅ Selected cover image bbox: {best_bbox}")  
    else:  
        logger.warning("⚠️ No suitable cover image found")  
  
    return best_bbox  
  
  
def _is_good_rect(r) -> bool:  
    return r is not None and r.width > 0 and r.height > 0  
  
  
def _overlap_pct(a: "fitz.Rect", b: "fitz.Rect") -> float:  
    inter = a & b  
    return 0.0 if inter.is_empty else abs(inter) / abs(a) * 100.0  
  
  
def _norm_rgb(c) -> Tuple[float, float, float]:  
    if c is None:  
        return (0.0, 0.0, 0.0)  
    if isinstance(c, (list, tuple)):  
        if len(c) >= 3:  
            try:  
                return (float(c[0]), float(c[1]), float(c[2]))  
            except Exception:  
                pass  
    return (0.0, 0.0, 0.0)  
  
  
def _stroke_fill_colors(d):  
    if d.get("colors"):  
        stroke, fill = d["colors"]  
        return _norm_rgb(stroke), _norm_rgb(fill)  
    stroke = d.get("stroke")  
    fill = d.get("fill")  
    return _norm_rgb(stroke), _norm_rgb(fill)  
  
  
def _is_red_stripe_color(rgb: tuple) -> bool:  
    try:  
        r, g, b = rgb  
        if r >= 0.6 and g <= 0.35 and b <= 0.35:  
            return True  
        if r >= 0.5 and r > 1.5 * max(g, b, 0.05):  
            return True  
        return False  
    except Exception:  
        return False  
  
  
def _is_red_stripe_color_loose(rgb: tuple) -> bool:  
    try:  
        r, g, b = rgb  
        if r >= 0.4 and r > g and r > b and r > 1.2 * max(g, b, 0.05):  
            return True  
        return False  
    except Exception:  
        return False  
  
  
def _is_definitely_white(rgb: tuple) -> bool:  
    try:  
        r, g, b = rgb  
        return r >= 0.95 and g >= 0.95 and b >= 0.95  
    except Exception:  
        return True  
  
  
def _xo_info(page: "fitz.Page", raw):  
    if isinstance(raw, dict):  
        return (  
            int(raw.get("xref")),  
            str(raw.get("name")),  
            raw.get("bbox"),  
            raw.get("subtype"),  
        )  
    xref = int(raw[0])  
    doc = page.parent  
    try:  
        obj = doc.xref_object(xref, compressed=False) or b""  
    except Exception:  
        obj = b""  
    if isinstance(obj, str):  
        obj = obj.encode("latin1", "ignore")  
    g = re.search(rb"/Name\s*/([A-Za-z0-9]+)", obj)  
    name = g.group(1).decode() if g else f"XO{xref}"  
    g = re.search(rb"/Subtype\s*/([A-Za-z0-9]+)", obj)  
    subtype = "/" + g.group(1).decode() if g else None  
    bbox = None  
    g = re.search(rb"/BBox\s*$([^$]+)\]", obj)  
    if g:  
        nums = [float(v) for v in g.group(1).split()]  
        bbox = fitz.Rect(nums) if len(nums) == 4 else None  
    return xref, name, bbox, subtype  
  
  
def _del_resource(page: "fitz.Page", name: str):  
    doc = page.parent  
    try:  
        doc.xref_set_key(page.xref, f"Resources/XObject/{name}", "null")  
    except Exception:  
        pass  
    for c_x in page.get_contents():  
        data = doc.xref_stream(c_x) or b""  
        out = [  
            ln  
            for ln in data.splitlines()  
            if (f"/{name} Do".encode() not in ln) and (f"/{name} sh".encode() not in ln)  
        ]  
        if len(out) != len(data.splitlines()):  
            doc.update_stream(c_x, b"\n".join(out))  
  
  
def _clean_form_shadings(doc: "fitz.Document", xref: int):  
    for key in ("Resources/Pattern", "Resources/Shading"):  
        try:  
            doc.xref_set_key(xref, key, "null")  
        except Exception:  
            pass  
    try:  
        src = doc.xref_stream(xref) or b""  
    except Exception:  
        return  
    dst = b"\n".join(ln for ln in src.splitlines() if b" sh" not in ln)  
    if not dst.strip():  
        dst = b"q\nQ"  
    if dst != src:  
        doc.update_stream(xref, dst)  
  
  
def _scrub_forms(page: "fitz.Page"):  
    doc = page.parent  
    for xo in page.get_xobjects():  
        xref, _, __, st = _xo_info(page, xo)  
        if st == "/Form":  
            _clean_form_shadings(doc, xref)  
    try:  
        page.clean_contents()  
    except Exception:  
        pass  
  
  
def _collect_coloured_regions(page: "fitz.Page", white_thr: int = 245) -> List["fitz.Rect"]:  
    coloured: List["fitz.Rect"] = []  
    for d in page.get_drawings():  
        rect = d.get("rect")  
        if not rect or rect.is_empty:  
            continue  
        fill_opac = d.get("fill_opacity")  
        is_filled = (fill_opac or 0) > 0 or d.get("fill") is not None  
        if not is_filled:  
            continue  
        _, fill_rgb = _stroke_fill_colors(d)  
        if not _is_white(fill_rgb, white_thr):  
            coloured.append(rect)  
    return coloured  
  
  
def _is_white(rgb: Tuple[float, float, float], thr: int = 245) -> bool:  
    r, g, b = rgb  
    if max(r, g, b) <= 1.0:  
        r, g, b = r * 255.0, g * 255.0, b * 255.0  
    return (r >= thr) and (g >= thr) and (b >= thr)  
  
  
def _span_colour(span: dict) -> Tuple[int, int, int]:  
    if "color" in span and span["color"] is not None:  
        return _rgb_from_int(span["color"])  
    if "fill" in span and span["fill"] is not None:  
        return _rgb_from_int(span["fill"])  
    return (0, 0, 0)  
  
  
def _rgb_from_int(val: int) -> Tuple[int, int, int]:  
    return (val >> 16) & 255, (val >> 8) & 255, val & 255  
  
  
def _repaint_white_text_black(  
    page: "fitz.Page",  
    ref_rect: "fitz.Rect",  
    *,  
    white_thr: int = 245,  
):  
    doc_font = "helv"  
    coloured_regions = _collect_coloured_regions(page, white_thr)  
  
    def _inside_coloured(b: "fitz.Rect") -> bool:  
        return any(b.intersects(c) for c in coloured_regions)  
  
    for block in page.get_text("dict")["blocks"]:  
        if block["type"] != 0:  
            continue  
        for line in block["lines"]:  
            for sp in line["spans"]:  
                bbox = fitz.Rect(sp["bbox"])  
                if not bbox.intersects(ref_rect):  
                    continue  
                if _inside_coloured(bbox):  
                    continue  
                col_rgb = _span_colour(sp)  
                if not _is_white(col_rgb, white_thr):  
                    continue  
                x0, y1 = bbox.x0, bbox.y1  
                try:  
                    page.insert_text(  
                        fitz.Point(x0, y1),  
                        sp["text"],  
                        fontsize=sp["size"],  
                        fontname=sp.get("font", doc_font),  
                        color=(0, 0, 0),  
                        overlay=True,  
                    )  
                except Exception:  
                    page.insert_text(  
                        fitz.Point(x0, y1),  
                        sp["text"],  
                        fontsize=sp["size"],  
                        fontname=doc_font,  
                        color=(0, 0, 0),  
                        overlay=True,  
                    )  
  
  
def _purge_overlaps(page: "fitz.Page", ref_rect: "fitz.Rect", thr: float = 90.0):  
    if page.number > 1:  
        return  
    redaction_added = False  
    for xo in page.get_xobjects():  
        _, name, bbox, stype = _xo_info(page, xo)  
        if bbox and _is_good_rect(bbox):  
            if _overlap_pct(bbox, ref_rect) >= thr:  
                _del_resource(page, name)  
            continue  
        if stype == "/Pattern":  
            _del_resource(page, name)  
            page.add_redact_annot(ref_rect, fill=(1, 1, 1))  
            redaction_added = True  
    for drawing in page.get_drawings():  
        rect = drawing.get("rect")  
        if not _is_good_rect(rect):  
            continue  
        overlap = _overlap_pct(rect, ref_rect)  
        if overlap < thr:  
            continue  
        stroke_color, fill_color = _stroke_fill_colors(drawing)  
        is_red_element = (_is_red_stripe_color(stroke_color) or _is_red_stripe_color(fill_color))  
        if is_red_element:  
            page.add_redact_annot(rect, fill=(1, 1, 1))  
            redaction_added = True  
            continue  
        if overlap >= 60.0 and _has_diagonal_stripe_geometry(drawing):  
            if not (_is_definitely_white(stroke_color) and _is_definitely_white(fill_color)):  
                page.add_redact_annot(rect, fill=(1, 1, 1))  
                redaction_added = True  
    for drawing in page.get_drawings():  
        rect = drawing.get("rect")  
        if not _is_good_rect(rect):  
            continue  
        area = rect.width * rect.height  
        if area > 200 or not rect.intersects(ref_rect):  
            continue  
        stroke_color, fill_color = _stroke_fill_colors(drawing)  
        if (_is_red_stripe_color_loose(stroke_color) or _is_red_stripe_color_loose(fill_color)):  
            page.add_redact_annot(rect, fill=(1, 1, 1))  
            redaction_added = True  
    if redaction_added:  
        try:  
            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)  
        except Exception:  
            pass  
    try:  
        page.clean_contents()  
    except Exception:  
        pass  
  
  
def _has_diagonal_stripe_geometry(drawing: dict) -> bool:  
    try:  
        rect = drawing.get("rect")  
        if not rect:  
            return False  
        aspect_ratio = max(rect.width, rect.height) / max(min(rect.width, rect.height), 0.1)  
        if aspect_ratio < 1.5:  
            return False  
        area = rect.width * rect.height  
        if area < 50 or area > 2000:  
            return False  
        items = drawing.get("items", [])  
        for item in items:  
            if len(item) >= 3 and item[0] == "l":  
                try:  
                    p1, p2 = item[1], item[2]  
                    if hasattr(p1, "x") and hasattr(p2, "x"):  
                        dx, dy = p2.x - p1.x, p2.y - p1.y  
                        if abs(dx) > 0 and abs(dy) > 0:  
                            angle = abs(math.degrees(math.atan2(dy, dx)))  
                            angle = min(angle, 180 - angle)  
                            if 20 <= angle <= 70:  
                                return True  
                except Exception:  
                    continue  
        return False  
    except Exception:  
        return False  
  
  
def _seg_angle(p1, p2):  
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]  
    if dx == dy == 0:  
        return None  
    ang = abs(math.degrees(math.atan2(dy, dx)))  
    return ang if ang <= 90 else 180 - ang  
  
  
def _segments_from_drawing(d: dict):  
    segs, cur, tr = [], None, d.get("trans")  
  
    def _t(p):  
        if not tr:  
            return p  
        a, b, c, d_, e, f = tr  
        x, y = p  
        return (a * x + c * y + e, b * x + d_ * y + f)  
  
    for op, arg, *_ in d["items"]:  
        if op == "l":  
            nxt = _t(arg)  
            if cur:  
                segs.append((cur, nxt))  
            cur = nxt  
        elif op == "m":  
            cur = _t(arg)  
        elif op == "re":  
            x, y, w, h = arg  
            p0 = _t((x, y))  
            p1 = _t((x + w, y))  
            p2 = _t((x + w, y + h))  
            p3 = _t((x, y + h))  
            segs.extend([(p0, p1), (p1, p2), (p2, p3), (p3, p0)])  
            cur = None  
        elif op == "h":  
            cur = None  
    return segs  
  
  
def _color_is_red(rgb: Tuple[float, float, float]) -> bool:  
    try:  
        r, g, b = rgb  
    except Exception:  
        return False  
    return (r >= RED_MIN_R) and (g <= RED_MAX_G) and (b <= RED_MAX_B)  
  
  
def is_inspire_cluster(drawings: List[dict], verbose: bool = False) -> bool:  
    logger.info(f"🔍 Analyzing cluster with {len(drawings)} drawings for Inspire pattern")  
    diag_len = hv_len = 0.0  
    diag_cnt = hv_cnt = 0  
    for d in drawings:  
        stroke_clr, fill_clr = _stroke_fill_colors(d)  
        if not (_color_is_red(stroke_clr) or _color_is_red(fill_clr)):  
            continue  
        if d.get("do_stroke", False) and d.get("width", 0) < 0.4:  
            continue  
        for p1, p2 in _segments_from_drawing(d):  
            seg_len = math.hypot(p2[0] - p1[0], p2[1] - p1[1])  
            if seg_len < MIN_STRIPE_LENGTH:  
                continue  
            ang = _seg_angle(p1, p2)  
            if ang is None:  
                continue  
            if abs(ang - REF_ANGLE) <= ANGLE_TOLERANCE:  
                diag_cnt += 1  
                diag_len += seg_len  
            elif ang < 10 or ang > 80:  
                hv_cnt += 1  
                hv_len += seg_len  
    is_inspire = (  
        diag_cnt >= MIN_STRIPES_IN_CLUSTER  
        and diag_len >= MIN_TOTAL_LEN  
        and (not hv_len or (hv_len / diag_len) <= MAX_HV_RATIO)  
    )  
    logger.info(  
        f"📊 Inspire cluster analysis: diag_cnt={diag_cnt}, diag_len={diag_len:.1f}, hv_len={hv_len:.1f}, is_inspire={is_inspire}"  
    )  
    return is_inspire  
  
  
def fullpage_cover(page_shape: Tuple[int, int], tpl: np.ndarray) -> np.ndarray:  
    ph, pw = page_shape  
    return cv2.resize(  
        tpl,  
        (pw, ph),  
        interpolation=cv2.INTER_AREA if (pw < tpl.shape[1] or ph < tpl.shape[0]) else cv2.INTER_LINEAR,  
    )  
  
#######template-resize helper ###### 
def resize_template_exact(tpl: np.ndarray, tgt_w: int, tgt_h: int) -> np.ndarray:  
    logger.info(f"📏 Resizing template from {tpl.shape} to ({tgt_w}, {tgt_h})")  
    if tgt_w <= 0 or tgt_h <= 0:  
        raise ValueError("target size must be positive")  
    interp = (cv2.INTER_AREA if tgt_w < tpl.shape[1] or tgt_h < tpl.shape[0] else cv2.INTER_LINEAR)  
    result = cv2.resize(tpl, (tgt_w, tgt_h), interpolation=interp)  
    logger.info(f"✅ Template resized successfully to {result.shape}")  
    return result  
  
  
def replace_cover_images_with_template(  
    pdf_stream: io.BytesIO,  
    template_img: np.ndarray,  
    cover_pages: List[int],  
) -> io.BytesIO:  
    logger.info(f"🔄 Replacing cover images with template on pages: {cover_pages}")  
    doc = fitz.open(stream=pdf_stream, filetype="pdf")  
    for pno in cover_pages:  
        if pno >= len(doc):  
            logger.warning(f"⚠️ Page {pno} does not exist (doc has {len(doc)} pages)")  
            continue  
        page = doc[pno]  
        bbox = cover_image_bbox_pdf(page)  
        if bbox is None or bbox.is_empty:  
            logger.warning(f"⚠️ No cover image found on page {pno}")  
            continue  
        tw, th = int(bbox.width), int(bbox.height)  
        fitted = resize_template_exact(template_img, tw, th)  
        img_bytes = cv2.imencode(".png", fitted)[1].tobytes()  
        logger.info(f"🖼️ Inserting template image on page {pno} at bbox {bbox}")  
        page.insert_image(bbox, stream=img_bytes, overlay=True)  
    out = io.BytesIO()  
    doc.save(out, deflate=True)  
    doc.close()  
    out.seek(0)  
    logger.info("✅ Cover image replacement completed")  
    return out  
  
  
def _detect_red_diagonal_pattern(img: np.ndarray) -> bool:  
    logger.info(f"🔍 Detecting red diagonal pattern in image {img.shape if img is not None else 'None'}")  
    if img is None or img.size == 0:  
        logger.warning("⚠️ Empty or None image provided")  
        return False  
  
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  
    mask1 = cv2.inRange(hsv, (0, 70, 50), (10, 255, 255))  
    mask2 = cv2.inRange(hsv, (170, 70, 50), (180, 255, 255))  
    mask = cv2.bitwise_or(mask1, mask2)  
    red_pixels = cv2.countNonZero(mask)  
    logger.info(f"🔴 Red pixels found: {red_pixels}")  
  
    if red_pixels < 500:  
        logger.info("❌ Not enough red pixels for pattern detection")  
        return False  
  
    edges = cv2.Canny(mask, 50, 150)  
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=80, minLineLength=40, maxLineGap=10)  
    if lines is None:  
        logger.info("❌ No lines detected in red regions")  
        return False  
  
    diag_cnt = hv_cnt = 0  
    diag_len = hv_len = 0.0  
    for l in lines:  
        x1, y1, x2, y2 = l[0]  
        length = math.hypot(x2 - x1, y2 - y1)  
        if length < 30:  
            continue  
        ang = abs(math.degrees(math.atan2(y2 - y1, x2 - x1)))  
        ang = ang if ang <= 90 else 180 - ang  
        if abs(ang - REF_ANGLE) <= ANGLE_TOLERANCE:  
            diag_cnt += 1  
            diag_len += length  
        elif ang < 10 or ang > 80:  
            hv_cnt += 1  
            hv_len += length  
  
    has_pattern = (  
        diag_cnt >= MIN_STRIPES_IN_CLUSTER and  
        diag_len >= MIN_TOTAL_LEN and  
        (not hv_len or (hv_len / diag_len) <= MAX_HV_RATIO)  
    )  
    logger.info(  
        f"📊 Pattern detection result: diag_cnt={diag_cnt}, diag_len={diag_len:.1f}, hv_len={hv_len:.1f}, has_pattern={has_pattern}"  
    )  
    return has_pattern  
  
  
def _encode_img(img: np.ndarray, ext: str) -> bytes:  
    ext = ext.lower()  
    if ext in [".jpg", ".jpeg"]:  
        ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 90])  
    elif ext == ".bmp":  
        ok, buf = cv2.imencode(".bmp", img)  
    else:  
        ok, buf = cv2.imencode(".png", img, [int(cv2.IMWRITE_PNG_COMPRESSION), 3])  
    if not ok:  
        raise RuntimeError("Image encoding failed.")  
    return buf.tobytes()  
  
#######PDF: Step-1 (pattern removal) ######  
_SIG_APPLY = inspect.signature(fitz.Page.apply_redactions)  
_SUPPORTS_IMAGES_KW = "images" in _SIG_APPLY.parameters  
_SUPPORTS_GRAPHICS_KW = "graphics" in _SIG_APPLY.parameters  
  
REDACT_LINE_ART_OPTION = getattr(  
    fitz, "PDF_REDACT_LINE_ART_REMOVE_IF_COVERED", getattr(fitz, "PDF_REDACT_REMOVE_GRAPHICS_IF_COVERED", 0)  
)  
  
def _apply_redactions_safe(  
    page: fitz.Page,  
    *,  
    images_opt=fitz.PDF_REDACT_IMAGE_NONE,  
    graphics_opt=REDACT_LINE_ART_OPTION,  
) -> None:  
    kwargs = {}  
    if _SUPPORTS_IMAGES_KW and images_opt is not None:  
        kwargs["images"] = images_opt  
    if _SUPPORTS_GRAPHICS_KW and graphics_opt is not None:  
        kwargs["graphics"] = graphics_opt  
    page.apply_redactions(**kwargs)  
  
def process_pdf_pipeline_inspire(  
    pdf_stream: io.BytesIO,  
    *,  
    template_cover: bool = False,  
    template_img: Optional[np.ndarray] = None,  
    area_ratio: float = 0.80,  
    width_ratio: float = 0.80,  
    height_ratio: float = 0.80,  
    overlap_threshold: float = 90.0,  
    debug: bool = True,  
    cover_pages: Optional[List[int]] = None,  
) -> io.BytesIO:  
     
     ######remove large cover bitmaps and overlapping vector elements  ######
     ######(optionally) overlay new cover image  ######
     ######find + redact red diagonal "Inspire" stripe clusters  ######
 
    logger.info("🚀 Starting PDF pipeline for Inspire pattern processing")  
    logger.info(f"📋 Parameters: template_cover={template_cover}, template_img={'provided' if template_img is not None else 'None'}")  
  
    if cover_pages is None:  
        cover_pages = [0, 1]  
    cover_set: set[int] = set(cover_pages) if template_cover else set()  
    logger.info(f"📄 Cover pages to process: {cover_pages}")  
  
    doc = fitz.open(stream=pdf_stream, filetype="pdf")  
    logger.info(f"📚 Opened PDF with {len(doc)} pages")  
    for page in doc:  
        logger.info(f"📄 Processing page {page.number}")  
        pg_area = page.rect.width * page.rect.height  
        big_boxes: list[fitz.Rect] = []  
  
        images = page.get_images(full=True)  
        logger.info(f"📷 Found {len(images)} images on page {page.number}")  
  
        for i, (xref, *_) in enumerate(images):  
            rects = page.get_image_rects(xref)  
            if not rects:  
                continue  
            bb = rects[0]  
            area_r = (bb.width * bb.height) / pg_area  
            width_r = bb.width / page.rect.width  
            height_r = bb.height / page.rect.height  
            logger.info(  
                f"📊 Image {i}: area_ratio={area_r:.3f}, width_ratio={width_r:.3f}, height_ratio={height_r:.3f}"  
            )  
            if (area_r >= area_ratio or width_r >= width_ratio or height_r >= height_ratio):  
                logger.info(f"🎯 Image {i} identified as large cover image")  
                if page.number not in cover_set:  
                    logger.info(f"🔄 Replacing large image on non-cover page {page.number}")  
                    white_px = cv2.imencode(".png", np.full((1, 1, 3), 255, np.uint8))[1].tobytes()  
                    try:  
                        page.replace_image(xref, stream=white_px)  
                        logger.info("✅ Image replaced with white pixel")  
                    except Exception as e:  
                        logger.error(f"❌ Failed to replace image: {e}")  
                        pass  
                big_boxes.append(bb)  
  
        for r in big_boxes:  
            logger.info(f"🧹 Purging overlaps for bbox: {r}")  
            _purge_overlaps(page, r, overlap_threshold)  
            _scrub_forms(page)  
            if page.number not in cover_set:  
                _repaint_white_text_black(page, r)  
  
    interim = io.BytesIO()  
    doc.save(interim, deflate=True)  
    doc.close()  
    interim.seek(0)  
    logger.info("✅ Step 1 completed - bitmap cleanup done")  
  
    if template_cover and template_img is not None:  
        logger.info("🖼️ Applying template cover overlay")  
        interim = replace_cover_images_with_template(interim, template_img, cover_pages)  
        logger.info("✅ Template cover overlay completed")  
  
    logger.info("🎯 Starting stripe cluster detection and redaction")  
    doc = fitz.open(stream=interim, filetype="pdf")  
    cluster_helper = getattr(fitz.Page, "cluster_drawings")  
  
    total_flagged = 0  
    for page in doc:  
        if template_cover and page.number in cover_set:  
            logger.info(f"⏭️ Skipping cover page {page.number}")  
            continue  
  
        logger.info(f"🔍 Analyzing page {page.number} for Inspire patterns")  
        cluster_rects = cluster_helper(page)  
        logger.info(f"📊 Found {len(cluster_rects)} drawing clusters")  
        drawings = page.get_drawings()  
        logger.info(f"🎨 Found {len(drawings)} drawings")  
        flagged: List[fitz.Rect] = []  
        for i, crect in enumerate(cluster_rects):  
            cl_dr = [d for d in drawings if fitz.Rect(d["rect"]).intersects(crect)]  
            logger.info(f"🔍 Cluster {i}: {len(cl_dr)} drawings")  
            if is_inspire_cluster(cl_dr, verbose=debug and False):  
                logger.info(f"✅ Cluster {i} identified as Inspire pattern - marking for redaction")  
                flagged.append(crect)  
        logger.info(f"🎯 Page {page.number}: {len(flagged)} Inspire patterns flagged for redaction")  
        for r in flagged:  
            page.add_redact_annot(r)  
        if flagged:  
            logger.info(f"🔄 Applying redactions to page {page.number}")  
        _apply_redactions_safe(page, graphics_opt=REDACT_LINE_ART_OPTION)  
        total_flagged += len(flagged)  
  
    logger.info(f"🎉 Pipeline completed - {total_flagged} total Inspire patterns removed")  
    out = io.BytesIO()  
    doc.save(out, garbage=4)  
    doc.close()  
    out.seek(0)  
    return out  
  
#######LOGO OVERLAY (images)######
def _overlay_logo_on_image(  
    img: np.ndarray,  
    logo_path: str,  
    position: str = "top-right",  
    margin: int = 20,  
    logo_size: tuple = (120, 40),  
) -> np.ndarray:  
    logger.info(f"🔄 Overlaying logo from {logo_path} at {position}")  
    try:  
        logo = cv2.imread(logo_path, cv2.IMREAD_UNCHANGED)  
        if logo is None:  
            logger.error(f"❌ Could not load logo from {logo_path}")  
            if DEBUG:  
                print(f"⚠ Could not load logo from {logo_path}")  
            return img  
        logger.info(f"✅ Logo loaded: {logo.shape}")  
        logo = cv2.resize(logo, logo_size, interpolation=cv2.INTER_LANCZOS4)  
  
        if logo.shape[2] == 4:  
            logo_rgb = logo[:, :, :3]  
            alpha = logo[:, :, 3]  
        else:  
            logo_rgb = logo  
            gray = cv2.cvtColor(logo, cv2.COLOR_BGR2GRAY)  
            _, alpha = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)  
  
        logo_black = np.zeros_like(logo_rgb)  
        logo_black[alpha > 0] = [0, 0, 0]  
  
        img_h, img_w = img.shape[:2]  
        logo_h, logo_w = logo_black.shape[:2]  
  
        if position == "top-right":  
            start_y = margin  
            start_x = img_w - logo_w - margin  
        elif position == "top-left":  
            start_y = margin  
            start_x = margin  
        elif position == "bottom-right":  
            start_y = img_h - logo_h - margin  
            start_x = img_w - logo_w - margin  
        else:  # bottom-left  
            start_y = img_h - logo_h - margin  
            start_x = margin  
  
        end_y = min(start_y + logo_h, img_h)  
        end_x = min(start_x + logo_w, img_w)  
        actual_logo_h = end_y - start_y  
        actual_logo_w = end_x - start_x  
  
        if actual_logo_h <= 0 or actual_logo_w <= 0:  
            logger.warning("⚠️ Logo doesn't fit in image bounds")  
            if DEBUG:  
                print("⚠ Logo doesn't fit in image")  
            return img  
  
        img_roi = img[start_y:end_y, start_x:end_x]  
        logo_roi = logo_black[:actual_logo_h, :actual_logo_w]  
        alpha_roi = alpha[:actual_logo_h, :actual_logo_w]  
  
        alpha_norm = alpha_roi.astype(np.float32) / 255.0  
        alpha_norm = np.expand_dims(alpha_norm, axis=2)  
  
        blended = img_roi.astype(np.float32) * (1 - alpha_norm) + logo_roi.astype(np.float32) * alpha_norm  
        img[start_y:end_y, start_x:end_x] = blended.astype(np.uint8)  
  
        logger.info(f"✅ Logo overlayed successfully at {position}")  
        if DEBUG:  
            print(f"✓ Logo overlayed at {position} position on cover image")  
  
        return img  
    except Exception as e:  
        logger.error(f"❌ Error overlaying logo: {e}")  
        if DEBUG:  
            print(f"⚠ Error overlaying logo: {e}")  
        return img  
  
# ─────────────────────── DOCX: Step-1 (cover/pattern) ───────────────────────  
def process_docx_pipeline_inspire_new(  
    docx_bytes: bytes,  
    template_cover: bool = False,  
    template_img: Optional[np.ndarray] = None,  
) -> bytes:  
    logger.info("🚀 Starting DOCX pipeline for Inspire pattern processing (new version)")  
    logger.info(f"📋 Parameters: template_cover={template_cover}, template_img={'provided' if template_img is not None else 'None'}")  
  
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as zin:  
        names = zin.namelist()  
        original_bytes = {n: zin.read(n) for n in names}  
        logger.info(f"📄 DOCX contains {len(names)} files")  
  
    replacements: dict[str, bytes] = {}  
    first_image_processed = False  
    media_files = [n for n in names if n.startswith("word/media/")]  
    logger.info(f"📷 Found {len(media_files)} media files")  
  
    for name in media_files:  
        ext = os.path.splitext(name)[1].lower()  
        if ext not in (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff"):  
            logger.info(f"⏭️ Skipping non-image file: {name}")  
            continue  
  
        logger.info(f"🔍 Processing image: {name}")  
        img_arr = np.frombuffer(original_bytes[name], np.uint8)  
        img = cv2.imdecode(img_arr, cv2.IMREAD_COLOR)  
        if img is None:  
            logger.warning(f"⚠️ Could not decode image: {name}")  
            continue  
  
        logger.info(f"📊 Image {name}: {img.shape}")  
        is_cover_image = False  
        if not first_image_processed:  
            img_h, img_w = img.shape[:2]  
            img_area = img_h * img_w  
            logger.info(f"📏 Image area: {img_area}")  
            if img_area > 100000:  # Consider as cover if large enough  
                is_cover_image = True  
                first_image_processed = True  
                logger.info(f"✅ Identified as cover image: {name}")  
  
        has_pattern = _detect_red_diagonal_pattern(img)  
        if has_pattern:  
            logger.info(f"🎯 Red diagonal pattern detected in {name}")  
            if template_cover and template_img is not None:  
                logger.info(f"🔄 Replacing with template image")  
                h, w = img.shape[:2]  
                fitted = cv2.resize(  
                    template_img,  
                    (w, h),  
                    interpolation=cv2.INTER_AREA if (w < template_img.shape[1] or h < template_img.shape[0]) else cv2.INTER_LINEAR,  
                )  
                if is_cover_image and ADD_COVER_LOGO_DOCX:  
                    logger.info("🏷️ Adding logo to cover page")  
                    logo_file = REPLACEMENT_LOGOS.get("hitachi_inspire")  
                    if logo_file:  
                        logo_paths = [Path(logo_file), Path.cwd() / logo_file]  
                        if "__file__" in globals():  
                            logo_paths.append(Path(__file__).parent / logo_file)  
                        for logo_path in logo_paths:  
                            if logo_path.exists():  
                                logger.info(f"✅ Found logo at: {logo_path}")  
                                fitted = _overlay_logo_on_image(  
                                    fitted,  
                                    str(logo_path),  
                                    position="top-right",  
                                    margin=COVER_LOGO_MARGIN_RIGHT,  
                                    logo_size=COVER_LOGO_SIZE,  
                                )  
                                break  
                        else:  
                            logger.error("❌ Logo file not found for cover page")  
                replacements[name] = _encode_img(fitted, ext)  
                logger.info(f"✅ Template replacement completed for {name}")  
            else:  
                logger.info(f"🔄 Replacing with blank image")  
                blank = np.full_like(img, 255)  
                if is_cover_image and ADD_COVER_LOGO_DOCX:  
                    logger.info("🏷️ Adding logo to blank cover page")  
                    logo_file = REPLACEMENT_LOGOS.get("hitachi_inspire")  
                    if logo_file:  
                        logo_paths = [Path(logo_file), Path.cwd() / logo_file]  
                        if "__file__" in globals():  
                            logo_paths.append(Path(__file__).parent / logo_file)  
                        for logo_path in logo_paths:  
                            if logo_path.exists():  
                                logger.info(f"✅ Found logo at: {logo_path}")  
                                blank = _overlay_logo_on_image(  
                                    blank,  
                                    str(logo_path),  
                                    position="top-right",  
                                    margin=COVER_LOGO_MARGIN_RIGHT,  
                                    logo_size=COVER_LOGO_SIZE,  
                                )  
                                break  
                        else:  
                            logger.error("❌ Logo file not found for blank cover page")  
                replacements[name] = _encode_img(blank, ext)  
                logger.info(f"✅ Blank replacement completed for {name}")  
        elif is_cover_image and ADD_COVER_LOGO_DOCX:  
            logger.info(f"🏷️ Adding logo to cover image without red pattern: {name}")  
            logo_file = REPLACEMENT_LOGOS.get("hitachi_inspire")  
            if logo_file:  
                logo_paths = [Path(logo_file), Path.cwd() / logo_file]  
                if "__file__" in globals():  
                    logo_paths.append(Path(__file__).parent / logo_file)  
                for logo_path in logo_paths:  
                    if logo_path.exists():  
                        logger.info(f"✅ Found logo at: {logo_path}")  
                        img_with_logo = _overlay_logo_on_image(  
                            img,  
                            str(logo_path),  
                            position="top-right",  
                            margin=COVER_LOGO_MARGIN_RIGHT,  
                            logo_size=COVER_LOGO_SIZE,  
                        )  
                        replacements[name] = _encode_img(img_with_logo, ext)  
                        break  
                else:  
                    logger.error("❌ Logo file not found for cover image")  
        else:  
            logger.info(f"⏭️ No processing needed for {name}")  
  
    logger.info(f"🔄 Rebuilding DOCX with {len(replacements)} replaced files")  
    output_buffer = io.BytesIO()  
    with zipfile.ZipFile(output_buffer, "w", compression=zipfile.ZIP_DEFLATED) as zout:  
        for n in names:  
            zout.writestr(n, replacements.get(n, original_bytes[n]))  
        logger.info("✅ DOCX pipeline completed successfully")  
    return output_buffer.getvalue()  
  
def process_docx_pipeline_inspire(  
    docx_bytes: bytes,  
    template_cover: bool = False,  
    template_img: Optional[np.ndarray] = None,  
) -> bytes:  
    logger.info("🚀 Starting DOCX pipeline for Inspire pattern processing")  
    logger.info(f"📋 Parameters: template_cover={template_cover}, template_img={'provided' if template_img is not None else 'None'}")  
  
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as zin:  
        names = zin.namelist()  
        original_bytes = {n: zin.read(n) for n in names}  
        logger.info(f"📄 DOCX contains {len(names)} files")  
  
    replacements: dict[str, bytes] = {}  
    media_files = [n for n in names if n.startswith("word/media/")]  
    logger.info(f"📷 Found {len(media_files)} media files")  
  
    for name in media_files:  
        ext = os.path.splitext(name)[1].lower()  
        if ext not in (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff"):  
            logger.info(f"⏭️ Skipping non-image file: {name}")  
            continue  
        logger.info(f"🔍 Processing image: {name}")  
        img_arr = np.frombuffer(original_bytes[name], np.uint8)  
        img = cv2.imdecode(img_arr, cv2.IMREAD_COLOR)  
        if img is None:  
            logger.warning(f"⚠️ Could not decode image: {name}")  
            continue  
        logger.info(f"📊 Image {name}: {img.shape}")  
        has_pattern = _detect_red_diagonal_pattern(img)  
        if has_pattern:  
            logger.info(f"🎯 Red diagonal pattern detected in {name}")  
            if template_cover and template_img is not None:  
                logger.info(f"🔄 Replacing with template image")  
                h, w = img.shape[:2]  
                fitted = cv2.resize(  
                    template_img,  
                    (w, h),  
                    interpolation=cv2.INTER_AREA if (w < template_img.shape[1] or h < template_img.shape[0]) else cv2.INTER_LINEAR,  
                )  
                replacements[name] = _encode_img(fitted, ext)  
                logger.info(f"✅ Template replacement completed for {name}")  
            else:  
                logger.info(f"🔄 Replacing with blank image")  
                blank = np.full_like(img, 255)  
                replacements[name] = _encode_img(blank, ext)  
                logger.info(f"✅ Blank replacement completed for {name}")  
        else:  
            logger.info(f"⏭️ No red diagonal pattern found in {name}")  
  
    logger.info(f"🔄 Rebuilding DOCX with {len(replacements)} replaced files")  
    output_buffer = io.BytesIO()  
    with zipfile.ZipFile(output_buffer, "w", compression=zipfile.ZIP_DEFLATED) as zout:  
        for n in names:  
            zout.writestr(n, replacements.get(n, original_bytes[n]))  
        logger.info("✅ DOCX pipeline completed successfully")  
    return output_buffer.getvalue()  
  
#######Utilities###### 
def ensure_dir(p: Path | str) -> None:  
    Path(p).mkdir(parents=True, exist_ok=True)  
  
def pil2bytes(img: Image.Image, fmt: str = "PNG") -> bytes:  
    buf = io.BytesIO()  
    img.save(buf, fmt)  
    return buf.getvalue()  
  
def resize_for_azure(img: Image.Image) -> Tuple[Image.Image, float]:  
    w, h = img.size  
    if w < MIN_DIM or h < MIN_DIM:  
        s = float(MIN_DIM) / min(w, h)  
    elif w > MAX_DIM or h > MAX_DIM:  
        s = float(MAX_DIM) / max(w, h)  
    else:  
        return img, 1.0  
    return img.resize((int(w * s), int(h * s)), Image.LANCZOS), s  
  
def _iou(a, b) -> float:  
    xa1, ya1, xa2, ya2 = a  
    xb1, yb1, xb2, yb2 = b  
    iw = max(0, min(xa2, xb2) - max(xa1, xb1))  
    ih = max(0, min(ya2, yb2) - max(ya1, yb1))  
    inter = iw * ih  
    if inter == 0:  
        return 0.0  
    return inter / (((xa2 - xa1) * (ya2 - ya1)) + ((xb2 - xb1) * (yb2 - yb1)) - inter)  
  
def _expand_box(  
    box: Tuple[int, int, int, int], pad: int, max_w: int, max_h: int  
) -> Tuple[int, int, int, int]:  
    x1, y1, x2, y2 = box  
    return (  
        max(0, x1 - pad),  
        max(0, y1 - pad),  
        min(max_w, x2 + pad),  
        min(max_h, y2 + pad),  
    )  
  
def _load_logo(key: str) -> np.ndarray:  
    logger.info(f"🔍 Loading logo for key: {key}")  
    filename = REPLACEMENT_LOGOS[key]  
    candidates: list[Path] = []  
    p = Path(filename)  
    if p.is_absolute():  
        candidates.append(p)  
    else:  
        here = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()  
        azure = Path("/home/site/wwwroot")  
        candidates.extend([here / filename, Path.cwd() / filename, azure / filename])  
  
    logger.info(f"🔍 Searching for logo file '{filename}' in locations:")  
    for i, path in enumerate(candidates, 1):  
        logger.info(f"  {i}. {path}")  
  
    for path in candidates:  
        if path.exists():  
            logger.info(f"✅ Found logo file at: {path}")  
            img = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)  
            if img is not None:  
                logger.info(f"✅ Logo loaded successfully: {img.shape}")  
                return img  
            else:  
                logger.warning(f"⚠️ Could not decode image at: {path}")  
  
    error_msg = (  
        f"❌ Replacement logo '{filename}' not found.\n"  
        f"🔍 Searched locations:\n" + "\n".join(f"  - {path}" for path in candidates)  
    )  
    logger.error(error_msg)  
    raise FileNotFoundError(error_msg)  
  
#######LOGO DETECTION BACKENDS ######
def azure_detect(img: Image.Image) -> List[dict]:  
    logger.info(f"🔍 Starting Azure logo detection on image {img.size}")  
    try:  
        from azure.ai.vision.imageanalysis import ImageAnalysisClient  
        from azure.ai.vision.imageanalysis.models import VisualFeatures  
        from azure.core.credentials import AzureKeyCredential  
  
        client = ImageAnalysisClient(  
            endpoint=AZURE_VISION_ENDPOINT,  
            credential=AzureKeyCredential(AZURE_VISION_KEY),  
        )  
  
        detections: List[dict] = []  
  
        logger.info("🎯 Running Azure object detection")  
        objs = client.analyze(image_data=pil2bytes(img), visual_features=[VisualFeatures.OBJECTS])  
        if objs.objects:  
            logger.info(f"📦 Found {len(objs.objects.list)} objects")  
            for i, o in enumerate(objs.objects.list):  
                tag = o.tags[0]  
                logger.info(f"  Object {i}: {tag.name} (conf: {tag.confidence:.3f})")  
                if float(tag.confidence or 0) < LOGO_CONF_THRESHOLD:  
                    logger.info(f"    ⏭️ Skipped - confidence too low")  
                    continue  
                if not any(k in tag.name.lower() for k in KEYWORDS_HITACHI):  
                    logger.info(f"    ⏭️ Skipped - not a Hitachi keyword")  
                    continue  
                bb = o.bounding_box  
                detection = dict(  
                    label=tag.name,  
                    source="object",  
                    conf=float(tag.confidence or 0),  
                    box=(bb.x, bb.y, bb.x + bb.w, bb.y + bb.h),  
                )  
                detections.append(detection)  
                logger.info(f"    ✅ Added object detection: {detection}")  
  
        def _append(read_res, y_shift, scale, want_energy):  
            if not read_res.read or not getattr(read_res.read, "blocks", None):  
                return  
            for blk in read_res.read.blocks:  
                for ln in blk.lines:  
                    txt = (ln.text or "").strip()  
                    if not any(k in txt.lower() for k in KEYWORDS_HITACHI):  
                        continue  
                    if ("energy" in txt.lower()) != want_energy:  
                        continue  
                    xs = [p.x / scale for p in ln.bounding_polygon]  
                    ys = [p.y / scale + y_shift for p in ln.bounding_polygon]  
                    detection = dict(  
                        label=txt,  
                        source="ocr",  
                        conf=1.0,  
                        box=(min(xs), min(ys), max(xs), max(ys)),  
                    )  
                    detections.append(detection)  
                    logger.info(f"    ✅ Added OCR detection: {detection}")  
  
        scaled, sc = resize_for_azure(img)  
        logger.info("📝 Running Azure OCR on full page")  
        ocr_full = client.analyze(image_data=pil2bytes(scaled), visual_features=[VisualFeatures.READ])  
        _append(ocr_full, 0, sc, want_energy=False)  
  
        logger.info("📝 Running Azure OCR on footer region")  
        y0 = int(img.height * (1 - FOOTER_OCR_PCT))  
        foot, sc2 = resize_for_azure(img.crop((0, y0, img.width, img.height)))  
        ocr_foot = client.analyze(image_data=pil2bytes(foot), visual_features=[VisualFeatures.READ])  
        _append(ocr_foot, y0, sc2, want_energy=True)  
  
        _append(ocr_full, 0, sc, want_energy=True)  
  
        logger.info(f"✅ Azure detection completed: {len(detections)} detections")  
        return detections  
    except Exception as exc:  
        logger.error(f"❌ Azure detect error: {exc}")  
        if DEBUG:  
            print("Azure detect error – continuing without Azure:", exc)  
        return []  
  
def template_detect_single(gray_full: np.ndarray, tmpl: np.ndarray, thr: float, sc: float) -> List[Tuple[int, int]]:  
    if gray_full.shape[0] < tmpl.shape[0] or gray_full.shape[1] < tmpl.shape[1]:  
        return []  
    res = cv2.matchTemplate(gray_full, tmpl, cv2.TM_CCOEFF_NORMED)  
    ys, xs = np.where(res >= thr)  
    return [(int(y / sc), int(x / sc)) for y, x in zip(ys, xs)]  
  
def template_detect(img: Image.Image) -> List[dict]:  
    logger.info(f"🔍 Starting template detection on image {img.size}")  
    if not USE_TEMPLATE_DET or not Path(TEMPLATE_DIR).exists():  
        logger.warning(f"⚠️ Template detection disabled or directory '{TEMPLATE_DIR}' not found")  
        return []  
  
    hits: List[dict] = []  
    pil_rots = [(img, 0)]  
    for deg in (90, 270):  
        pil_rots.append((img.rotate(deg, expand=True), deg))  
    for pil_rot, deg in pil_rots:  
        logger.info(f"🔄 Processing rotation: {deg}°")  
        gray_full = cv2.cvtColor(np.asarray(pil_rot.convert("RGB")), cv2.COLOR_RGB2GRAY)  
        template_files = list(Path(TEMPLATE_DIR).glob("*"))  
        logger.info(f"📁 Found {len(template_files)} template files")  
        for tpath in template_files:  
            stem = tpath.stem.lower()  
            logger.info(f"🔍 Processing template: {stem}")  
            if "hitachi_inspire" in stem:  
                lbl = "hitachi inspire the next"  
            elif "hitachi_energy" in stem:  
                lbl = "hitachi energy"  
            else:  
                logger.info(f"  ⏭️ Skipped - not a recognized template")  
                continue  
            tmpl = cv2.imread(str(tpath), cv2.IMREAD_GRAYSCALE)  
            if tmpl is None:  
                logger.warning(f"  ⚠️ Could not load template: {tpath}")  
                continue  
            th, tw = tmpl.shape[:2]  
            thr = TEMPLATE_THRESHOLDS.get(lbl, 0.63)  
            logger.info(f"  📊 Template: {th}x{tw}, threshold: {thr}")  
            for sc in (1.0, 0.9, 0.8, 0.7, 0.6):  
                gray = (gray_full if sc == 1.0 else cv2.resize(gray_full, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA))  
                xy_hits = template_detect_single(gray, tmpl, thr, sc)  
                logger.info(f"    Scale {sc}: {len(xy_hits)} matches")  
                for top, left in xy_hits:  
                    detection = dict(  
                        label=lbl,  
                        source="tmpl",  
                        conf=1.0,  
                        box=(left, top, left + int(tw / sc), top + int(th / sc)),  
                    )  
                    hits.append(detection)  
                    logger.info(f"      ✅ Added template match: {detection}")  
    logger.info(f"✅ Template detection completed: {len(hits)} matches")  
    return hits  
  
def tesseract_detect(img: Image.Image) -> list[dict]:  
    logger.info(f"🔍 Starting Tesseract OCR on image {img.size}")  
    if not ENABLE_TESSERACT:  
        logger.warning("⚠️ Tesseract OCR disabled")  
        return []  
    try:  
        data = pytesseract.image_to_data(img, output_type=Output.DICT, lang="eng")  
        out = []  
        logger.info(f"📝 Tesseract found {len(data['text'])} text elements")  
        for i, word in enumerate(data["text"]):  
            if data["conf"][i] < TESS_MIN_CONF:  
                continue  
            word_lc = word.strip().lower()  
            if not any(k in word_lc for k in KEYWORDS_HITACHI):  
                continue  
            x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]  
            detection = dict(  
                label=word_lc,  
                source="tess",  
                conf=data["conf"][i] / 100,  
                box=(x, y, x + w, y + h),  
            )  
            out.append(detection)  
            logger.info(f"  ✅ Added Tesseract detection: {detection}")  
        logger.info(f"✅ Tesseract completed: {len(out)} detections")  
        return out  
    except Exception as e:  
        logger.error(f"❌ Tesseract error: {e}")  
        if DEBUG:  
            print(f"Tesseract error: {e}")  
        return []  
  
#######Logo Analysis ######  
def _ocr_roi(pil_img: Image.Image, box: tuple) -> str:  
    if not ENABLE_TESSERACT:  
        return ""  
    try:  
        x1, y1, x2, y2 = map(int, box)  
        roi = pil_img.crop((x1, y1, x2, y2))  
        txt = pytesseract.image_to_string(roi, lang="eng", config="--psm 6")  
        logger.info(f"🔍 OCR ROI result: '{txt.strip()}'")  
        return txt.lower()  
    except Exception as e:  
        logger.warning(f"⚠️ OCR ROI error: {e}")  
        return ""  
  
def is_old_hitachi_logo(pil_img: Image.Image, box: tuple) -> bool:  
    logger.info(f"🔍 Checking if logo is old Hitachi style: {box}")  
    txt = _ocr_roi(pil_img, box)  
    is_old = "inspire" in txt or "next" in txt  
    logger.info(f"📊 Old Hitachi logo check: text='{txt}', is_old={is_old}")  
    return is_old  
  
def _ink_ratio(img: Image.Image, box) -> float:  
    x1, y1, x2, y2 = map(int, box)  
    arr = np.asarray(img.crop((x1, y1, x2, y2)).convert("L"))  
    return (arr < 240).sum() / arr.size  
  
def _looks_like_logo(img: Image.Image, box) -> bool:  
    x1, y1, x2, y2 = map(int, box)  
    h, w = y2 - y1, x2 - x1  
    ink_r = _ink_ratio(img, box)  
    looks_like = h >= MIN_LOGO_HEIGHT_PX and w / h >= 2.0 and ink_r >= 0.07  
    logger.info(f"📊 Logo check: h={h}, w={w}, ratio={w/h:.2f}, ink={ink_r:.3f}, looks_like={looks_like}")  
    return looks_like  
  
def _red_mask(pil_img: Image.Image, roi_box) -> np.ndarray:  
    x1, y1, x2, y2 = map(int, roi_box)  
    x1 = max(0, min(x1, pil_img.width))  
    x2 = max(0, min(x2, pil_img.width))  
    y1 = max(0, min(y1, pil_img.height))  
    y2 = max(0, min(y2, pil_img.height))  
    if x2 <= x1 or y2 <= y1:  
        return np.zeros((1, 1), dtype=np.uint8)  
    hsv = cv2.cvtColor(np.asarray(pil_img.crop((x1, y1, x2, y2))), cv2.COLOR_RGB2HSV)  
    return (  
        cv2.inRange(hsv, (0, 100, 50), (10, 255, 255)) |  
        cv2.inRange(hsv, (160, 100, 50), (180, 255, 255))  
    )  
  
def _red_ratio(img: Image.Image, box) -> float:  
    mask = _red_mask(img, box)  
    ratio = (mask > 0).sum() / mask.size  
    logger.info(f"🔴 Red ratio in box {box}: {ratio:.4f}")  
    return ratio  
  
def _left_red_ratio(img: Image.Image, box, pct: float = 0.35) -> float:  
    x1, y1, x2, y2 = map(int, box)  
    split = x1 + int((x2 - x1) * pct)  
    left_box = (x1, y1, split, y2)  
    ratio = _red_ratio(img, left_box)  
    logger.info(f"🔴 Left red ratio (left {pct*100:.0f}%): {ratio:.4f}")  
    return ratio  
  
def _has_logo_symbol(  
    img: Image.Image,  
    box,  
    left_pct: float = 0.35,  
    min_px: int = MIN_SYMBOL_AREA_PX,  
    min_ratio: float = MIN_SYMBOL_AREA_RATIO,  
    asp_lo: float = MIN_SYMBOL_ASPECT,  
    asp_hi: float = MAX_SYMBOL_ASPECT,  
) -> bool:  
    logger.info(f"🔍 Checking for logo symbol in box: {box}")  
    x1, y1, x2, y2 = map(int, box)  
    split = x1 + int((x2 - x1) * left_pct)  
    roi_box = (x1, y1, split, y2)  
    mask = _red_mask(img, roi_box)  
    red_pixels = cv2.countNonZero(mask)  
    logger.info(f"🔴 Red pixels in symbol area: {red_pixels}")  
    if red_pixels < min_px:  
        logger.info(f"❌ Not enough red pixels (min: {min_px})")  
        return False  
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=2)  
    num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)  
    if num <= 1:  
        logger.info("❌ No connected components found")  
        return False  
    stats = stats[1:]  
    areas = stats[:, cv2.CC_STAT_AREA]  
    idx = int(np.argmax(areas))  
    area = int(areas[idx])  
    x, y, w, h = stats[idx, :4]  
    logger.info(f"📊 Largest symbol: area={area}, size={w}x{h}")  
    roi_area = mask.size  
    area_ratio = area / roi_area  
    logger.info(f"📊 Area ratio: {area_ratio:.4f} (min: {min_ratio})")  
    if area < min_px or area_ratio < min_ratio:  
        logger.info("❌ Symbol too small or low ratio")  
        return False  
    aspect = w / h if h else 0  
    logger.info(f"📊 Symbol aspect ratio: {aspect:.2f} (range: {asp_lo}-{asp_hi})")  
    has_symbol = asp_lo <= aspect <= asp_hi  
    logger.info(f"✅ Has logo symbol: {has_symbol}")  
    return has_symbol  
  
def _is_energy_logo(img: Image.Image, box) -> bool:  
    logger.info(f"🔍 Checking if box is Hitachi Energy logo: {box}")  
    looks_like = _looks_like_logo(img, box)  
    red_ratio = _red_ratio(img, box)  
    left_red_ratio = _left_red_ratio(img, box)  
    has_symbol = _has_logo_symbol(img, box)  
    is_energy = (looks_like and red_ratio >= MIN_RED_RATIO and left_red_ratio >= MIN_LEFT_RED_RATIO and has_symbol)  
    logger.info(  
        f"📊 Energy logo analysis: looks_like={looks_like}, red_ratio={red_ratio:.4f}>={MIN_RED_RATIO}, left_red_ratio={left_red_ratio:.4f}>={MIN_LEFT_RED_RATIO}, has_symbol={has_symbol} → is_energy={is_energy}"  
    )  
    return is_energy  
  
def _extend_hitachi_energy_box(box, img: Image.Image, max_ratio: float = 1.6) -> Tuple[int, int, int, int]:  
    logger.info(f"🔍 Extending Hitachi Energy box: {box}")  
    fallback_pad_ratio = 0.001  
    x1, y1, x2, y2 = map(int, box)  
    h = y2 - y1  
    search = int(h * max_ratio)  
    logger.info(f"📏 Search distance: {search} pixels")  
    left_roi = (max(0, x1 - search), y1, x1, y2)  
    right_roi = (x2, y1, min(img.width, x2 + search), y2)  
  
    def _symbol_bounds(roi):  
        if roi[2] <= roi[0] or roi[3] <= roi[1]:  
            return None  
        mask = _red_mask(img, roi)  
        red_pixels = cv2.countNonZero(mask)  
        logger.info(f"  ROI {roi}: {red_pixels} red pixels")  
        if red_pixels < 150:  
            return None  
        n, _, stats, _ = cv2.connectedComponentsWithStats(mask, 8)  
        if n <= 1:  
            return None  
        stats = stats[1:]  
        rx, ry, rw, rh, _ = stats[np.argmax(stats[:, cv2.CC_STAT_AREA])]  
        bounds = roi[0] + rx, roi[0] + rx + rw  
        logger.info(f"  Found symbol bounds: {bounds}")  
        return bounds  
  
    PAD = 2  
    lbounds = _symbol_bounds(left_roi)  
    rbounds = _symbol_bounds(right_roi)  
  
    original_box = (x1, y1, x2, y2)  
    if lbounds:  
        x1 = min(x1, lbounds[0] - PAD)  
        logger.info(f"📏 Extended left to include symbol")  
    elif rbounds:  
        x2 = max(x2, rbounds[1] + PAD)  
        logger.info(f"📏 Extended right to include symbol")  
    else:  
        pad = int(h * fallback_pad_ratio)  
        x1 = max(0, x1 - pad)  
        x2 = min(img.width, x2 + pad)  
        logger.info(f"📏 Applied fallback padding: {pad} pixels")  
    extended_box = (x1, y1, x2, y2)  
    logger.info(f"📏 Box extension: {original_box} → {extended_box}")  
    return extended_box  
  
def detect_logo_only_page(img: Image.Image) -> List[dict]:  
    logger.info(f"🔍 Detecting logo-only page on image {img.size}")  
    gray = cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2GRAY)  
    _, bw = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)  
    ink_ratio = np.count_nonzero(bw) / bw.size  
    logger.info(f"📊 Ink ratio: {ink_ratio:.4f} (range: {MIN_SOLO_INK_RATIO}-{MAX_SOLO_INK_RATIO})")  
    if not (MIN_SOLO_INK_RATIO < ink_ratio < MAX_SOLO_INK_RATIO):  
        logger.info("❌ Ink ratio outside acceptable range")  
        return []  
    bw = cv2.morphologyEx(bw, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))  
    cnts, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  
    if not cnts:  
        logger.info("❌ No contours found")  
        return []  
    x, y, w, h = cv2.boundingRect(max(cnts, key=cv2.contourArea))  
    box = (x, y, x + w, y + h)  
    logger.info(f"📊 Main contour: {w}x{h}, ratio: {w/h:.2f}")  
    if h < MIN_LOGO_HEIGHT_PX or w / h < 2.0:  
        logger.info("❌ Contour too small or wrong aspect ratio")  
        return []  
    if not _is_energy_logo(img, box):  
        logger.info("❌ Does not look like energy logo")  
        return []  
    detection = {"label": "hitachi energy", "box": box}  
    logger.info(f"✅ Detected logo-only page: {detection}")  
    return [detection]  
  
def final_logo_boxes(img: Image.Image) -> List[dict]:  
    logger.info(f"🚀 Starting comprehensive logo detection on image {img.size}")  
    scaled, sc = resize_for_azure(img)  
    logger.info(f"📏 Image scaling: {sc:.3f}")  
    cand: List[dict] = []  
    if DETECTION_BACKEND == "azure":  
        logger.info("🔍 Running Azure detection")  
        cand.extend(azure_detect(scaled))  
    logger.info("🔍 Running template detection")  
    cand.extend(template_detect(scaled))  
  
    logger.info(f"📊 Initial candidates: {len(cand)}")  
    if sc != 1.0:  
        logger.info(f"📏 Rescaling {len(cand)} candidates by factor {1/sc:.3f}")  
        for c in cand:  
            x1, y1, x2, y2 = c["box"]  
            c["box"] = (int(x1 / sc), int(y1 / sc), int(x2 / sc), int(y2 / sc))  
  
    footer_y = int(img.height * (1 - FOOTER_OCR_PCT))  
    logger.info(f"📊 Footer boundary at y={footer_y}")  
  
    before_filter = len(cand)  
    cand = [  
        c  
        for c in cand  
        if not (  
            "energy" in c["label"].lower()  
            and (c["box"][1] + c["box"][3]) / 2 < footer_y  
            and not (_looks_like_logo(img, c["box"]) or _is_energy_logo(img, c["box"]))  
        )  
    ]  
    after_filter = len(cand)  
    logger.info(f"🧹 Filtered body energy words: {before_filter} → {after_filter}")  
  
    used: Set[int] = set()  
    final: List[dict] = []  
  
    def h_overlap(a, b):  
        return max(0, min(a[2], b[2]) - max(a[0], b[0]))  
  
    idx_hitachi = [i for i, c in enumerate(cand) if c["label"].lower() == "hitachi"]  
    idx_tagline = [i for i, c in enumerate(cand) if any(w in c["label"].lower() for w in ("inspire", "next"))]  
    idx_energy_word = [i for i, c in enumerate(cand) if c["label"].strip().lower() == "energy"]  
  
    logger.info(f"📊 Candidate groups: Hitachi={len(idx_hitachi)}, Tagline={len(idx_tagline)}, Energy={len(idx_energy_word)}")  
  
    logger.info("🔍 Processing Hitachi + Inspire combinations")  
    for hi in idx_hitachi:  
        if hi in used:  
            continue  
        hx1, hy1, hx2, hy2 = cand[hi]["box"]  
        hh = hy2 - hy1  
        union, grp = list(cand[hi]["box"]), [hi]  
        logger.info(f"  Hitachi candidate {hi}: box={cand[hi]['box']}")  
        for ti in idx_tagline:  
            if ti in used:  
                continue  
            tx1, ty1, tx2, ty2 = cand[ti]["box"]  
            logger.info(f"    Checking tagline {ti}: box={cand[ti]['box']}")  
            if not (hy1 <= ty1 <= hy2 + 3 * hh):  
                logger.info(f"      ❌ Vertical alignment check failed")  
                continue  
            if (h_overlap(cand[hi]["box"], cand[ti]["box"]) >= 0.3 * (tx2 - tx1) or hx1 <= (tx1 + tx2) / 2 <= hx2):  
                logger.info(f"      ✅ Horizontal alignment check passed")  
                union[0] = min(union[0], tx1)  
                union[1] = min(union[1], ty1)  
                union[2] = max(union[2], tx2)  
                union[3] = max(union[3], ty2)  
                grp.append(ti)  
  
        if len(grp) == 1:  
            union[3] = min(img.height, union[3] + int(1.5 * hh))  
            logger.info(f"    Extended single Hitachi box vertically")  
  
        if _looks_like_logo(img, union):  
            logo = {"label": "hitachi inspire the next", "box": tuple(map(int, union))}  
            final.append(logo)  
            used.update(grp)  
            logger.info(f"    ✅ Added Hitachi Inspire logo: {logo}")  
        else:  
            logger.info(f"    ❌ Union does not look like a logo")  
  
    logger.info("🔍 Processing Hitachi + Energy (footer) combinations")  
    for hi in idx_hitachi:  
        if hi in used or cand[hi]["box"][1] < footer_y:  
            continue  
        hx1, hy1, hx2, hy2 = cand[hi]["box"]  
        hh, union, grp, merged = hy2 - hy1, list(cand[hi]["box"]), [hi], False  
        logger.info(f"  Footer Hitachi candidate {hi}: box={cand[hi]['box']}")  
        for ei in idx_energy_word:  
            if ei in used:  
                continue  
            ex1, ey1, ex2, ey2 = cand[ei]["box"]  
            if ey1 < footer_y or not (hy1 <= ey1 <= hy2 + 2.5 * hh):  
                continue  
            if (h_overlap(cand[hi]["box"], cand[ei]["box"]) >= 0.25 * (ex2 - ex1) or hx1 <= (ex1 + ex2) / 2 <= hx2):  
                union[0] = min(union[0], ex1)  
                union[1] = min(union[1], ey1)  
                union[2] = max(union[2], ex2)  
                union[3] = max(union[3], ey2)  
                grp.append(ei)  
                merged = True  
                logger.info(f"    ✅ Merged with energy word {ei}")  
        if merged and _is_energy_logo(img, union):  
            logo = {"label": "hitachi energy", "box": tuple(map(int, union))}  
            final.append(logo)  
            used.update(grp)  
            logger.info(f"    ✅ Added footer Hitachi Energy logo: {logo}")  
  
    logger.info("🔍 Processing Hitachi + Energy (body) combinations")  
    for hi in idx_hitachi:  
        if hi in used:  
            continue  
        hx1, hy1, hx2, hy2 = cand[hi]["box"]  
        if not (HEADER_FOOTER_PCT * img.height < hy1 < (1 - FOOTER_OCR_PCT) * img.height):  
            continue  
        hh, union, grp, merged = hy2 - hy1, list(cand[hi]["box"]), [hi], False  
        logger.info(f"  Body Hitachi candidate {hi}: box={cand[hi]['box']}")  
        for ei in idx_energy_word:  
            if ei in used:  
                continue  
            ex1, ey1, ex2, ey2 = cand[ei]["box"]  
            if not (HEADER_FOOTER_PCT * img.height < ey1 < (1 - FOOTER_OCR_PCT) * img.height):  
                continue  
            if not (hy1 <= ey1 <= hy2 + 3 * hh):  
                continue  
            if (h_overlap(cand[hi]["box"], cand[ei]["box"]) >= 0.25 * (ex2 - ex1) or hx1 <= (ex1 + ex2) / 2 <= hx2):  
                union[0] = min(union[0], ex1)  
                union[1] = min(union[1], ey1)  
                union[2] = max(union[2], ex2)  
                union[3] = max(union[3], ey2)  
                grp.append(ei)  
                merged = True  
                logger.info(f"    ✅ Merged with energy word {ei}")  
        if merged and _is_energy_logo(img, union):  
            logo = {"label": "hitachi energy", "box": tuple(map(int, union))}  
            final.append(logo)  
            used.update(grp)  
            logger.info(f"    ✅ Added body Hitachi Energy logo: {logo}")  
  
    logger.info("🔍 Processing single-box Hitachi Energy")  
    for i, c in enumerate(cand):  
        if i in used:  
            continue  
        if "hitachi" in c["label"].lower() and "energy" in c["label"].lower() and _is_energy_logo(img, c["box"]):  
            logo = {"label": "hitachi energy", "box": tuple(map(int, c["box"]))}  
            final.append(logo)  
            used.add(i)  
            logger.info(f"    ✅ Added single-box Hitachi Energy: {logo}")  
  
    logger.info("🔍 Processing template leftovers")  
    for i, c in enumerate(cand):  
        if i in used or c["source"] != "tmpl" or "energy" in c["label"].lower():  
            continue  
        if _looks_like_logo(img, c["box"]):  
            logo = {"label": c["label"], "box": tuple(map(int, c["box"]))}  
            final.append(logo)  
            used.add(i)  
            logger.info(f"    ✅ Added template leftover: {logo}")  
  
    logger.info("🔍 Processing stand-alone Hitachi")  
    for i, c in enumerate(cand):  
        if i in used or c["label"].lower() != "hitachi":  
            continue  
        x1, y1, x2, y2 = c["box"]  
        h, w = y2 - y1, x2 - x1  
        if h < MIN_LOGO_HEIGHT_PX or w / h < MIN_HITACHI_WIDTH_RATIO:  
            continue  
        if HEADER_FOOTER_PCT * img.height <= y2 <= (1 - HEADER_FOOTER_PCT) * img.height:  
            continue  
        union = (x1, y1, x2, min(img.height, y2 + int(1.5 * h)))  
        if _looks_like_logo(img, union):  
            logo = {"label": "hitachi inspire the next", "box": union}  
            final.append(logo)  
            logger.info(f"    ✅ Added standalone Hitachi: {logo}")  
  
    logger.info("🧹 Deduplicating final results")  
    dedup: List[dict] = []  
    for m in final:  
        if not any(_iou(m["box"], d["box"]) > IOU_DUP_THRESHOLD for d in dedup):  
            dedup.append(m)  
        else:  
            logger.info(f"    🗑️ Removed duplicate: {m}")  
  
    if SKIP_NEW_HITACHI:  
        logger.info("🔍 Filtering new Hitachi logos")  
        before_skip = len(dedup)  
        dedup = [  
            d for d in dedup  
            if not (  
                d["label"].startswith("hitachi")  
                and "energy" not in d["label"].lower()  
                and not is_old_hitachi_logo(img, d["box"])  
            )  
        ]  
        after_skip = len(dedup)  
        logger.info(f"    Filtered new logos: {before_skip} → {after_skip}")  
  
    logger.info(f"🎉 Final logo detection completed: {len(dedup)} logos found")  
    for i, logo in enumerate(dedup):  
        logger.info(f"  {i+1}. {logo}")  
    return dedup  
  
#######Inpainting & Logo Replacement######
def smart_inpaint(page_bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:  
    logger.info("🎨 Starting smart inpainting")  
    if _LAMA_MODEL is not None:  
        try:  
            logger.info("→ Using LaMa inpainting model")  
            if DEBUG:  
                print("→ LaMa in-paint …")  
            return _apply_lama_inpaint(page_bgr, mask)  
        except Exception as exc:  
            logger.warning(f"⚠ LaMa inpainting failed: {exc}")  
            if DEBUG:  
                print("⚠ LaMa failed:", exc)  
    logger.info("→ Using OpenCV Telea inpainting")  
    if DEBUG:  
        print("→ OpenCV Telea in-paint …")  
    return cv2.inpaint(page_bgr, mask, 7, cv2.INPAINT_TELEA)  
  
def _get_mask_center(mask: np.ndarray) -> Tuple[int, int]:  
    ys, xs = np.nonzero(mask)  
    if xs.size == 0 or ys.size == 0:  
        h, w = mask.shape[:2]  
        return w // 2, h // 2  
    return int(xs.mean()), int(ys.mean())  
  
def _apply_lama_inpaint(cv_bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:  
    logger.info("🎨 Applying LaMa inpainting")  
    rgb = cv2.cvtColor(cv_bgr, cv2.COLOR_BGR2RGB)  
    res = _LAMA_MODEL(rgb, mask, _LAMA_CFG_OBJ)  # type: ignore  
    if res.dtype != np.uint8:  
        res = np.clip(res, 0, 255).astype(np.uint8)  
    res_bgr = cv2.cvtColor(res, cv2.COLOR_RGB2BGR)  
    try:  
        centre = _get_mask_center(mask)  
        blended = cv2.seamlessClone(res_bgr, cv_bgr, mask, centre, cv2.NORMAL_CLONE)  
        logger.info("✅ LaMa inpainting with seamless clone completed")  
        return blended  
    except cv2.error:  
        logger.info("⚠️ Seamless clone failed, using raw LaMa result")  
        return res_bgr  
  
def _prep_logo(key: str, tw: int, th: int) -> np.ndarray:  
    logger.info(f"🔄 Preparing logo '{key}' for size {tw}x{th}")  
    logo = _load_logo(key)  
    if (th > tw) != (logo.shape[0] > logo.shape[1]):  
        logger.info("🔄 Rotating logo for orientation match")  
        logo = cv2.rotate(logo, cv2.ROTATE_90_COUNTERCLOCKWISE)  
    scale = max(1e-6, min(tw / logo.shape[1], th / logo.shape[0]) * SCALE_COVERAGE)  
    new_w = max(1, int(round(logo.shape[1] * scale)))  
    new_h = max(1, int(round(logo.shape[0] * scale)))  
    logger.info(f"📏 Logo scaling: {scale:.3f}, new size: {new_w}x{new_h}")  
    result = cv2.resize(logo, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)  
    logger.info("✅ Logo preparation completed")  
    return result  
  
def _dominant_text_colour_simplified(  
    pil_img: Image.Image,  
    box: tuple[int, int, int, int],  
) -> tuple[int, int, int]:  
    logger.info(f"🎨 Determining text color for logo in box: {box}")  
    if FORCE_BLACK_INSPIRE_LOGOS:  
        logger.info("  → Forcing black color for Hitachi Inspire logo")  
        if DEBUG:  
            print("  -> Forcing black color for Hitachi Inspire logo")  
        return (0, 0, 0)  
    x1, y1, x2, y2 = map(int, box)  
    x1 = max(0, x1); y1 = max(0, y1)  
    x2 = min(pil_img.width, x2)  
    y2 = min(pil_img.height, y2)  
    gray = cv2.cvtColor(np.asarray(pil_img.crop((x1, y1, x2, y2))).astype(np.uint8), cv2.COLOR_RGB2GRAY)  
    _, thr = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)  
    mask_dark = thr == 0  
    mask_brite = thr == 255  
    ink_mask = mask_dark if mask_dark.sum() < mask_brite.sum() else mask_brite  
    if not ink_mask.any():  
        logger.info("  → Using black as default")  
        return (0, 0, 0)  
    median_luma = float(np.median(gray[ink_mask]))  
    color = (255, 255, 255) if median_luma > 128 else (0, 0, 0)  
    logger.info(f"  → Chosen color: {color} (median luma: {median_luma:.1f})")  
    return color  
  
def _recolour_logo(rgba: np.ndarray, rgb: tuple[int, int, int]) -> np.ndarray:  
    logger.info(f"🎨 Recoloring logo to RGB: {rgb}")  
    col = np.array(rgb, dtype=np.uint8)  
    out = rgba.copy()  
    m = out[..., 3] > 20  
    out[m, :3] = col  
    return out  
  
def _shrink_vertically(pil_img: Image.Image, box: tuple, margin: int = 3) -> tuple:  
    logger.info(f"📏 Shrinking box vertically: {box}")  
    x1, y1, x2, y2 = map(int, box)  
    roi = cv2.cvtColor(np.asarray(pil_img.crop((x1, y1, x2, y2))), cv2.COLOR_RGB2GRAY)  
    _, bw = cv2.threshold(roi, 230, 255, cv2.THRESH_BINARY_INV)  
    ys = np.where(bw.sum(axis=1) > 0)[0]  
    if ys.size == 0:  
        logger.info("  → No content found, keeping original box")  
        return box  
    new_y1 = y1 + max(0, ys.min() - margin)  
    new_y2 = y1 + min(roi.shape[0], ys.max() + margin)  
    new_box = (x1, new_y1, x2, new_y2)  
    logger.info(f"  → Shrunk to: {new_box}")  
    return new_box  
  
def _kernel(side: int, pct: float, mx: int, odd=True) -> int:  
    k = max(3, min(mx, int(side * pct)))  
    return k + 1 if odd and k % 2 == 0 else k  
  
def _create_wipe_mask(cv: np.ndarray, box):  
    x1, y1, x2, y2 = map(int, box)  
    pad = _kernel(min(x2 - x1, y2 - y1), PAD_PCT, MAX_PAD_PX, odd=False)  
    wipe = _expand_box((x1, y1, x2, y2), pad, cv.shape[1], cv.shape[0])  
    mask = np.zeros(cv.shape[:2], np.uint8)  
    cv2.rectangle(mask, (wipe[0], wipe[1]), (wipe[2], wipe[3]), 255, -1)  
    dil = _kernel(min(x2 - x1, y2 - y1), DILATE_PCT, MAX_DILATE_PX)  
    mask = cv2.dilate(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (dil, dil)), 1)  
    rad = _kernel(min(x2 - x1, y2 - y1), INPAINT_PCT, MAX_INPAINT_RADIUS, odd=False)  
    return mask, wipe, rad  
  
def _alpha_overlay(dst: np.ndarray, src_rgba: np.ndarray, top: int, left: int):  
    top, left = int(top), int(left)  
    h, w = src_rgba.shape[:2]  
    if (top < 0 or left < 0 or top + h > dst.shape[0] or left + w > dst.shape[1]):  
        return dst  
    roi = dst[top: top + h, left: left + w].astype(np.float32)  
    src_rgb = src_rgba[..., :3].astype(np.float32)  
    alpha = src_rgba[..., 3].astype(np.float32) / 255.0  
    alpha = cv2.GaussianBlur(alpha, (5, 5), 0)  
    if alpha.ndim == 2:  
        alpha = alpha[..., None]  
    dst[top: top + h, left: left + w] = (alpha * src_rgb + (1 - alpha) * roi).astype(np.uint8)  
    return dst  
  
def wipe_and_paste_generic(pil_img: Image.Image, box, key: str, tint: tuple[int,int,int] | None = None) -> Image.Image:  
    cv = cv2.cvtColor(np.asarray(pil_img), cv2.COLOR_RGB2BGR)  
    mask, wipe, rad = _create_wipe_mask(cv, box)  
    cv = smart_inpaint(cv, mask)  
    x1, y1, x2, y2 = wipe  
    logo = _prep_logo(key, x2 - x1, y2 - y1)  
    if tint is not None:  
        logo = _recolour_logo(logo, tint)  
    lbgr, alpha = logo[..., :3], logo[..., 3]  
    if alpha.max() == 0:  
        g = cv2.cvtColor(lbgr, cv2.COLOR_BGR2GRAY)  
        alpha = cv2.threshold(g, 10, 255, cv2.THRESH_BINARY)[1]  
    cx, cy = x1 + (x2 - x1) // 2, y1 + (y2 - y1) // 2  
    ph, pw = cv.shape[:2]  
    cx = int(np.clip(cx, lbgr.shape[1] // 2, pw - (lbgr.shape[1] - lbgr.shape[1] // 2)))  
    cy = int(np.clip(cy, lbgr.shape[0] // 2, ph - (lbgr.shape[0] - lbgr.shape[0] // 2)))  
    blended = False  
    before = cv[y1:y2, x1:x2].copy()  
    for mode in SEAMLESS_CLONE_TRIES:  
        try:  
            trial = cv2.seamlessClone(lbgr, cv, alpha, (cx, cy), mode)  
            if np.mean(cv2.absdiff(trial[y1:y2, x1:x2], before)) > 5:  
                cv, blended = trial, True  
                break  
        except cv2.error:  
            pass  
    if not blended:  
        cv = _alpha_overlay(cv, logo, cy - lbgr.shape[0] // 2, cx - lbgr.shape[1] // 2)  
    return Image.fromarray(cv2.cvtColor(cv, cv2.COLOR_BGR2RGB))  
  
def wipe_and_paste(img: Image.Image, box):  
    fg = _dominant_text_colour_simplified(img, box)  
    return wipe_and_paste_generic(img, box, "hitachi_inspire", fg)  
  
def wipe_and_paste_energy(img: Image.Image, box):  
    return wipe_and_paste_generic(img, box, "hitachi_energy", None)  
  
#######DOCX & PDF Processing ###### 
def _bytes2pil(data: bytes):  
    try:  
        im = Image.open(io.BytesIO(data))  
        im.load()  
        return im.convert("RGB")  
    except Exception:  
        return None  
  
def _pil2bytes(img: Image.Image, ext: str) -> bytes:  
    fmt = {"png":"PNG","jpg":"JPEG","jpeg":"JPEG","bmp":"BMP","tif":"TIFF","tiff":"TIFF"}.get(ext.lstrip(".").lower(),"PNG")  
    buf = io.BytesIO()  
    params = {"quality":92} if fmt=="JPEG" else {}  
    img.save(buf, fmt, **params)  
    return buf.getvalue()  
  
def _scale_for_detection(pil: Image.Image, target_short_side: int = 800) -> tuple[list[Image.Image], list[float]]:  
    w, h = pil.size  
    short = min(w, h)  
    if short >= target_short_side:  
        return [pil], [1.0]  
    scales, imgs = [1.0], [pil]  
    factor = target_short_side / short  
    steps = max(1, int(math.log(factor, 2)))  
    for i in range(steps):  
        sc = 2 ** (i + 1)  
        new_w = int(w * sc)  
        new_h = int(h * sc)  
        big = pil.resize((new_w, new_h), Image.LANCZOS)  
        imgs.append(big)  
        scales.append(1.0 / sc)  
    return imgs, scales  
  
def _blank_bitmap(width: int, height: int, ext: str, style: str = DELETE_STYLE) -> bytes:  
    if style == "transparent":  
        mode = "RGBA"  
        colour = (0, 0, 0, 0)  
    else:  # "white"  
        mode = "RGB"  
        colour = (255, 255, 255)  
    img = Image.new(mode, (width, height), colour)  
    return _pil2bytes(img, ext)  
  
def _process_bitmap(data: bytes, ext: str, dbg_name: str | None = None) -> bytes:  
    pil_orig = _bytes2pil(data)  
    if pil_orig is None:  
        return data  
  
    imgs, inv_scales = _scale_for_detection(pil_orig)  
    detections: list[dict] = []  
    for img, inv_sc in zip(imgs, inv_scales):  
        detections = final_logo_boxes(img)  
        if not any("energy" in d["label"].lower() for d in detections):  
            detections.extend(detect_logo_only_page(img))  
        if detections:  
            for d in detections:  
                x1, y1, x2, y2 = d["box"]  
                d["box"] = (int(x1 * inv_sc), int(y1 * inv_sc), int(x2 * inv_sc), int(y2 * inv_sc))  
            break  
  
    if not detections:  
        return data  
  
    for d in detections:  
        if "energy" in d["label"].lower():  
            d["box"] = _extend_hitachi_energy_box(d["box"], pil_orig)  
  
    pil = pil_orig  
    for d in detections:  
        d["box"] = _shrink_vertically(pil, d["box"])  
        if "energy" in d["label"].lower():  
            if DOCX_FORCE_DELETE_ENERGY:  
                blank = _blank_bitmap(pil_orig.width, pil_orig.height, ext)  
                if DEBUG:  
                    print(f"   ↻  {dbg_name} – bitmap removed")  
                return blank  
            else:  
                pil = wipe_and_paste_energy(pil, d["box"])  
        else:  
            pil = wipe_and_paste(pil, d["box"])  
    return _pil2bytes(pil, ext)  
  
def process_docx_step2(docx_bytes: bytes) -> bytes:  
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as zin:  
        names = zin.namelist()  
        original_bytes = {n: zin.read(n) for n in names}  
    output_buffer = io.BytesIO()  
    with zipfile.ZipFile(output_buffer, "w", compression=zipfile.ZIP_DEFLATED) as zout:  
        for item_name in names:  
            data = original_bytes[item_name]  
            if item_name.startswith("word/media/"):  
                ext = Path(item_name).suffix.lower()  
                try:  
                    if ext in DOCX_BITMAP_EXTS:  
                        data = _process_bitmap(data, ext, item_name)  
                except Exception as exc:  
                    if DEBUG:  
                        print("   ⚠ media processing error:", exc)  
            zout.writestr(item_name, data)  
    if DEBUG:  
        print("✓ Step 2 completed - logo embedding handled in Step 1")  
    return output_buffer.getvalue()  
  
#######PDF FONT Rebranding ###### 
TOL = 1  # rounding error in degrees  
_TJ = re.compile(rb"$(?:[^]]+?)$\s*TJ|$.*?$\s*Tj", re.S)  
  
def cw(dir_tuple):  
    cos_v, sin_v = dir_tuple  
    raw = (-math.degrees(math.atan2(sin_v, cos_v))) % 360  
    snap = (round(raw / 90) * 90) % 360  
    if abs(raw - snap) > TOL:  
        return None  
    if snap in (90, 270):  
        snap = (snap + 180) % 360  
    return int(snap)  
  
def strip_ops(p: fitz.Page):  
    doc = p.parent  
    for xref in p.get_contents():  
        doc.update_stream(xref, _TJ.sub(b"", doc.xref_stream(xref)), compress=1)  
  
def re_font(page: fitz.Page, tag: str):  
    spans: List[dict] = []  
    for b in page.get_text("dict")["blocks"]:  
        if b["type"]:  
            continue  
        for ln in b["lines"]:  
            for sp in ln["spans"]:  
                sp["dir"] = ln.get("dir", (1.0, 0.0))  
                spans.append(sp)  
    if REMOVE_STRATEGY == "stream":  
        strip_ops(page)  
    else:  
        for sp in spans:  
            if not sp["text"].strip():  
                continue  
            r = fitz.Rect(sp["bbox"])  
            r.x0, r.y0, r.x1, r.y1 = r.x0 + 0.5, r.y0 + 0.5, r.x1 - 0.5, r.y1 - 0.5  
            page.add_redact_annot(r, fill=None)  
        page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)  
  
    if tag not in page.get_fonts():  
        try:  
            page.insert_font(fontname=tag, fontfile=str(FONT_FILE))  
        except Exception:  
            pass  
  
    page.clean_contents()  
    rgb = lambda c: ((c >> 16 & 255) / 255, (c >> 8 & 255) / 255, (c & 255) / 255)  
    for sp in spans:  
        if not sp["text"].strip():  
            continue  
        x, y = sp["origin"]  
        try:  
            page.insert_text(  
                (x, y),  
                sp["text"],  
                fontname=tag,  
                fontsize=max(sp["size"] + SIZE_DELTA, 1),  
                fontfile=str(FONT_FILE),  
                color=rgb(sp["color"]),  
                rotate=cw(sp["dir"]),  
                overlay=True,  
            )  
        except Exception:  
            page.insert_text(  
                (x, y),  
                sp["text"],  
                fontsize=max(sp["size"] + SIZE_DELTA, 1),  
                color=rgb(sp["color"]),  
                rotate=cw(sp["dir"]),  
                overlay=True,  
            )  
  
def process_pdf_step2(pdf_stream: io.BytesIO) -> io.BytesIO:  
    doc = fitz.open(stream=pdf_stream, filetype="pdf")  
    for pno, page in enumerate(doc):  
        if ENABLE_PDF_FONT_REBRAND:  
            re_font(page, "HZ")  
  
        pix = page.get_pixmap(dpi=300, alpha=False)  
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)  
  
        detections = final_logo_boxes(img)  
        if not any("hitachi energy" in d["label"].lower() for d in detections):  
            detections.extend(detect_logo_only_page(img))  
  
        for d in detections:  
            if d["label"].lower() == "hitachi energy":  
                d["box"] = _extend_hitachi_energy_box(d["box"], img)  
  
        for d in detections:  
            d["box"] = _shrink_vertically(img, d["box"])  
            if "energy" in d["label"].lower():  
                img = wipe_and_paste_energy(img, d["box"])  
            else:  
                img = wipe_and_paste(img, d["box"])  
  
        buf = io.BytesIO()  
        img.save(buf, "PNG")  
        page.clean_contents()  
        page.insert_image(page.rect, stream=buf.getvalue())  
  
    output_stream = io.BytesIO()  
    doc.save(output_stream, garbage=4, deflate=True, clean=True)  
    doc.close()  
    output_stream.seek(0)  
    return output_stream  
  
#######DOCX TYPOGRAPHY Rebranding######  
def is_valid_docx(path: Path | str) -> bool:  
    if not zipfile.is_zipfile(path):  
        return False  
    try:  
        with zipfile.ZipFile(path) as z:  
            return "[Content_Types].xml" in z.namelist()  
    except zipfile.BadZipFile:  
        return False  
  
def _check_license(ttf: pathlib.Path) -> None:  
    try:  
        if TTFont and TTFont(str(ttf))["OS/2"].fsType & 0b10:  
            print(f"Warning: Font license may restrict embedding: {ttf}")  
    except Exception:  
        pass  
  
def _obfuscate(ttf: pathlib.Path) -> tuple[bytes, str]:  
    guid, rev = uuid.uuid4(), bytes.fromhex(uuid.uuid4().hex)[::-1]  
    buf = bytearray(ttf.read_bytes())  
    for i in range(16):  
        buf[i] ^= rev[i]  
        buf[i + 16] ^= rev[i]  
    return bytes(buf), str(guid).upper()  
  
def _iter_parts(pkg: pathlib.Path):  
    patterns = (  
        "document.xml", "styles.xml", "numbering.xml",  
        "comments*.xml", "footnotes.xml", "endnotes.xml",  
        "header*.xml", "footer*.xml", "settings.xml",  
    )  
    for pat in patterns:  
        yield from (pkg / "word").glob(pat)  
  
def _half_points(pt: float) -> int:  
    return int(round(pt * 2))  
  
def _points_from_half_points(half_pts: int) -> float:  
    return half_pts / 2.0  
  
def _should_reduce_size(rpr) -> bool:  
    sz_el = rpr.find("w:sz", namespaces=NS)  
    if sz_el is None:  
        return False  
    try:  
        half_pts = int(sz_el.get(qn("w:val")))  
        current_pt = _points_from_half_points(half_pts)  
        return current_pt >= MIN_SIZE_THRESHOLD_PT  
    except (TypeError, ValueError):  
        return False  
  
def _get_reduction_amount(current_pt: float) -> float:  
    if current_pt < MIN_SIZE_THRESHOLD_PT:  
        return 0.0  
    elif current_pt > REDUCE_THRESHOLD_PT:  
        return REDUCE_BY_PT_LARGE  
    else:  
        return REDUCE_BY_PT_SMALL  
  
def _apply_smart_size_reduction(rpr) -> None:  
    sz_el = rpr.find("w:sz", namespaces=NS)  
    szcs_el = rpr.find("w:szCs", namespaces=NS)  
    for node in (sz_el, szcs_el):  
        if node is None:  
            continue  
        try:  
            old_half_pts = int(node.get(qn("w:val")))  
            current_pt = _points_from_half_points(old_half_pts)  
            reduction_pt = _get_reduction_amount(current_pt)  
            if reduction_pt > 0:  
                new_pt = max(MIN_SIZE_THRESHOLD_PT, current_pt - reduction_pt)  
                new_half_pts = _half_points(new_pt)  
                node.set(qn("w:val"), str(new_half_pts))  
        except (TypeError, ValueError):  
            continue  
  
def _is_bullet_font(rpr) -> bool:  
    if rpr is None:  
        return False  
    rf = rpr.find("w:rFonts", namespaces=NS)  
    if rf is None:  
        return False  
    for attr in ("ascii", "hAnsi", "cs", "eastAsia"):  
        if rf.get(qn(f"w:{attr}")) in PRESERVE_BULLET_FONTS:  
            return True  
    return False  
  
def _touch_rfonts(rpr, *, preserve_special: bool = False) -> None:  
    if rpr is None or (preserve_special and _is_bullet_font(rpr)):  
        return  
    rf = rpr.find("w:rFonts", namespaces=NS)  
    if rf is None:  
        rf = etree.SubElement(rpr, qn("w:rFonts"))  
    for theme_attr in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):  
        rf.attrib.pop(qn(f"w:{theme_attr}"), None)  
    for attr in ("ascii", "hAnsi", "cs", "eastAsia"):  
        if preserve_special and rf.get(qn(f"w:{attr}")) in PRESERVE_BULLET_FONTS:  
            continue  
        rf.set(qn(f"w:{attr}"), TARGET_NAME)  
  
def _patch_part(xml: pathlib.Path) -> None:  
    tree = etree.parse(str(xml), etree.XMLParser(remove_blank_text=True))  
    for run in tree.xpath(".//w:r", namespaces=NS):  
        rpr = run.find("w:rPr", namespaces=NS)  
        text_content = "".join(run.xpath("./w:t/text()", namespaces=NS))  
        bullet_like = any(ch in UNICODE_BULLETS for ch in text_content)  
        preserve_flag = bullet_like or (rpr is not None and _is_bullet_font(rpr))  
        _touch_rfonts(rpr, preserve_special=preserve_flag)  
        if rpr is not None and not preserve_flag and _should_reduce_size(rpr):  
            _apply_smart_size_reduction(rpr)  
    tree.write(str(xml), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _patch_styles(xml: pathlib.Path) -> None:  
    tree = etree.parse(str(xml), etree.XMLParser(remove_blank_text=True))  
    root = tree.getroot()  
    dd = root.find(".//w:docDefaults/w:rPrDefault/w:rPr", namespaces=NS)  
    if dd is not None:  
        _touch_rfonts(dd)  
        if _should_reduce_size(dd):  
            _apply_smart_size_reduction(dd)  
    for rpr in root.xpath(".//w:style//w:rPr", namespaces=NS):  
        _touch_rfonts(rpr)  
        if _should_reduce_size(rpr):  
            _apply_smart_size_reduction(rpr)  
    tree.write(str(xml), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _patch_numbering(xml: pathlib.Path) -> None:  
    tree = etree.parse(str(xml), etree.XMLParser(remove_blank_text=True))  
    for lvl in tree.xpath(".//w:lvl", namespaces=NS):  
        numfmt = lvl.find("w:numFmt", namespaces=NS)  
        pic = lvl.find("w:lvlPicBulletId", namespaces=NS)  
        is_bullet = numfmt is not None and numfmt.get(qn("w:val")) == "bullet"  
        if pic is not None:  
            continue  
        for rpr in lvl.xpath(".//w:rPr", namespaces=NS):  
            if is_bullet or _is_bullet_font(rpr):  
                continue  
            _touch_rfonts(rpr, preserve_special=True)  
            if _should_reduce_size(rpr):  
                _apply_smart_size_reduction(rpr)  
    tree.write(str(xml), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _ensure_mime(pkg: pathlib.Path) -> None:  
    ct = pkg / "[Content_Types].xml"  
    tree = etree.parse(str(ct))  
    root = tree.getroot()  
    tag = f"{{{CT}}}Default"  
    if not any(n.get("Extension") == "odttf" for n in root.findall(tag)):  
        etree.SubElement(root, tag, Extension="odttf", ContentType="application/vnd.ms-package.obfuscated-opentype")  
        tree.write(str(ct), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _write_font(pkg: pathlib.Path, blob: bytes, guid: str) -> str:  
    p = pkg / "word" / "fonts"  
    p.mkdir(parents=True, exist_ok=True)  
    (p / f"{guid}.odttf").write_bytes(blob)  
    return f"fonts/{guid}.odttf"  
  
def _add_font_rel(pkg: pathlib.Path, tgt: str) -> str:  
    rels = pkg / "word" / "_rels" / "fontTable.xml.rels"  
    rels.parent.mkdir(exist_ok=True)  
    if rels.exists():  
        tree = etree.parse(str(rels)); root = tree.getroot()  
    else:  
        root = etree.Element("Relationships", xmlns="http://schemas.openxmlformats.org/package/2006/relationships")  
    rid = f"rId{uuid.uuid4().int >> 112}"  
    etree.SubElement(  
        root, "Relationship",  
        Id=rid,  
        Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/font",  
        Target=tgt,  
    )  
    etree.ElementTree(root).write(str(rels), encoding="utf-8", xml_declaration=True, standalone="yes")  
    return rid  
  
def _update_font_table(pkg: pathlib.Path, rid: str, guid: str) -> None:  
    ftab = pkg / "word" / "fontTable.xml"  
    if ftab.exists():  
        tree = etree.parse(str(ftab)); root = tree.getroot()  
    else:  
        root = etree.Element(qn("w:fonts"), nsmap=NS)  
    for old in root.xpath(f".//w:font[@w:name='{TARGET_NAME}']", namespaces=NS):  
        root.remove(old)  
    font = etree.SubElement(root, qn("w:font"), **{qn("w:name"): TARGET_NAME})  
    etree.SubElement(  
        font, qn("w:embedRegular"),  
        **{f"{{{R}}}id": rid, qn("w:fontKey"): f"{{{guid}}}"}  
    )  
    for tag, val in (("charset","00"),("family","auto"),("pitch","variable")):  
        etree.SubElement(font, qn(f"w:{tag}"), **{qn("w:val"): val})  
    etree.ElementTree(root).write(str(ftab), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _flag_embed(pkg: pathlib.Path) -> None:  
    s = pkg / "word" / "settings.xml"  
    if not s.exists():  
        return  
    tree = etree.parse(str(s)); root = tree.getroot()  
    if root.find("w:embedTrueTypeFonts", namespaces=NS) is None:  
        etree.SubElement(root, qn("w:embedTrueTypeFonts"))  
        tree.write(str(s), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def process_docx_typography(docx_bytes: bytes) -> bytes:  
    if not ENABLE_DOCX_FONT_REBRAND or etree is None:  
        return docx_bytes  
    try:  
        with tempfile.TemporaryDirectory() as td:  
            pkg = pathlib.Path(td)  
            with zipfile.ZipFile(io.BytesIO(docx_bytes)) as z:  
                z.extractall(pkg)  
  
            for xml in _iter_parts(pkg):  
                {"styles.xml": _patch_styles, "numbering.xml": _patch_numbering}.get(xml.name, _patch_part)(xml)  
  
            if pathlib.Path(VERDANA_TTF).exists():  
                _check_license(pathlib.Path(VERDANA_TTF))  
                blob, guid = _obfuscate(pathlib.Path(VERDANA_TTF))  
                rid = _add_font_rel(pkg, _write_font(pkg, blob, guid))  
                _update_font_table(pkg, rid, guid)  
                _flag_embed(pkg)  
                _ensure_mime(pkg)  
  
            output_buffer = io.BytesIO()  
            with zipfile.ZipFile(output_buffer, "w", compression=zipfile.ZIP_DEFLATED) as zout:  
                for file_path in pkg.rglob("*"):  
                    if file_path.is_file():  
                        arcname = str(file_path.relative_to(pkg))  
                        zout.write(file_path, arcname)  
            output_buffer.seek(0)  
            return output_buffer.getvalue()  
    except Exception as e:  
        if DEBUG:  
            print(f"Typography processing error: {e}")  
        return docx_bytes  
  
#######Azure Blob Helpers ###### 
def _download_inputs_from_blob(local_dir: Path) -> List[Path]:  
    downloaded: List[Path] = []  
    if BlobServiceClient is None:  
        logger.error("Azure Blob SDK not available. Please install azure-storage-blob.")  
        return downloaded  
    try:  
        service = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)  
        container = service.get_container_client(AZURE_CONTAINER_INPUT)  
        blobs = container.list_blobs()  
        for blob in blobs:  
            name = blob.name  
            if not name.lower().endswith((".pdf", ".docx")):  
                continue  
            target = local_dir / Path(name).name  
            ensure_dir(local_dir)  
            logger.info(f"⬇️ Downloading blob: {name} → {target}")  
            with open(target, "wb") as f:  
                stream = container.download_blob(name)  
                f.write(stream.readall())  
            downloaded.append(target)  
    except Exception as e:  
        logger.error(f"Failed to download from Azure Blob: {e}")  
    return downloaded  
  
def _upload_to_blob(file_path: Path) -> None:  
    if BlobServiceClient is None:  
        logger.error("Azure Blob SDK not available. Please install azure-storage-blob.")  
        return  
    try:  
        service = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)  
        container = service.get_container_client(AZURE_CONTAINER_OUTPUT)  
        try:  
            container.create_container()  
        except Exception:  
            pass  
        logger.info(f"⬆️ Uploading {file_path.name} to container {AZURE_CONTAINER_OUTPUT}")  
        content_settings = None  
        if ContentSettings is not None:  
            if file_path.suffix.lower() == ".pdf":  
                content_settings = ContentSettings(content_type="application/pdf")  
            elif file_path.suffix.lower() == ".docx":  
                content_settings = ContentSettings(  
                    content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"  
                )  
        with open(file_path, "rb") as f:  
            container.upload_blob(  
                name=file_path.name,  
                data=f,  
                overwrite=True,  
                content_settings=content_settings,  
            )  
    except Exception as e:  
        logger.error(f"Failed to upload to Azure Blob: {e}")  
  
#######Consolidated Processing Wrappers ###### 
def process_pdf_consolidated1(  
    pdf_path: Path,  
    output_path: Path,  
    *,  
    template_cover: bool = False,  
    template_img: Optional[np.ndarray] = None,  
    debug: bool = DEBUG,  
) -> None:  
    with open(pdf_path, "rb") as f:  
        in_stream = io.BytesIO(f.read())  
    ####### Step 1: Pattern Detection & Removal###### 
    interim = process_pdf_pipeline_inspire(  
        in_stream,  
        template_cover=template_cover,  
        template_img=template_img,  
        debug=debug,  
    )  
    ####### Step 2: Logo Detection, Replacement & Typography ###### 
    final_stream = process_pdf_step2(interim)  
    with open(output_path, "wb") as out:  
        out.write(final_stream.getvalue())  
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file1 = Path(OUTPUT_DIR) / f"{Path(pdf_path).stem}_{timestamp}_rebranded.pdf"
    with open(output_file1, "wb") as out1:  
        out1.write(final_stream.getvalue())

    logger.info(f"✅ PDF written: {output_path}")  
  
def process_docx_consolidated1(  
    docx_path: Path,  
    output_path: Path,  
    *,  
    template_cover: bool = False,  
    template_img: Optional[np.ndarray] = None,  
    debug: bool = DEBUG,  
) -> None:  
    with open(docx_path, "rb") as f:  
        in_bytes = f.read()  
    ####### Step 1: Pattern Detection & Removal ###### 
    step1_bytes = process_docx_pipeline_inspire_new(  
        in_bytes,  
        template_cover=template_cover,  
        template_img=template_img,  
    )  
    ####### Step 2: Logo Detection & Replacement  ######
    step2_bytes = process_docx_step2(step1_bytes)  
    ####### Step 3: Typography Rebranding  ######
    final_bytes = process_docx_typography(step2_bytes)  
    with open(output_path, "wb") as out:  
        out.write(final_bytes)  
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file1 = Path(OUTPUT_DIR) / f"{Path(docx_path).stem}_{timestamp}_rebranded.docx"
    with open(output_file1, "wb") as out1:  
        out1.write(final_bytes)
    logger.info(f"✅ DOCX written: {output_path}")  
  
# ─────────────────────────── Main Consolidated Pipeline ──────────────────────  
def main_consolidated() -> None:  
     
    print("=" * 80)  
    print("           CONSOLIDATED HITACHI REBRANDING PIPELINE")  
    print("    Step 1: Pattern Detection & Removal")  
    print("    Step 2: Logo Detection, Replacement & Typography")  
    print("    FIXED: PDF Black Logos + DOCX Floating Logo Placement")  
    print("=" * 80)  
  
    ensure_dir(OUTPUT_DIR)  
  
    ####### Load template image if available ###### 
    template_path = Path("new_cover.png")  
    template_img = cv2.imread(str(template_path), cv2.IMREAD_COLOR) if template_path.exists() else None  
    template_flag = False  # Set to True when you want to overlay a clean cover  
  
    ####### Process all files in input directory  ######
    if USE_AZURE_BLOB:  
        tmp_in = Path(tempfile.mkdtemp(prefix="az_in_"))  
        local_inputs = _download_inputs_from_blob(tmp_in)  
        pdf_files = [p for p in local_inputs if p.suffix.lower() == ".pdf"]  
        docx_files = [p for p in local_inputs if p.suffix.lower() == ".docx"]  
    else:  
        inp = Path(INPUT_DIR)  
        if not inp.exists():  
            print(f"✘ Input directory not found: {INPUT_DIR}")  
            return  
        pdf_files = list(inp.glob("*.pdf"))  
        docx_files = list(inp.glob("*.docx"))  
  
    if not (pdf_files or docx_files):  
        print("✘ No PDF / DOCX files to process")  
        return  
  
    print(f"Found  {len(pdf_files)}  PDF   +   {len(docx_files)}  DOCX")  
    print()  
  
    ####### Process PDF files ###### 
    for pdf_file in pdf_files:  
        output_file = Path(OUTPUT_DIR) / f"{pdf_file.stem}_rebranded.pdf"  
        try:  
            process_pdf_consolidated1(  
                pdf_file,  
                output_file,  
                template_cover=template_flag,  
                template_img=template_img,  
                debug=DEBUG,  
            )  
        except Exception as e:  
            print(f"✘ Error processing {pdf_file.name}: {e}")  
            if DEBUG:  
                import traceback  
                traceback.print_exc()  
  
    ####### Process DOCX files ###### 
    for docx_file in docx_files:  
        output_file = Path(OUTPUT_DIR) / f"{docx_file.stem}_rebranded.docx"  
        try:  
            process_docx_consolidated1(  
                docx_file,  
                output_file,  
                template_cover=template_flag,  
                template_img=template_img,  
                debug=DEBUG,  
            )  
        except Exception as e:  
            print(f"✘ Error processing {docx_file.name}: {e}")  
            if DEBUG:  
                import traceback  
                traceback.print_exc()  
  
    if USE_AZURE_BLOB:  
        for prod in Path(OUTPUT_DIR).glob("*_rebranded.*"):  
            _upload_to_blob(prod)  
            if not KEEP_LOCAL_COPY:  
                prod.unlink()  
  
    print()  
    print("=" * 80)  
    print("✓ FIXED PIPELINE COMPLETED!")  
    print(f"  • PDF: Simplified black color for all Hitachi Inspire logos")  
    print(f"  • DOCX: Floating logo placement (no content shift)")  
    print(f"  • Cover page logo: {'ENABLED' if ADD_COVER_LOGO_DOCX else 'DISABLED'}")  
    if USE_AZURE_BLOB:  
        print(f"  Results uploaded to Azure container  “{AZURE_CONTAINER_OUTPUT}”.")  
    else:  
        print(f"  Results written to local folder  {OUTPUT_DIR}")  
    print("=" * 80)  
  
  
if __name__ == "__main__":  
    USE_AZURE_BLOB = False  
    KEEP_LOCAL_COPY = True  
    main_consolidated()  