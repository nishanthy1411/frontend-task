# hitachi_rebranding_final_original_cp_updated_V2.py  
from __future__ import annotations  
  
import io  
import logging  
import math  
import os  
import sys  
import warnings  
import zipfile  
import tempfile  
import uuid  
import inspect  
import pathlib  
import re  
import datetime  
from pathlib import Path  
from typing import Dict, List, Tuple, Set, Optional  
logging.disable(logging.CRITICAL) 
 
try:  
    from azure.storage.blob import BlobServiceClient    
except ImportError:  
    BlobServiceClient = None    
  
  
try:  
    from azure.storage.blob import ContentSettings    
except Exception:  
    ContentSettings = None    
  
##################CONFIGURATION#################  

INPUT_DIR = "input_branding2"  
OUTPUT_DIR = "output_branding2"  
  

USE_AZURE_BLOB: bool = True    
AZURE_STORAGE_CONNECTION_STRING = os.getenv(  
    "AZURE_STORAGE_CONNECTION_STRING",  
    "DefaultEndpointsProtocol=https;AccountName=saaicoepoc011;AccountKey=W+P65IDd03XhMnpZqQ7LMwnGdOfTjgLkIHyh7mdX1AyhY+bZe4ZklFoRtLFFW+Y+SeOn6SFZ3xKH+ASt3tupsg==;EndpointSuffix=core.windows.net",  
)  
AZURE_CONTAINER_INPUT = os.getenv("AZURE_CONTAINER_INPUT", "rebranding-input")  
AZURE_CONTAINER_OUTPUT = os.getenv("AZURE_CONTAINER_OUTPUT", "rebranding-output")  
KEEP_LOCAL_COPY = True  # still write files to OUTPUT_DIR unless --no-local-copy  
  

logging.basicConfig(  
    level=logging.INFO,  
    format="%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s",  
    handlers=[  
        logging.StreamHandler(sys.stdout),  
        # logging.FileHandler("/tmp/hitachi_rebranding.log", mode="a")
        logging.FileHandler("./hitachi_rebranding.log", mode="a")  
        # if os.path.exists("/tmp")
        if os.path.exists("./")  
        else logging.StreamHandler(sys.stdout),  
    ],  
)  
logger = logging.getLogger(__name__)  
  
################## Add environment detection  #################
IS_AZURE = os.getenv("WEBSITE_SITE_NAME") is not None  
IS_LOCAL = not IS_AZURE  
logger.info(f"🚀 APPLICATION STARTUP - Environment: {'Azure WebApp' if IS_AZURE else 'Local'}")  
logger.info(f"📍 Current working directory: {os.getcwd()}")  
logger.info(f"📁 Python executable: {sys.executable}")  
logger.info(f"🔧 Python path: {sys.path}")  
  
warnings.filterwarnings("ignore", category=UserWarning)  
os.environ["TOKENIZERS_PARALLELISM"] = "false"  
  
##################CORE DEPENDENCIES################# 
try:  
    import cv2  
    import fitz    
    import numpy as np  
    import requests  
    from PIL import Image  
    import pytesseract  
    from pytesseract import Output  
    logger.info("✅ Core dependencies imported successfully")  
except ImportError as e:  
    logger.error(f"❌ Failed to import core dependencies: {e}")  
    raise  
  
 
try:  
    import huggingface_hub as _hf  
    if not hasattr(_hf, "cached_download"):  
        from huggingface_hub import hf_hub_download  
        _hf.cached_download = hf_hub_download  
    logger.info("✅ HuggingFace Hub imported")  
except ImportError:  
    logger.warning("⚠️ HuggingFace Hub not available")  
    pass  
  
############################## AZURE GPT-Image-1 ##############################  
AZURE_OPENAI_KEY = os.getenv(  
    "AZURE_OPENAI_KEY",  
    "DYHNOW22gxruqjtpiFCpec1ftaJKb96Tvex2ue26gnVrwBNlvKwQJQQJ99BEACMsfrFXJ3w3AAAAACOG1QC8",  
)  
AZURE_OPENAI_ENDPOINT = "https://ramku-mb6ic4fp-westus3.cognitiveservices.azure.com"  
AZURE_OPENAI_DEPLOYMENT = "gpt-image-1"  
AZURE_OPENAI_API_VERSION = "2025-04-01-preview"  
INPAINT_PROMPT = (  
    "Fill the masked area so it blends seamlessly with the surrounding page. "  
    "Match colours, shading and texture. "  
    "Do not introduce any additional elements."  
)  
INPAINT_PROMPT1 = (  
    "Fill the masked area so it blends seamlessly/perfectly with the surrounding page without any border/patch lines around the area. "  
    "Match exact surrounding background colours, pattern, shading and texture making it perfectly indinstiguishable with respect to the background of the page irrespective of the complexity. "  
    "Do not introduce any additional elements. There should not be any wiped/blurr/halo effect/texture"  
)  
INPAINT_PROMPT3 = (  
    "Reconstruct ONLY the pixels inside the mask so the area is completely "  
    "indistinguishable from the immediately surrounding background. "  
    "Seamlessly continue the exact colours, lighting, grain, perspective and "  
    "texture (grass hillside / natural landscape) that are already present. "  
    "Remove every trace of the previous logo. "  
    "Do NOT introduce or write any text, shapes, watermarks, objects or new "  
    "details. Do NOT soften, blur, smudge or stylise the image. "  
    "Keep neighbouring pixels untouched and avoid visible seams, borders, "  
    "banding, tiling or repeating patterns. The result must look like the "  
    "original photograph with nothing ever placed there."  
)  
NEGATIVE_PROMPT = (  
    "text, letters, logos, symbols, pattern repetition, blurring, smearing, "  
    "halo, colour bands, low-resolution artefacts, watermark, patch border"  
)  
HTTP_TIMEOUT = 120  
ENABLE_AZURE_GPT_INPAINT = bool(AZURE_OPENAI_KEY)  
logger.info(f"🔑 Azure OpenAI Key configured: {bool(AZURE_OPENAI_KEY)}")  
  
############################## Stable-Diffusion Loader ########################  
_SD_PIPE = None  
try:  
    import torch  
    from diffusers import StableDiffusionInpaintPipeline  
    _SD_DEVICE = "cuda" if torch.cuda.is_available() else "cpu"  
    _DTYPE = torch.float16 if _SD_DEVICE == "cuda" else torch.float32  
    logger.info("Loading SD-Inpaint …")  
    _SD_PIPE = StableDiffusionInpaintPipeline.from_pretrained(  
        "runwayml/stable-diffusion-inpainting",  
        torch_dtype=_DTYPE,  
        safety_checker=None,  
        local_files_only=False,  
    ).to(_SD_DEVICE)  
    _SD_PIPE.enable_attention_slicing()  
    logger.info(f"✓  SD-Inpaint ready on {_SD_DEVICE}")  
except Exception as e:  
    logger.warning(f"Stable-Diffusion NOT available – fallback chain continues. ({e})")  
    _SD_PIPE = None  
  
############################## LaMa loader ###################################  
_LAMA_MODEL = None  
_LAMA_CFG_OBJ = None  
try:  
    from lama_cleaner.model_manager import ModelManager  
    from lama_cleaner.schema import Config as LamaConfig  
    _LAMA_MODEL = ModelManager(  
        name="lama",  
        device="cuda" if cv2.cuda.getCudaEnabledDeviceCount() else "cpu",  
        model_path="/home/site/wwwroot/big-lama.pt",  
    )  
    _LAMA_CFG_OBJ = LamaConfig(  
        ldm_steps=25,  
        hd_strategy="Crop",  
        hd_strategy_crop_margin=32,  
        hd_strategy_crop_trigger_size=800,  
        hd_strategy_resize_limit=2000,  
        prompt=INPAINT_PROMPT1,  
    )  
    logger.info(f"✓  LaMa ready on {_LAMA_MODEL.device}")  
except Exception as e:  
    logger.warning(f"LaMa NOT available – fallback to OpenCV. ({e})")  
    _LAMA_MODEL = None  
  
############################## Google GenAI (optional) ########################  
try:  
    from google import genai  
    from google.oauth2 import service_account  
    from google.genai.types import (  
        Image as VertexImage,  
        EditImageConfig,  
        RawReferenceImage,  
        MaskReferenceConfig,  
        MaskReferenceImage,  
    )  
    logger.info("✅ Google GenAI imported")  
except Exception:  
    logger.warning("⚠️ Google GenAI not available")  
    genai = None  
  
############################## DOCX Libraries ################################  
try:  
    import docx  
    from docx import Document  
    from docx.shared import Pt, Inches  
    from docx.oxml import OxmlElement  
    from docx.oxml.ns import qn, nsmap  
    from docx.enum.style import WD_STYLE_TYPE  
    from docx.opc.constants import RELATIONSHIP_TYPE as RT  
    logger.info("✅ DOCX libraries imported")  
except ImportError:  
    logger.warning("⚠️ DOCX libraries not available")  
    docx = None  
  
############################## Font tools ####################################  
try:  
    from fontTools.ttLib import TTFont  
    from lxml import etree  
    logger.info("✅ Font tools imported")  
except ImportError:  
    logger.warning("⚠️ Font tools not available")  
    TTFont = None  
    etree = None   
  
############################## User Settings/CONFIGURATION ####################  
DEBUG = True  
  
################## Step 1 Configuration (Pattern Detection)  #################
REF_ANGLE = 45.0  
ANGLE_TOLERANCE = 8.0  
MIN_STRIPE_LENGTH = 20.0  
MIN_TOTAL_LEN = 120.0  
MIN_STRIPES_IN_CLUSTER = 3 #3  
MAX_HV_RATIO = 0.4  
RED_MIN_R, RED_MAX_G, RED_MAX_B = 0.60, 0.35, 0.35  
CLEANUP_NON_COVER_LARGE_IMAGES = False  
########################  Non-Inspire Cover Overlay Settings  ########################  
NON_INSPIRE_OVERLAY_SCALE: int = 2        # render scale multiplier for overlay pixmaps  
SAVE_NON_INSPIRE_OVERLAY_DEBUG: bool = True  
NON_INSPIRE_OVERLAY_DIRNAME: str = "cover_overlays_non_inspire"  # debug save dir  
########################  RASTER INSPIRE DETECTION (robust)  ########################  

PDF_DETECT_RASTER_INSPIRE_ON_COVER: bool = True  
PDF_RASTER_INSP_DET_SCALE: int = 2  
PDF_RASTER_INSP_DEBUG_SAVE: bool = False  
PDF_RASTER_INSP_DEBUG_DIR: str = "raster_inspire_debug"  
PRINT_RASTER_INSPIRE_FLAGS: bool = True  
  
########### Stripe heuristics (tolerant; tuned for filled red parallelograms) ############ 
RASTER_STRIPE_MIN_COUNT: int = 3                    ##### ≥ 3 slanted red components  
RASTER_STRIPE_MIN_AREA_RATIO: float = 0.010         ##### total stripes area vs cover area  
RASTER_STRIPE_MIN_COMP_AREA_RATIO: float = 0.00035  ##### each component area vs cover area  
RASTER_STRIPE_MIN_ASPECT: float = 1.25              ##### elongated requirement (long/short)  
RASTER_STRIPE_ANGLE_LO: float = 22.0                ##### acceptable slant range  
RASTER_STRIPE_ANGLE_HI: float = 68.0  
  
# Gradient-orientation support (helps when stripes touch)  
RASTER_GRAD_DIAG_MIN: float = 0.30                  ##### diag energy vs total in mask  
RASTER_GRAD_STRONG: float = 0.42                    ##### strong diag energy (area check relaxed)  
RASTER_MIN_RED_AREA: float = 0.008                  ##### minimal red coverage sanity   
########Raster cover: targeted removal of old vector/text logos###########
RASTER_COVER_KILL_OLD_LOGOS: bool = True  
RASTER_LOGO_WIPE_PAD_PCT: float = 0.065          ##### padding around detected logo rect  
RASTER_LOGO_WIPE_MAX_PAD_PT: float = 22.0        ##### absolute pad cap in PDF points  
RASTER_LOGO_WIPE_MAX_AREA_RATIO: float = 0.18    ##### don’t wipe if box is too big vs cover  
RASTER_LOGO_WIPE_MAX_HEIGHT_RATIO: float = 0.33  ##### don’t wipe if box is too tall vs cover 

RASTER_STRIPE_MIN_COUNT = 3  
RASTER_STRIPE_MIN_AREA_RATIO = 0.008  
RASTER_STRIPE_MIN_COMP_AREA_RATIO = 0.00025  
RASTER_STRIPE_MIN_ASPECT = 1.20  
RASTER_STRIPE_ANGLE_LO = 24.0  
RASTER_STRIPE_ANGLE_HI = 66.0  
  
RASTER_GRAD_DIAG_MIN = 0.28  
RASTER_GRAD_STRONG   = 0.42  
  
RASTER_STRIPE_CONFIRM_PARALLEL_MIN = 3  
RASTER_ORI_HIST_PEAK_MIN           = 0.35  
RASTER_BIG_RED_ONE_MAX             = 0.86  
RASTER_BIG_RED_TWO_MAX             = 0.94  
RASTER_CONF_SCORE_MIN              = 0.62  
  
ANGLE_CLUSTER_MED_LO  = 32.0  
ANGLE_CLUSTER_MED_HI  = 58.0  
ANGLE_CLUSTER_STD_MAX = 10.0 
 
  
########## Conservative red thresholds to avoid warm landscapes being treated as "red"  ############
RASTER_RED_S_MIN: int = 115          ##### HSV saturation minimum for red  
RASTER_RED_V_MIN: int = 40           ####### HSV value minimum for red  
RASTER_LAB_A_MIN: int = 155          ######## Lab 'a' channel minimum for red  
RASTER_LAB_A_B_DELTA_MIN: int = 18   ######### Lab (a - b) must be clearly red, not yellow  
RASTER_YCRCB_CR_MIN: int = 150       ############ YCrCb: Cr strong  
RASTER_YCRCB_CR_CB_DELTA_MIN: int = 30  ######### YCrCb: Cr - Cb separation  
  
######## Guard against photos containing very large "red" regions ####### 
RASTER_MAX_RED_AREA: float = 0.22    ######## if red covers > 22% and orientation evidence is weak → reject  ########
  
####### Require orientation confirmation for strong-diagonal fallback  ##########
RASTER_STRONG_DIAG_FALLBACK: bool = False  ####### set True only if you really need the fallback  
  
######## Tighten the strong diagonal requirement a bit ######### 
RASTER_GRAD_STRONG: float = 0.50  ####### To reduce false positives in natural photos  
  
########### Make "big red" guard stricter (brand stripes are never a giant red mass)  ######
RASTER_BIG_RED_ONE_MAX: float = 0.86  
RASTER_BIG_RED_TWO_MAX: float = 0.80   
  
######### Confidence gate stays conservative  ###########
RASTER_CONF_SCORE_MIN: float = 0.66    
################## Step 2 Configuration (Logo Detection & Replacement)  #################
AZURE_VISION_KEY = "2Is5XLYBpspoD24Fbw2si6FfpM2buW1Tki7kwGNMrYYiWm8BE01tJQQJ99BEACYeBjFXJ3w3AAAFACOGZjh2"  
AZURE_VISION_ENDPOINT = "https://cv-hitachi-rebranding.cognitiveservices.azure.com/"  
logger.info(f"🔑 Azure Vision Key configured: {bool(AZURE_VISION_KEY)}")  
  
################## Tesseract configuration  #################
try:  
    if os.name == "nt":  
        possible_paths = [  
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",  
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",  
            r"C:\Tools\tesseract\tesseract.exe",  
        ]  
        for path in possible_paths:  
            if os.path.exists(path):  
                pytesseract.pytesseract.tesseract_cmd = path  
                logger.info(f"✅ Tesseract found at: {path}")  
                break  
    ENABLE_TESSERACT = True  
    logger.info("✅ Tesseract OCR enabled")  
except Exception as e:  
    logger.warning(f"⚠️ Tesseract OCR not available: {e}")  
    ENABLE_TESSERACT = False  
  
ENABLE_TESSERACT = True  
TESS_MIN_CONF = 50  
SKIP_NEW_HITACHI = True  
  
################## Replacement logos  #################
REPLACEMENT_LOGOS: Dict[str, str] = {  
    "hitachi_inspire": "Hitachi_Inspire1.png",  
    "hitachi_energy": "Transparent_logo1.png",  
}  
  
logger.info("🔍 REPLACEMENT LOGO CONFIGURATION:")  
for key, filename in REPLACEMENT_LOGOS.items():  
    logger.info(f"  {key}: {filename}")  
    possible_paths = [  
        Path(filename),  
        Path.cwd() / filename,  
        Path(__file__).resolve().parent / filename if "__file__" in globals() else None,  
        Path("/home/site/wwwroot") / filename,  
    ]  
    found = False  
    for path in possible_paths:  
        if path and path.exists():  
            logger.info(f"    ✅ Found at: {path}")  
            found = True  
            break  
    if not found:  
        logger.error("    ❌ NOT FOUND - Searched:")  
        for path in possible_paths:  
            if path:  
                logger.error(f"      - {path}")  
  
TEMPLATE_DIR = "templates"  
USE_TEMPLATE_DET = True  
DETECTION_BACKEND = "azure"  
  
################## Logo detection constants  #################
LOGO_CONF_THRESHOLD = 0.50  
MIN_DIM, MAX_DIM = 50, 16_000  
MIN_LOGO_HEIGHT_PX = 45  
HEADER_FOOTER_PCT = 0.22  
FOOTER_OCR_PCT = 0.25  
MIN_HITACHI_WIDTH_RATIO = 3.2  
IOU_DUP_THRESHOLD = 0.67  
  
MIN_RED_RATIO = 0.003  
MIN_LEFT_RED_RATIO = 0.015  
MIN_SYMBOL_AREA_PX = 180  
MIN_SYMBOL_AREA_RATIO = 0.05  
MIN_SYMBOL_ASPECT = 0.50  
MAX_SYMBOL_ASPECT = 1.60  
  
EDGE_RING_PCT = 0.20  
MAX_EDGE_DENSITY = 0.06  
MIN_SOLO_INK_RATIO = 0.001  
MAX_SOLO_INK_RATIO = 0.08  
  
PAD_PCT, MAX_PAD_PX = 0.12, 12  
DILATE_PCT, MAX_DILATE_PX = 0.18, 15  
INPAINT_PCT, MAX_INPAINT_RADIUS = 0.07, 7  
SCALE_COVERAGE = 1.01  
SEAMLESS_CLONE_TRIES = (cv2.MIXED_CLONE, cv2.NORMAL_CLONE)  
KEYWORDS_HITACHI = ("hitachi", "inspire", "next", "energy")  
  
TEMPLATE_THRESHOLDS = {  
    "hitachi inspire the next": 0.63,  
    "hitachi energy": 0.50,  
}  
  
################## Typography settings  #################
ENABLE_PDF_FONT_REBRAND = True  
ENABLE_DOCX_FONT_REBRAND = True  
HITACHI_SANS_TTF = "HitachiSans.ttf"  
VERDANA_TTF = "Verdana.ttf"  
FONT_FACTOR_PDF = 1.02  
FONT_FACTOR_DOCX = 1.00  
# UPDATED GLOBAL VARIABLES (set black logos and force black text on cover)  
FORCE_BLACK_INSPIRE_LOGOS = True  
FORCE_BLACK_TEXT_ON_COVER: bool = True    
# Gate: ONLY enable in template_flag=False path  
REFONT_COVER_TO_BLACK_ENABLED: bool = False  
################## Font rebranding settings  #################
FONT_FILE = pathlib.Path("HitachiSans.ttf")  
SHRINK_PT = 3  
SIZE_DELTA = -SHRINK_PT if SHRINK_PT else 0  
REMOVE_STRATEGY = os.getenv("REMOVE_STRATEGY", "redact")  
  
################## DOCX settings  #################
DOCX_BITMAP_EXTS: set[str] = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}  
DOCX_VECTOR_EXTS: set[str] = {".svg", ".emf", ".wmf"}  
DOCX_FORCE_DELETE_ENERGY = True  
DELETE_STYLE = "transparent"  
  
################## Force black color for all Hitachi Inspire logos
FORCE_BLACK_INSPIRE_LOGOS = False  
COND_WHITE_THR: int = 245  
WHITE_TEXT_THR_SHADOW: int = 245
COND_BG_MIN_INTERSECT_RATIO: float = 0.25 
#########If a red-like background is detected under the span, DO NOT recolor the text to black (veto). ######## 
COND_RED_VETO: bool = True  
#########"Red-like" background thresholds (in 0..255 space) ########## 
COND_RED_R_MIN: int = 150  
COND_RED_DOM_DELTA: int = 40  
COND_RED_GB_MAX: int = 140    
################## Add logo to DOCX cover pages  #################
ADD_COVER_LOGO_DOCX = False  
COVER_LOGO_SIZE = (120, 40)  
COVER_LOGO_MARGIN_RIGHT = 20  
COVER_LOGO_MARGIN_TOP = 20  
  
################## Font rebranding constants for DOCX  #################
TARGET_NAME = "Verdana"  
REDUCE_THRESHOLD_PT = 29.0  
REDUCE_BY_PT_LARGE = 2.0  
REDUCE_BY_PT_SMALL = 2.5  
MIN_SIZE_THRESHOLD_PT = 7.1  

WHITE_PANEL_OVERLAP_THR: float = 0.65        ### % of panel inside cluster (relative to panel area)  
WHITE_PANEL_MIN_AREA_RATIO: float = 0.08     ##### panel area vs cover area  
STRIPE_CLUSTER_MIN_OVERLAP: float = 0.25     ##### min overlap (relative to 


PRESERVE_BULLET_FONTS = {  
    "Symbol", "Wingdings", "Wingdings 2", "Wingdings 3",  
    "Webdings", "MS Gothic", "Arial Unicode MS", "OpenSymbol"  
}  
UNICODE_BULLETS = {  
    "•", "◦", "▪", "▫", "►", "‣", "⁃", "∙", "⚫", "⚪", "✓", "✗",  
    "■", "◼", "◾", "⬧"  
}  
  
  
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"  
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"  
CT = "http://schemas.openxmlformats.org/package/2006/content-types"  
NS = {"w": W}  
  
 
REDACT_LINE_ART_OPTION = getattr(  
    fitz,  
    "PDF_REDACT_LINE_ART_REMOVE_IF_COVERED",  
    getattr(fitz, "PDF_REDACT_REMOVE_GRAPHICS_IF_COVERED", 0),  
)  
  
if not hasattr(fitz.Page, "cluster_drawings"):  
    from typing import List as _List  
  
    def _cluster_drawings(self, gap: float = 2.0) -> _List["fitz.Rect"]:  
        drawings = self.get_drawings()  
        clusters: _List[fitz.Rect] = []  
        for d in drawings:  
            rect = d.get("rect")  
            if rect is None or rect.is_empty:  
                continue  
            r = fitz.Rect(rect.x0 - gap, rect.y0 - gap, rect.x1 + gap, rect.y1 + gap)  
            merged = False  
            for i, c in enumerate(clusters):  
                if r.intersects(c):  
                    clusters[i] = c | rect  
                    merged = True  
                    break  
            if not merged:  
                clusters.append(fitz.Rect(rect))  
        return clusters  
  
    fitz.Page.cluster_drawings = _cluster_drawings   
    logger.info("✅ Added cluster_drawings shim for PyMuPDF")  
else:  
    _cluster_drawings = fitz.Page.cluster_drawings    
    logger.info("✅ Using native cluster_drawings from PyMuPDF")  
  
##################COVER-IMAGE HELPERS################# 
def _shadow_rgb_from_int(color_int: int) -> Tuple[int, int, int]:  
    return ((color_int >> 16) & 255, (color_int >> 8) & 255, color_int & 255)  
  
  
def _shadow_is_span_white(sp: dict, thr_255: int = WHITE_TEXT_THR_SHADOW) -> bool:  
    c_int = sp.get("color")  
    if c_int is None:  
        return False  
    r, g, b = _shadow_rgb_from_int(int(c_int))  
    return min(r, g, b) >= thr_255  
  
  
def _shadow_cw(dir_tuple: Tuple[float, float]) -> float:  
    dx, dy = (dir_tuple or (1.0, 0.0))  
    ang = math.degrees(math.atan2(dy, dx))  
    if ang < 0:  
        ang += 360.0  
    return ang  
def _fallback_transparent_template() -> Optional[np.ndarray]:  
    candidates: List[Path] = []  
    here = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()  
    candidates.extend([  
        Path("transparent1.png"),  
        here / "transparent1.png",  
        Path.cwd() / "transparent1.png",  
        Path("/home/site/wwwroot") / "transparent1.png",  
    ])  
    for p in candidates:  
        try:  
            if p.exists():  
                img = cv2.imread(str(p), cv2.IMREAD_COLOR)  
                if img is not None:  
                    return img  
        except Exception:  
            continue  
    return None 
class _TmpGlobals:  
    def __init__(self, **overrides):  
        self._overrides = overrides  
        self._orig = {}  
  
    def __enter__(self):  
        for k, v in self._overrides.items():  
            self._orig[k] = globals().get(k, None)  
            globals()[k] = v  
        return self  
  
    def __exit__(self, exc_type, exc_val, exc_tb):  
        for k, v in self._orig.items():  
            globals()[k] = v  
        return False   
  
######### COLOR HELPERS used by the conditional re-font pass ############### 
import math  
  
def _to255(rgb_any):  
    r, g, b = rgb_any  
    if max(r, g, b) <= 1.0:  
        return int(round(r * 255)), int(round(g * 255)), int(round(b * 255))  
    return int(round(r)), int(round(g)), int(round(b))  
  
def _is_white(rgb_any, thr_255: int = COND_WHITE_THR) -> bool:  
    r, g, b = _to255(rgb_any)  
    return min(r, g, b) >= thr_255  
  
def _rgb_from_int(color_int: int):  
    return ((color_int >> 16) & 255, (color_int >> 8) & 255, color_int & 255)  
  
def _is_span_white(sp: dict, thr_255: int = COND_WHITE_THR) -> bool:  
    c_int = sp.get("color")  
    if c_int is None:  
        return False  
    r, g, b = _rgb_from_int(int(c_int))  
    return min(r, g, b) >= thr_255  
  
def cw(dir_tuple: Tuple[float, float]) -> float:  
    dx, dy = (dir_tuple or (1.0, 0.0))  
    ang = math.degrees(math.atan2(dy, dx))  
    if ang < 0:  
        ang += 360.0  
    return ang   
  
def _normalize_rgb01(c_any):  
    if c_any is None:  
        return (1.0, 1.0, 1.0)  
    if isinstance(c_any, (tuple, list)) and len(c_any) >= 3:  
        r, g, b = float(c_any[0]), float(c_any[1]), float(c_any[2])  
        if max(r, g, b) > 1.0:  
            return (r / 255.0, g / 255.0, b / 255.0)  
        return (r, g, b)  
    if isinstance(c_any, int):  
        r, g, b = _rgb_from_int(c_any)  
        return (r / 255.0, g / 255.0, b / 255.0)  
    ######### for white  ########
    return (1.0, 1.0, 1.0)  
  
def _stroke_fill_colors(d):  
    ######### Robustly fetch stroke and fill colors (normalized 0..1 floats)############  
    sc = d.get("color") or d.get("stroke") or d.get("stroke_color")  
    fc = d.get("fill") or d.get("fill_color")  
    return _normalize_rgb01(sc), _normalize_rgb01(fc) 
  
  
def _blank_cover_png_for_bbox(bbox: "fitz.Rect") -> tuple[np.ndarray, bytes]:  
      
    tw = max(1, int(round(bbox.width)))  
    th = max(1, int(round(bbox.height)))  
    blank = np.full((th, tw, 3), 255, dtype=np.uint8)  
    ok, buf = cv2.imencode(".png", blank, [int(cv2.IMWRITE_PNG_COMPRESSION), 3])  
    if not ok:  
        raise RuntimeError("Failed to encode blank cover PNG")  
    return blank, buf.tobytes()  
def _expand_rect_pct(r: "fitz.Rect", frac: float, max_pad: float, clip: Optional["fitz.Rect"] = None) -> "fitz.Rect":  
    #########Expand rect by a fraction of its max(side), capped by max_pad; optionally clip to 'clip'.#########  
    if r is None or r.is_empty:  
        return r  
    pad = min(max_pad, max(r.width, r.height) * max(0.0, float(frac)))  
    out = fitz.Rect(r.x0 - pad, r.y0 - pad, r.x1 + pad, r.y1 + pad)  
    if clip is not None:  
        out = out & clip  
    return out  
  
  
def _is_reasonable_logo_wipe_rect(r: "fitz.Rect", cover_bbox: "fitz.Rect") -> bool:  
    ###########Conservative filter to avoid wiping large non-logo content on the cover.###########  
    if r is None or r.is_empty:  
        return False  
    cover_area = max(abs(cover_bbox), 1e-6)  
    area_ratio = abs(r) / cover_area  
    if area_ratio > RASTER_LOGO_WIPE_MAX_AREA_RATIO:  
        return False  
    if r.height > (RASTER_LOGO_WIPE_MAX_HEIGHT_RATIO * cover_bbox.height):  
        return False  
    return True  
  
  
def _remove_graphics_in_rects(page: "fitz.Page", rects: list["fitz.Rect"]) -> None:  
    ########Remove vector line-art/graphics fully covered by given rects. Images remain untouched.############ 
    if not rects:  
        return  
    for r in rects:  
        if r is None or r.is_empty:  
            continue  
        try:  
            page.add_redact_annot(r, fill=None)  
        except Exception:  
            pass  
    ######### Remove vector graphics covered by the rects, keep images  ###########
    try:  
        _apply_redactions_safe(  
            page,  
            images_opt=getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0),  
            graphics_opt=getattr(  
                fitz, "PDF_REDACT_LINE_ART_REMOVE_IF_COVERED",  
                getattr(fitz, "PDF_REDACT_REMOVE_GRAPHICS_IF_COVERED", 0)  
            ),  
        )  
    except Exception:  
        try:  
            page.apply_redactions()  
        except Exception:  
            pass  
    try:  
        page.clean_contents()  
    except Exception:  
        pass  
  

def _detect_raster_inspire_info(img: np.ndarray) -> Tuple[bool, int, dict]:  
     
    #######Detects whether a raster image contains the Inspire diagonal red/parallelogram pattern. ########  
    if img is None or img.size == 0:  
        return False, 0, {"reason": "empty"}  
  
    H, W = img.shape[:2]  
    max_side = max(H, W)  
    if max_side > 2200:  
        sc = 2200.0 / max_side  
        img = cv2.resize(img, (int(W * sc), int(H * sc)), interpolation=cv2.INTER_AREA)  
        H, W = img.shape[:2]  
    area_total = float(H * W)  
  
    ##### Conservative red mask  #######
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  
    s_min, v_min = RASTER_RED_S_MIN, RASTER_RED_V_MIN  
    m1 = cv2.inRange(hsv, (0, s_min, v_min), (10, 255, 255))  
    m2 = cv2.inRange(hsv, (170, s_min, v_min), (180, 255, 255))  
  
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)  
    a = lab[:, :, 1].astype(np.int16)  
    b = lab[:, :, 2].astype(np.int16)  
    m3 = (((a >= RASTER_LAB_A_MIN) & ((a - b) >= RASTER_LAB_A_B_DELTA_MIN)).astype(np.uint8)) * 255  
  
    ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)  
    cr = ycrcb[:, :, 1].astype(np.int16)  
    cb = ycrcb[:, :, 2].astype(np.int16)  
    m5 = (((cr >= RASTER_YCRCB_CR_MIN) & ((cr - cb) >= RASTER_YCRCB_CR_CB_DELTA_MIN)).astype(np.uint8)) * 255  
  
    ######## BGR dominance with an extra saturation gate from HSV  ##########
    R, G, B = img[:, :, 2], img[:, :, 1], img[:, :, 0]  
    sat = hsv[:, :, 1]  
    m4 = (((R > 155) & (R > G + 38) & (R > B + 38) & (sat >= s_min)).astype(np.uint8)) * 255  
  
    ########## Final mask: require high-sat reds; allow Lab/YCrCb corroboration ############ 
    mask = m1 | m2 | (m3 & m5) | (m4 & (m1 | m2))  
  
    ########## Morphology (kept mild)  ##########
    k = max(3, int(0.006 * max(H, W)))  
    if k % 2 == 0:  
        k += 1  
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))  
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)  
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  kernel, iterations=1)  
  
    red_area = cv2.countNonZero(mask)  
    red_area_ratio = float(red_area) / max(1.0, area_total)  
    if red_area_ratio < max(0.004, RASTER_MIN_RED_AREA):  
        return False, 0, {"red_area": red_area_ratio, "reason": "too_little_red"}  
  
    ########## Components → CC stripes (elongated + slanted)  ##############
    min_comp_px = max(int(RASTER_STRIPE_MIN_COMP_AREA_RATIO * area_total), 120)  
    num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)  
  
    stripe_infos = []  
  
    def _pca_angle(cnt: np.ndarray) -> float:  
        pts = cnt.reshape(-1, 2).astype(np.float32)  
        if len(pts) < 5:  
            return 0.0  
        pts -= pts.mean(axis=0, keepdims=True)  
        cov = np.cov(pts.T)  
        eigvals, eigvecs = np.linalg.eigh(cov)  
        v = eigvecs[:, np.argmax(eigvals)]  
        ang = abs(math.degrees(math.atan2(v[1], v[0])))  
        return ang if ang <= 90 else 180 - ang  
  
    for i in range(1, num):  
        area_i = int(stats[i, cv2.CC_STAT_AREA])  
        if area_i < min_comp_px:  
            continue  
        comp = (labels == i).astype(np.uint8) * 255  
        cnts, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  
        if not cnts:  
            continue  
        cnt = max(cnts, key=cv2.contourArea)  
        rect = cv2.minAreaRect(cnt)  
        (_, _), (rw, rh), ang_r = rect  
        if rw == 0 or rh == 0:  
            continue  
        long_side = max(rw, rh)  
        short_side = max(1e-6, min(rw, rh))  
        if (long_side / short_side) < RASTER_STRIPE_MIN_ASPECT:  
            continue  
        if rw < rh:  
            ang_r += 90.0  
        ang_r = abs(ang_r)  
        ang_r = ang_r if ang_r <= 90 else 180 - ang_r  
        ang_p = _pca_angle(cnt)  
        angle = float(np.median([ang_r, ang_p]))  
        if not (RASTER_STRIPE_ANGLE_LO <= angle <= RASTER_STRIPE_ANGLE_HI):  
            continue  
        stripe_infos.append(  
            dict(  
                area=area_i,  
                angle=angle,  
                bbox=fitz.Rect(stats[i, 0], stats[i, 1], stats[i, 0] + stats[i, 2], stats[i, 1] + stats[i, 3]),  
            )  
        )  
  
    stripes_cc = len(stripe_infos)  
    area_sum_cc = float(sum(s["area"] for s in stripe_infos))  
    area_ratio_stripes = area_sum_cc / max(1.0, area_total)  
    angles = [s["angle"] for s in stripe_infos]  
  
    ##### Gradient orientation  #########
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  
    gray = cv2.GaussianBlur(gray, (0, 0), 1.2)  
    gx = cv2.Scharr(gray, cv2.CV_32F, 1, 0)  
    gy = cv2.Scharr(gray, cv2.CV_32F, 0, 1)  
    mag = cv2.magnitude(gx, gy)  
    ang = (cv2.phase(gx, gy, angleInDegrees=True) + 180.0) % 180.0  
    ang = np.minimum(ang, 180.0 - ang)  
    m = (mask > 0)  
    mag_m = mag[m]  
    ang_m = ang[m]  
    total_energy = float(mag_m.sum()) + 1e-6  
    diag_energy = float(mag_m[(ang_m >= 22.0) & (ang_m <= 68.0)].sum())  
    diag_ratio = diag_energy / total_energy  
  
    ########## Hough lines -> orientation confirmation  ##########
    edges = cv2.Canny(mask, 50, 150)  
    lines = cv2.HoughLinesP(  
        edges,  
        1,  
        np.pi / 180,  
        threshold=80,  
        minLineLength=max(40, int(0.18 * max(H, W))),  
        maxLineGap=12,  
    )  
    line_angles = []  
    if lines is not None:  
        for l in lines:  
            x1, y1, x2, y2 = l[0]  
            if math.hypot(x2 - x1, y2 - y1) < max(30, 0.15 * max(H, W)):  
                continue  
            a = abs(math.degrees(math.atan2(y2 - y1, x2 - x1)))  
            a = a if a <= 90 else 180 - a  
            if RASTER_STRIPE_ANGLE_LO <= a <= RASTER_STRIPE_ANGLE_HI:  
                line_angles.append(a)  
    parallel_lines, ori_peak = 0, 0.0  
    if line_angles:  
        bins = np.arange(0, 91, 6.0)  
        hist, _ = np.histogram(line_angles, bins=bins)  
        parallel_lines = int(hist.max())  
        ori_peak = float(hist.max()) / max(1.0, float(hist.sum()))  
  
    ##### Dominant angle ###### 
    if angles:  
        main_angle = float(np.median(angles))  
    elif line_angles:  
        main_angle = float(np.median(line_angles))  
    else:  
        main_angle = 45.0  
  
    ######## Projection band counter (when blobs merge)  ##########
    rot = -main_angle  
    M = cv2.getRotationMatrix2D((W / 2.0, H / 2.0), rot, 1.0)  
    mask_rot = cv2.warpAffine(mask, M, (W, H), flags=cv2.INTER_NEAREST, borderValue=0)  
    row_counts = (mask_rot > 0).sum(axis=1).astype(np.int32)  
    row_thr = max(8, int(0.12 * W))  
    stripe_rows = (row_counts >= row_thr).astype(np.uint8)  
    win = max(3, int(0.01 * H))  
    win += (win % 2 == 0)  
    if win > 1:  
        stripe_rows = (np.convolve(stripe_rows, np.ones(win) / win, mode="same") > 0.3).astype(np.uint8)  
    diffs = np.diff(np.pad(stripe_rows, (1, 1), "constant"))  
    bands = int((diffs > 0).sum())  
  
    stripes = max(stripes_cc, bands)  
    stripes_src = "cc" if stripes_cc >= stripes else "bands"  
  
    ######## Compactness/density  ##########
    union_rect = None  
    for s in stripe_infos:  
        union_rect = s["bbox"] if union_rect is None else (union_rect | s["bbox"])  
    if union_rect is not None:  
        union_area_ratio = abs(union_rect) / max(1.0, area_total)  
        density = area_sum_cc / max(1.0, abs(union_rect))  
    else:  
        union_area_ratio, density = 0.0, 0.0  
    ang_std = float(np.std(angles)) if len(angles) > 1 else 0.0  
  
    ####### Largest red component guards  ##########
    red_num, _, red_stats, _ = cv2.connectedComponentsWithStats(mask, 8)  
    biggest = 0  
    if red_num > 1:  
        areas = red_stats[1:, cv2.CC_STAT_AREA]  
        biggest = int(np.max(areas))  
    big_red1_cc = biggest / max(1.0, area_sum_cc) if area_sum_cc > 0 else 0.0  
    big_red1 = big_red1_cc if stripes_src == "cc" and area_sum_cc >= biggest * 0.5 else biggest / max(1.0, red_area)  
    big_red2 = biggest / max(1.0, red_area)  
  
    ####### Confidence  ########
    def _clamp01(x): return max(0.0, min(1.0, float(x)))  
    s_norm = _clamp01(stripes / 6.0)  
    d_norm = _clamp01(diag_ratio / 0.60)  
    o_norm = _clamp01(ori_peak / 0.60)  
    a_norm = _clamp01(area_ratio_stripes / 0.08)  
    base = 0.25 * s_norm + 0.35 * d_norm + 0.20 * o_norm + 0.20 * a_norm  
    penalty = 0.0  
    if big_red1 > RASTER_BIG_RED_ONE_MAX:  
        penalty += 0.12  
    if big_red2 > RASTER_BIG_RED_TWO_MAX:  
        penalty += 0.18  
    ########## Penalize photos where red covers too much but orientation evidence is weak########  
    penalty += max(0.0, (red_area_ratio - RASTER_MAX_RED_AREA)) * (0.4 if (ori_peak < 0.33 and parallel_lines < 2) else 0.1)  
    conf_score = _clamp01(base - penalty)  
  
    ####### Decision  #########
    diag_ok = diag_ratio >= RASTER_GRAD_DIAG_MIN  
    strong_diag = diag_ratio >= RASTER_GRAD_STRONG  
    orientation_ok = (ori_peak >= RASTER_ORI_HIST_PEAK_MIN) or (parallel_lines >= RASTER_STRIPE_CONFIRM_PARALLEL_MIN)  
    area_ok = area_ratio_stripes >= RASTER_STRIPE_MIN_AREA_RATIO  
  
    ########### Main gate: require stripes, diagonal energy, AND some orientation evidence  ############
    has_pattern = bool(  
        (stripes >= RASTER_STRIPE_MIN_COUNT and area_ok and diag_ok and ang_std <= ANGLE_CLUSTER_STD_MAX and orientation_ok)  
        or  
        (strong_diag and orientation_ok and (bands >= 3 or area_ok))  
    )  
  
    ########### Extra guard: reject huge red coverage in photos when orientation is weak  ##########
    if has_pattern and red_area_ratio > RASTER_MAX_RED_AREA and not orientation_ok:  
        has_pattern = False  
  
    metrics = dict(  
        stripes=stripes,  
        stripes_cc=stripes_cc,  
        bands=bands,  
        stripes_src=stripes_src,  
        red_area=red_area_ratio,  
        stripe_area=area_ratio_stripes,  
        diag_ratio=diag_ratio,  
        angles=[round(a, 1) for a in angles],  
        angle_std=round(ang_std, 2),  
        union_area_ratio=round(union_area_ratio, 3),  
        density=round(density, 3),  
        parallel_lines=int(parallel_lines),  
        ori_peak=round(ori_peak, 3),  
        big_red1=round(big_red1, 3),  
        big_red2=round(big_red2, 3),  
        conf_score=round(conf_score, 3),  
        main_angle=round(main_angle, 1),  
    )  
    return has_pattern, stripes, metrics   
def _detect_raster_inspire_info_old(img: np.ndarray) -> Tuple[bool, int, dict]:  
    if img is None or img.size == 0:  
        return False, 0, {"reason": "empty"}  
  
    H, W = img.shape[:2]  
    max_side = max(H, W)  
    if max_side > 2200:  
        sc = 2200.0 / max_side  
        img = cv2.resize(img, (int(W * sc), int(H * sc)), interpolation=cv2.INTER_AREA)  
        H, W = img.shape[:2]  
    area_total = float(H * W)  
  
    ######## Red mask (HSV + Lab + BGR dominance) ######### 
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  
    m1 = cv2.inRange(hsv, (0, 60, 50), (12, 255, 255))  
    m2 = cv2.inRange(hsv, (168, 60, 50), (180, 255, 255))  
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)  
    a = lab[:, :, 1]  
    thr_a = int(np.clip(np.percentile(a, 75), 140, 175))  
    m3 = ((a >= thr_a).astype(np.uint8)) * 255  
    R, G, B = img[:, :, 2], img[:, :, 1], img[:, :, 0]  
    m4 = ((R > 135) & (R > G + 32) & (R > B + 32)).astype(np.uint8) * 255  
    mask = m1 | m2 | m3 | m4  
  
    ########## Morphology  ##########
    k = max(3, int(0.006 * max(H, W)))  
    if k % 2 == 0:  
        k += 1  
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))  
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)  
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  kernel, iterations=1)  
  
    red_area = cv2.countNonZero(mask)  
    red_area_ratio = float(red_area) / max(1.0, area_total)  
    if red_area_ratio < max(0.004, RASTER_MIN_RED_AREA):  
        return False, 0, {"red_area": red_area_ratio, "reason": "too_little_red"}  
  
    ########### Components → CC stripes  ##########
    min_comp_px = max(int(RASTER_STRIPE_MIN_COMP_AREA_RATIO * area_total), 120)  
    num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)  
  
    stripe_infos = []  
    def _pca_angle(cnt: np.ndarray) -> float:  
        pts = cnt.reshape(-1, 2).astype(np.float32)  
        if len(pts) < 5: return 0.0  
        pts -= pts.mean(axis=0, keepdims=True)  
        cov = np.cov(pts.T)  
        eigvals, eigvecs = np.linalg.eigh(cov)  
        v = eigvecs[:, np.argmax(eigvals)]  
        ang = abs(math.degrees(math.atan2(v[1], v[0])))  
        return ang if ang <= 90 else 180 - ang  
  
    for i in range(1, num):  
        area_i = int(stats[i, cv2.CC_STAT_AREA])  
        if area_i < min_comp_px:  
            continue  
        comp = (labels == i).astype(np.uint8) * 255  
        cnts, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  
        if not cnts:  
            continue  
        cnt = max(cnts, key=cv2.contourArea)  
        rect = cv2.minAreaRect(cnt)  
        (_, _), (rw, rh), ang_r = rect  
        if rw == 0 or rh == 0:  
            continue  
        long_side = max(rw, rh); short_side = max(1e-6, min(rw, rh))  
        if (long_side / short_side) < RASTER_STRIPE_MIN_ASPECT:  
            continue  
        if rw < rh: ang_r += 90.0  
        ang_r = abs(ang_r); ang_r = ang_r if ang_r <= 90 else 180 - ang_r  
        ang_p = _pca_angle(cnt)  
        angle = float(np.median([ang_r, ang_p]))  
        if not (RASTER_STRIPE_ANGLE_LO <= angle <= RASTER_STRIPE_ANGLE_HI):  
            continue  
        stripe_infos.append(dict(area=area_i, angle=angle,  
                                 bbox=fitz.Rect(stats[i,0], stats[i,1],  
                                                stats[i,0]+stats[i,2], stats[i,1]+stats[i,3])))  
  
    stripes_cc = len(stripe_infos)  
    area_sum_cc = float(sum(s["area"] for s in stripe_infos))  
    area_ratio_stripes = area_sum_cc / max(1.0, area_total)  
    angles = [s["angle"] for s in stripe_infos]  
  
    ######### Gradient orientation (diagonal energy)  #########
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  
    gray = cv2.GaussianBlur(gray, (0,0), 1.2)  
    gx = cv2.Scharr(gray, cv2.CV_32F, 1, 0)  
    gy = cv2.Scharr(gray, cv2.CV_32F, 0, 1)  
    mag = cv2.magnitude(gx, gy)  
    ang = (cv2.phase(gx, gy, angleInDegrees=True) + 180.0) % 180.0  
    ang = np.minimum(ang, 180.0 - ang)  
    m = (mask > 0)  
    mag_m = mag[m]; ang_m = ang[m]  
    total_energy = float(mag_m.sum()) + 1e-6  
    diag_energy = float(mag_m[(ang_m >= 22.0) & (ang_m <= 68.0)].sum())  
    diag_ratio = diag_energy / total_energy  
  
    ########## Hough lines → parallel / orientation peak ########## 
    edges = cv2.Canny(mask, 50, 150)  
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=80,  
                            minLineLength=max(40, int(0.18*max(H,W))), maxLineGap=12)  
    line_angles = []  
    if lines is not None:  
        for l in lines:  
            x1,y1,x2,y2 = l[0]  
            if math.hypot(x2-x1, y2-y1) < max(30, 0.15*max(H,W)): continue  
            a = abs(math.degrees(math.atan2(y2-y1, x2-x1))); a = a if a<=90 else 180-a  
            if RASTER_STRIPE_ANGLE_LO <= a <= RASTER_STRIPE_ANGLE_HI:  
                line_angles.append(a)  
    parallel_lines, ori_peak = 0, 0.0  
    if line_angles:  
        bins = np.arange(0, 91, 6.0)  
        hist, _ = np.histogram(line_angles, bins=bins)  
        parallel_lines = int(hist.max())  
        ori_peak = float(hist.max()) / max(1.0, float(hist.sum()))  
  
    ######### Dominant angle  ###########
    if angles:  
        main_angle = float(np.median(angles))  
    elif line_angles:  
        main_angle = float(np.median(line_angles))  
    else:  
        main_angle = 45.0  
  
    ############ Projection band counter (works when blobs merge)  ############
    rot = -main_angle  
    M = cv2.getRotationMatrix2D((W/2.0, H/2.0), rot, 1.0)  
    mask_rot = cv2.warpAffine(mask, M, (W, H), flags=cv2.INTER_NEAREST, borderValue=0)  
    row_counts = (mask_rot > 0).sum(axis=1).astype(np.int32)  
    row_thr = max(8, int(0.12 * W))  
    stripe_rows = (row_counts >= row_thr).astype(np.uint8)  
    win = max(3, int(0.01 * H));  win += (win % 2 == 0)  
    if win > 1:  
        stripe_rows = (np.convolve(stripe_rows, np.ones(win)/win, mode="same") > 0.3).astype(np.uint8)  
    diffs = np.diff(np.pad(stripe_rows, (1,1), "constant"))  
    bands = int((diffs > 0).sum())  
  
    stripes = max(stripes_cc, bands)  
    stripes_src = "cc" if stripes_cc >= stripes else "bands"  
  
    ######### Compactness/density  #########
    union_rect = None  
    for s in stripe_infos:  
        union_rect = s["bbox"] if union_rect is None else (union_rect | s["bbox"])  
    if union_rect is not None:  
        union_area_ratio = abs(union_rect) / max(1.0, area_total)  
        density = area_sum_cc / max(1.0, abs(union_rect))  
    else:  
        union_area_ratio, density = 0.0, 0.0  
    ang_std = float(np.std(angles)) if len(angles) > 1 else 0.0  
  
    ######## Largest red component guards  ############
    red_num, _, red_stats, _ = cv2.connectedComponentsWithStats(mask, 8)  
    biggest = 0  
    if red_num > 1:  
        areas = red_stats[1:, cv2.CC_STAT_AREA]  
        biggest = int(np.max(areas))  
    ############ Safe big_red1: when stripes came from bands (not CC), compare to total red  #########
    big_red1_cc = biggest / max(1.0, area_sum_cc) if area_sum_cc > 0 else 0.0  
    big_red1 = (big_red1_cc if stripes_src == "cc" and area_sum_cc >= biggest*0.5  
                else biggest / max(1.0, red_area))  
    big_red2 = biggest / max(1.0, red_area)  
  
    ########## Confidence  #########
    def _clamp01(x): return max(0.0, min(1.0, float(x)))  
    s_norm = _clamp01(stripes / 6.0)  
    d_norm = _clamp01(diag_ratio / 0.60)  
    o_norm = _clamp01(ori_peak   / 0.60)  
    a_norm = _clamp01(area_ratio_stripes / 0.08)  
    base = 0.25*s_norm + 0.35*d_norm + 0.20*o_norm + 0.20*a_norm  
    penalty = 0.0  
    if big_red1 > RASTER_BIG_RED_ONE_MAX: penalty += 0.12  
    if big_red2 > RASTER_BIG_RED_TWO_MAX: penalty += 0.12  
    conf_score = _clamp01(base - penalty)  
  
    ########## Decision#######  
    diag_ok = diag_ratio >= RASTER_GRAD_DIAG_MIN  
    strong_diag = diag_ratio >= RASTER_GRAD_STRONG  
    has_pattern = bool(  
        (stripes >= RASTER_STRIPE_MIN_COUNT and  
         area_ratio_stripes >= RASTER_STRIPE_MIN_AREA_RATIO and  
         diag_ok and  
         ang_std <= ANGLE_CLUSTER_STD_MAX and  
         (ori_peak >= RASTER_ORI_HIST_PEAK_MIN or parallel_lines >= RASTER_STRIPE_CONFIRM_PARALLEL_MIN))  
        or  
        (strong_diag and (bands >= 3 or area_ratio_stripes >= RASTER_STRIPE_MIN_AREA_RATIO))  
    )  
  
    metrics = dict(  
        stripes=stripes,  
        stripes_cc=stripes_cc,  
        bands=bands,  
        stripes_src=stripes_src,  
        red_area=red_area_ratio,  
        stripe_area=area_ratio_stripes,  
        diag_ratio=diag_ratio,  
        angles=[round(a,1) for a in angles],  
        angle_std=round(ang_std,2),  
        union_area_ratio=round(union_area_ratio,3),  
        density=round(density,3),  
        parallel_lines=int(parallel_lines),  
        ori_peak=round(ori_peak,3),  
        big_red1=round(big_red1,3),  
        big_red2=round(big_red2,3),  
        conf_score=round(conf_score,3),  
        main_angle=round(main_angle,1),  
    )  
    return has_pattern, stripes, metrics     
  
  
def _pixmap_clip_to_bgr(page: "fitz.Page", clip: "fitz.Rect", scale: int = 2) -> Optional[np.ndarray]:  
    try:  
        pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=clip, alpha=False)  
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)  
        return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)  
    except Exception:  
        return None  
   
 
def _remove_text_in_rects(page: "fitz.Page", rects: List["fitz.Rect"]) -> None:    
    ############Remove text elements whose span bbox intersects any of the given rects.  ###########  
    if not rects:  
        return  
    ######## Collect spans that intersect target rects ########## 
    spans_to_remove: List[dict] = []  
    for b in page.get_text("dict")["blocks"]:  
        if b["type"]:  
            continue  
        for ln in b["lines"]:  
            for sp in ln["spans"]:  
                r = fitz.Rect(sp["bbox"])  
                if _rect_intersects_any(r, rects):  
                    spans_to_remove.append(sp)  

    if not spans_to_remove:  
        return  

    ########### Add redaction annots for each target span bbox  ############
    for sp in spans_to_remove:  
        txt = sp.get("text", "")  
        if not txt.strip():  
            continue  
        r = fitz.Rect(sp["bbox"])  
        ########### shrink slightly to avoid over-redacting neighboring content ############ 
        r.x0, r.y0, r.x1, r.y1 = r.x0 + 0.5, r.y0 + 0.5, r.x1 - 0.5, r.y1 - 0.5  
        try:  
            page.add_redact_annot(r, fill=None)  
        except Exception:  
            pass  

    ############# Apply redactions (text only; do not touch images) ############# 
    try:  
        page.apply_redactions(images=getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0))  
    except Exception:  
        try:  
            page.apply_redactions()  
        except Exception:  
            pass  

     
    try:  
        page.clean_contents()  
    except Exception:  
        pass  
def cover_image_xref_bbox(  
    page: "fitz.Page",  
    *,  
    area_ratio_thr: float = 0.80,  
    width_ratio_thr: float = 0.90,  
    height_ratio_thr: float = 0.90,  
) -> Optional[Tuple[int, "fitz.Rect"]]:    
    imgs = page.get_images(full=True)  
    if not imgs:  
        return None  
  
    page_area = page.rect.width * page.rect.height  
    best: Tuple[int, "fitz.Rect"] | None = None  
    best_area = 0.0  
  
    for (xref, *_) in imgs:  
        try:  
            rects = page.get_image_rects(xref)  
        except Exception:  
            rects = []  
        if not rects:  
            continue  
  
        bbox = rects[0]  
        area = bbox.width * bbox.height  
        area_ratio = area / page_area  
        width_ratio = bbox.width / page.rect.width  
        height_ratio = bbox.height / page.rect.height  
  
        if (area_ratio >= area_ratio_thr) or (width_ratio >= width_ratio_thr) or (height_ratio >= height_ratio_thr):  
            if area > best_area:  
                best = (xref, bbox)  
                best_area = area  
  
    return best  

def cover_image_bbox_pdf(page) -> Optional["fitz.Rect"]:  
    logger.info(f"🔍 Searching for cover image on page {page.number}")  
    imgs = page.get_images(full=True)  
    if not imgs:  
        logger.info("📷 No images found on page")  
        return None  
  
    page_area = page.rect.width * page.rect.height  
    best_bbox, best_area = None, 0  
    logger.info(f"📊 Page area: {page_area}, Found {len(imgs)} images")  
  
    for i, (xref, *_) in enumerate(imgs):  
        try:  
            rects = page.get_image_rects(xref)  
        except Exception as e:  
            logger.warning(f"⚠️ Could not get rects for image {i}: {e}")  
            continue  
        if not rects:  
            continue  
        bbox = rects[0]  
        area = bbox.width * bbox.height  
        area_ratio = area / page_area  
        width_ratio = bbox.width / page.rect.width  
        height_ratio = bbox.height / page.rect.height  
        logger.info(  
            f"📷 Image {i}: area_ratio={area_ratio:.3f}, width_ratio={width_ratio:.3f}, height_ratio={height_ratio:.3f}"  
        )  
        if (area_ratio >= 0.80 or width_ratio >= 0.90 or height_ratio >= 0.90):  
            if area > best_area:  
                logger.info(f"✅ Found better cover image candidate: area={area}")  
                best_bbox, best_area = bbox, area  
  
    if best_bbox:  
        logger.info(f"✅ Selected cover image bbox: {best_bbox}")  
    else:  
        logger.warning("⚠️ No suitable cover image found")  
  
    return best_bbox  
   
  
def _norm_rgb(c) -> Tuple[float, float, float]:  
    if c is None:  
        return (0.0, 0.0, 0.0)  
    if isinstance(c, (list, tuple)) and len(c) >= 3:  
        try:  
            return (float(c[0]), float(c[1]), float(c[2]))  
        except Exception:  
            pass  
    return (0.0, 0.0, 0.0)  
  
def _stroke_fill_colors(d):  
    if d.get("colors"):  
        stroke, fill = d["colors"]  
        return _norm_rgb(stroke), _norm_rgb(fill)  
    stroke = d.get("stroke")  
    fill = d.get("fill")  
    return _norm_rgb(stroke), _norm_rgb(fill)
  
    
  
def _xo_info(page: "fitz.Page", raw):  
    if isinstance(raw, dict):  
        return (  
            int(raw.get("xref")),  
            str(raw.get("name")),  
            raw.get("bbox"),  
            raw.get("subtype"),  
        )  
    xref = int(raw[0])  
    doc = page.parent  
    try:  
        obj = doc.xref_object(xref, compressed=False) or b""  
    except Exception:  
        obj = b""  
    if isinstance(obj, str):  
        obj = obj.encode("latin1", "ignore")  
    g = re.search(rb"/Name\s*/([A-Za-z0-9]+)", obj)  
    name = g.group(1).decode() if g else f"XO{xref}"  
    g = re.search(rb"/Subtype\s*/([A-Za-z0-9]+)", obj)  
    subtype = "/" + g.group(1).decode() if g else None  
    bbox = None  
    g = re.search(rb"/BBox\s*$([^$]+)\]", obj)  
    if g:  
        nums = [float(v) for v in g.group(1).split()]  
        bbox = fitz.Rect(nums) if len(nums) == 4 else None  
    return xref, name, bbox, subtype  
  
  
def _del_resource(page: "fitz.Page", name: str):  
    doc = page.parent  
    try:  
        doc.xref_set_key(page.xref, f"Resources/XObject/{name}", "null")  
    except Exception:  
        pass  
    for c_x in page.get_contents():  
        data = doc.xref_stream(c_x) or b""  
        out = [  
            ln  
            for ln in data.splitlines()  
            if (f"/{name} Do".encode() not in ln) and (f"/{name} sh".encode() not in ln)  
        ]  
        if len(out) != len(data.splitlines()):  
            doc.update_stream(c_x, b"\n".join(out))  
    
def _is_white(rgb01: Tuple[float, float, float], thr_255: int = 245) -> bool:  
    r, g, b = rgb01  
    ##################Accept both 0..1 and 0..255 ranges  #################
    if max(r, g, b) <= 1.0:  
        r, g, b = r * 255.0, g * 255.0, b * 255.0  
    return (r >= thr_255) and (g >= thr_255) and (b >= thr_255)
   
def _rgb_from_int(val: int) -> Tuple[int, int, int]:  
    return (val >> 16) & 255, (val >> 8) & 255, val & 255  
  
def _has_diagonal_stripe_geometry(drawing: dict) -> bool:  
    try:  
        rect = drawing.get("rect")  
        if not rect:  
            return False  
        aspect_ratio = max(rect.width, rect.height) / max(min(rect.width, rect.height), 0.1)  
        if aspect_ratio < 1.5:  
            return False  
        area = rect.width * rect.height  
        if area < 50 or area > 2000:  
            return False  
        items = drawing.get("items", [])  
        for item in items:  
            if len(item) >= 3 and item[0] == "l":  
                try:  
                    p1, p2 = item[1], item[2]  
                    if hasattr(p1, "x") and hasattr(p2, "x"):  
                        dx, dy = p2.x - p1.x, p2.y - p1.y  
                        if abs(dx) > 0 and abs(dy) > 0:  
                            angle = abs(math.degrees(math.atan2(dy, dx)))  
                            angle = min(angle, 180 - angle)  
                            if 20 <= angle <= 70:  
                                return True  
                except Exception:  
                    continue  
        return False  
    except Exception:  
        return False  
  
  
def _seg_angle(p1, p2):  
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]  
    if dx == dy == 0:  
        return None  
    ang = abs(math.degrees(math.atan2(dy, dx)))  
    return ang if ang <= 90 else 180 - ang  
  
def _segments_from_drawing(d: dict):  
    segs, cur, tr = [], None, d.get("trans")  
  
    def _t(p):  
        if not tr:  
            return p  
        a, b, c, d_, e, f = tr  
        x, y = p  
        return (a * x + c * y + e, b * x + d_ * y + f)  
  
    for op, arg, *_ in d["items"]:  
        if op == "l":  
            nxt = _t(arg)  
            if cur:  
                segs.append((cur, nxt))  
            cur = nxt  
        elif op == "m":  
            cur = _t(arg)  
        elif op == "re":  
            x, y, w, h = arg  
            p0 = _t((x, y))  
            p1 = _t((x + w, y))  
            p2 = _t((x + w, y + h))  
            p3 = _t((x, y + h))  
            segs.extend([(p0, p1), (p1, p2), (p2, p3), (p3, p0)])  
            cur = None  
        elif op == "h":  
            cur = None  
    return segs  
  
  
def _color_is_red(rgb: Tuple[float, float, float]) -> bool:  
    try:  
        r, g, b = rgb  
    except Exception:  
        return False  
    return (r >= RED_MIN_R) and (g <= RED_MAX_G) and (b <= RED_MAX_B)  
  
def _rect_area(r: "fitz.Rect") -> float:  
    return abs(r)  
  
def _max_overlap_ratio_to_any(target: "fitz.Rect", refs: list["fitz.Rect"], *, ref_is="target") -> float:  
    if not refs:  
        return 0.0  
    ta = max(_rect_area(target), 1e-6)  
    m = 0.0  
    for rr in refs:  
        inter = target & rr  
        if inter.is_empty:  
            continue  
        ra = max(_rect_area(rr), 1e-6)  
        ratio = _rect_area(inter) / (ta if ref_is == "target" else ra)  
        m = max(m, ratio)  
    return m  
def save_pixmap_as_png(pix, output_path):
    ######Save a PyMuPDF Pixmap as a PNG file ##########
    try:
        pix.save(output_path)
        print(f"Saved: {output_path}")
    except Exception as e:
        print(f"Error saving {output_path}: {e}")  

def inspire_clusters(page: "fitz.Page", restrict_to: Optional["fitz.Rect"] = None) -> list["fitz.Rect"]:   
    clusters = page.cluster_drawings()  
    drawings = page.get_drawings()   
    flagged: list[fitz.Rect] = []  
    for crect in clusters:  
        if restrict_to is not None and not crect.intersects(restrict_to):  
            continue  
        cl_dr = [d for d in drawings if fitz.Rect(d.get("rect") or fitz.Rect()).intersects(crect)]  
        if cl_dr and is_inspire_cluster(cl_dr, verbose=False):  
        # if is_inspire_cluster(cl_dr, verbose=False):
            flagged.append(fitz.Rect(crect))  
    return flagged    
def is_inspire_cluster(drawings: List[dict], verbose: bool = False) -> bool:  
    logger.info(f"🔍 Analyzing cluster with {len(drawings)} drawings for Inspire pattern")  
    diag_len = hv_len = 0.0  
    diag_cnt = hv_cnt = 0  
    for d in drawings:  
        stroke_clr, fill_clr = _stroke_fill_colors(d)  
        if not (_color_is_red(stroke_clr) or _color_is_red(fill_clr)):  
            continue  
        if d.get("do_stroke", False) and d.get("width", 0) < 0.4:  
            continue  
        for p1, p2 in _segments_from_drawing(d):  
            seg_len = math.hypot(p2[0] - p1[0], p2[1] - p1[1])  
            if seg_len < MIN_STRIPE_LENGTH:  
                continue  
            ang = _seg_angle(p1, p2)  
            if ang is None:  
                continue  
            if abs(ang - REF_ANGLE) <= ANGLE_TOLERANCE:  
                diag_cnt += 1  
                diag_len += seg_len  
            elif ang < 10 or ang > 80:  
                hv_cnt += 1  
                hv_len += seg_len  
    is_inspire = (  
        diag_cnt >= MIN_STRIPES_IN_CLUSTER  
        and diag_len >= MIN_TOTAL_LEN  
        and (not hv_len or (hv_len / diag_len) <= MAX_HV_RATIO)  
    )  
    # print(f"diag_cnt={diag_cnt}, diag_len={diag_len:.1f}, hv_len={hv_len:.1f}, is_inspire={is_inspire}")
    logger.info(  
        f"📊 Inspire cluster analysis: diag_cnt={diag_cnt}, diag_len={diag_len:.1f}, hv_len={hv_len:.1f}, is_inspire={is_inspire}"  
    )  
    return is_inspire  
  
  
def fullpage_cover(page_shape: Tuple[int, int], tpl: np.ndarray) -> np.ndarray:  
    ph, pw = page_shape  
    return cv2.resize(  
        tpl,  
        (pw, ph),  
        interpolation=cv2.INTER_AREA if (pw < tpl.shape[1] or ph < tpl.shape[0]) else cv2.INTER_LINEAR,  
    )  
  
##################template-resize helper#################  
def resize_template_exact(tpl: np.ndarray, tgt_w: int, tgt_h: int) -> np.ndarray:  
    logger.info(f"📏 Resizing template from {tpl.shape} to ({tgt_w}, {tgt_h})")  
    if tgt_w <= 0 or tgt_h <= 0:  
        raise ValueError("target size must be positive")  
    interp = (cv2.INTER_AREA if tgt_w < tpl.shape[1] or tgt_h < tpl.shape[0] else cv2.INTER_LINEAR)  
    result = cv2.resize(tpl, (tgt_w, tgt_h), interpolation=interp)  
    logger.info(f"✅ Template resized successfully to {result.shape}")  
    return result  
 
def _detect_red_diagonal_pattern(img: np.ndarray) -> bool:  
    logger.info(f"🔍 Detecting red diagonal pattern in image {img.shape if img is not None else 'None'}")  
    if img is None or img.size == 0:  
        logger.warning("⚠️ Empty or None image provided")  
        return False  
  
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  
    mask1 = cv2.inRange(hsv, (0, 70, 50), (10, 255, 255))  
    mask2 = cv2.inRange(hsv, (170, 70, 50), (180, 255, 255))  
    mask = cv2.bitwise_or(mask1, mask2)  
    red_pixels = cv2.countNonZero(mask)  
    logger.info(f"🔴 Red pixels found: {red_pixels}")  
  
    if red_pixels < 500:  
        logger.info("❌ Not enough red pixels for pattern detection")  
        return False  
  
    edges = cv2.Canny(mask, 50, 150)  
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=80, minLineLength=40, maxLineGap=10)  
    if lines is None:  
        logger.info("❌ No lines detected in red regions")  
        return False  
  
    diag_cnt = hv_cnt = 0  
    diag_len = hv_len = 0.0  
    for l in lines:  
        x1, y1, x2, y2 = l[0]  
        length = math.hypot(x2 - x1, y2 - y1)  
        if length < 30:  
            continue  
        ang = abs(math.degrees(math.atan2(y2 - y1, x2 - x1)))  
        ang = ang if ang <= 90 else 180 - ang  
        if abs(ang - REF_ANGLE) <= ANGLE_TOLERANCE:  
            diag_cnt += 1  
            diag_len += length  
        elif ang < 10 or ang > 80:  
            hv_cnt += 1  
            hv_len += length  
  
    has_pattern = (  
        diag_cnt >= MIN_STRIPES_IN_CLUSTER and  
        diag_len >= MIN_TOTAL_LEN and  
        (not hv_len or (hv_len / diag_len) <= MAX_HV_RATIO)  
    ) 
    # print(f"diag_cnt={diag_cnt}, diag_len={diag_len:.1f}, hv_len={hv_len:.1f}, has_pattern={has_pattern}") 
    logger.info(  
        f"📊 Pattern detection result: diag_cnt={diag_cnt}, diag_len={diag_len:.1f}, hv_len={hv_len:.1f}, has_pattern={has_pattern}"  
    )  
    return has_pattern  
  
  
def _encode_img(img: np.ndarray, ext: str) -> bytes:  
    ext = ext.lower()  
    if ext in [".jpg", ".jpeg"]:  
        ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 90])  
    elif ext == ".bmp":  
        ok, buf = cv2.imencode(".bmp", img)  
    else:  
        ok, buf = cv2.imencode(".png", img, [int(cv2.IMWRITE_PNG_COMPRESSION), 3])  
    if not ok:  
        raise RuntimeError("Image encoding failed.")  
    return buf.tobytes()  
  
##################PDF: Step-1 (pattern removal) – apply_redactions kw compatibility################# 
_SIG_APPLY = inspect.signature(fitz.Page.apply_redactions)  
_SUPPORTS_IMAGES_KW = "images" in _SIG_APPLY.parameters  
_SUPPORTS_GRAPHICS_KW = "graphics" in _SIG_APPLY.parameters  
  
REDACT_LINE_ART_OPTION = getattr(  
    fitz, "PDF_REDACT_LINE_ART_REMOVE_IF_COVERED", getattr(fitz, "PDF_REDACT_REMOVE_GRAPHICS_IF_COVERED", 0)  
)  
def _cover_vector_cleanup(page: fitz.Page, cover_bbox: fitz.Rect, cluster_rects: list[fitz.Rect]) -> None:  
      
    if not cluster_rects:  
        return  
  
    cover_area = max(_rect_area(cover_bbox), 1e-6)  
    any_redacts = False  
  
    ################## Drawings inside cover area that belong to an Inspire cluster#################  
    for d in page.get_drawings():  
        rect = d.get("rect")  
        if not rect:  
            continue  
        r = fitz.Rect(rect)  
        if not r.intersects(cover_bbox):  
            continue  
  
        ################## Only act if the drawing belongs to one of the Inspire clusters  #################
        overlap_to_cluster = _max_overlap_ratio_to_any(r, cluster_rects, ref_is="target")  
        if overlap_to_cluster < STRIPE_CLUSTER_MIN_OVERLAP:  
            continue  
  
        stroke, fill = _stroke_fill_colors(d)  
        fill_opac = float(d.get("fill_opacity") or 0.0)  
  
        ################## Red diagonal stripes (brand design) – strict check ################# 
        is_red_stripe = (_color_is_red(stroke) or _color_is_red(fill)) and _has_diagonal_stripe_geometry(d)  
  
        ################## Large near-white panels that sit over cluster (cause the white patch) ################# 
        r_area_vs_cover = _rect_area(r) / cover_area  
        is_cluster_white_panel = (  
            fill_opac > 0.0  
            and _is_white(fill, 245)  
            and r_area_vs_cover >= WHITE_PANEL_MIN_AREA_RATIO  
            and _max_overlap_ratio_to_any(r, cluster_rects, ref_is="target") >= WHITE_PANEL_OVERLAP_THR  
        )  
  
        if is_red_stripe or is_cluster_white_panel:  
            try:  
                page.add_redact_annot(r, fill=None)  #### remove vector ops, no paint  
                any_redacts = True  
            except Exception:  
                pass  
  
    # #################Pattern/Form XObjects – delete only if they overlap an Inspire cluster  #################
    try:  
        for xo in page.get_xobjects():  
            xref, name, bbox, subtype = _xo_info(page, xo)  
            if subtype not in ("/Pattern", "/Form") or not bbox:  
                continue  
            rb = fitz.Rect(bbox)  
            if not rb.intersects(cover_bbox):  
                continue  
            if _max_overlap_ratio_to_any(rb, cluster_rects, ref_is="target") >= STRIPE_CLUSTER_MIN_OVERLAP:  
                _del_resource(page, name)  
                any_redacts = True  
    except Exception:  
        pass  
  
    if any_redacts:  
        _apply_redactions_safe(  
            page,  
            images_opt=getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0),  # don't touch images  
            graphics_opt=getattr(fitz, "PDF_REDACT_LINE_ART_REMOVE_IF_COVERED",  
                                 getattr(fitz, "PDF_REDACT_REMOVE_GRAPHICS_IF_COVERED", 0)),  
        )  
        try:  
            page.clean_contents()  
        except Exception:  
            pass 
def _apply_redactions_safe(page: fitz.Page, *, images_opt=None, graphics_opt=None) -> None:  
    try:  
        sig = getattr(fitz.Page, "apply_redactions").__signature__  # type: ignore  
        kwargs = {}  
        if "images" in sig.parameters:  
            kwargs["images"] = images_opt if images_opt is not None else getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0)  
        if "graphics" in sig.parameters:  
            kwargs["graphics"] = graphics_opt if graphics_opt is not None else getattr(  
                fitz, "PDF_REDACT_LINE_ART_REMOVE_IF_COVERED", getattr(fitz, "PDF_REDACT_REMOVE_GRAPHICS_IF_COVERED", 0)  
            )  
        page.apply_redactions(**kwargs)  
    except Exception:  
        try:  
            page.apply_redactions()  
        except Exception:  
            pass   

######## zones for cover logos when the cover image itself is raster  ##############
COVER_TOP_LOGO_MAX_Y_PCT: float = 0.40    ####### "Hitachi Inspire" must sit in top 40% of the cover  
COVER_BOTTOM_LOGO_MIN_Y_PCT: float = 0.70 ####### "Hitachi Energy" must sit in bottom 30% of the cover  
  
########## size limits for any detected logo box inside the cover image (raster path)  #########
COVER_LOGO_MAX_AREA_RATIO: float = 0.12   ###### box area vs cover image area (max)  
COVER_LOGO_MAX_WIDTH_PCT: float = 0.55    ###### box width vs cover width (max)  
COVER_LOGO_MAX_HEIGHT_PCT: float = 0.22   ###### box height vs cover height (max)  
COVER_LOGO_MIN_ASPECT_INSP: float = 1.30  ###### width/height minimum for "HITACHI"/"Inspire" (avoid tall center boxes)  
COVER_LOGO_MIN_ASPECT_ENERGY: float = 1.00 ###### Energy lockup is wider than tall, but allow near‑square  
  
##########process_pdf_pipeline_inspire (transparent fallback + force black text on cover)  

def process_pdf_pipeline_inspire(  
    pdf_stream: io.BytesIO,  
    *,  
    template_cover: bool = False,  
    template_img: Optional[np.ndarray] = None,  
    area_ratio: float = 0.80,  
    width_ratio: float = 0.80,  
    height_ratio: float = 0.80,  
    overlap_threshold: float = 90.0,  
    debug: bool = True,  
    cover_pages: Optional[List[int]] = None,  
) -> io.BytesIO:  
    
  
    ########## Fallback transparent template when requested but missing  ###########
    if template_cover and (template_img is None or template_img is False):  
        fb = _fallback_transparent_template()  
        if fb is not None:  
            template_img = fb  
            if debug:  
                print("→ Using transparent fallback template (transparent1.png)")  
  
    ######### Global toggles / thresholds  #########
    PDF_DETECT_RASTER = bool(globals().get("PDF_DETECT_RASTER_INSPIRE_ON_COVER", True))  
    PRINT_FLAGS = bool(globals().get("PRINT_RASTER_INSPIRE_FLAGS", True))  
    RENDER_SCALE = int(globals().get("PDF_RASTER_INSP_DET_SCALE", 3))  
    NON_INSPIRE_OVERLAY_SCALE = int(globals().get("NON_INSPIRE_OVERLAY_SCALE", 2))  
  
    ########## Raster cover targeted cleanup toggles ########## 
    RASTER_COVER_KILL_OLD_LOGOS = bool(globals().get("RASTER_COVER_KILL_OLD_LOGOS", True))  
    RASTER_LOGO_WIPE_PAD_PCT = float(globals().get("RASTER_LOGO_WIPE_PAD_PCT", 0.12))  
    RASTER_LOGO_WIPE_MAX_PAD_PT = float(globals().get("RASTER_LOGO_WIPE_MAX_PAD_PT", 35.0))  
    RASTER_LOGO_WIPE_MAX_AREA_RATIO = float(globals().get("RASTER_LOGO_WIPE_MAX_AREA_RATIO", 0.22))  
    RASTER_LOGO_WIPE_MAX_HEIGHT_RATIO = float(globals().get("RASTER_LOGO_WIPE_MAX_HEIGHT_RATIO", 0.40))  
  
    ########### Underlay cleanup (raster-only) ########### 
    RASTER_LOGO_UNDERLAY_STRICT_CLEAN = bool(globals().get("RASTER_LOGO_UNDERLAY_STRICT_CLEAN", True))  
    RASTER_LOGO_WIPE_EXTRA_PAD_PCT = float(globals().get("RASTER_LOGO_WIPE_EXTRA_PAD_PCT", 0.04))  
    RASTER_LOGO_WIPE_EXPAND_TO_DRAWINGS = bool(globals().get("RASTER_LOGO_WIPE_EXPAND_TO_DRAWINGS", True))  
    RASTER_LOGO_WIPE_EXPAND_TO_TEXT = bool(globals().get("RASTER_LOGO_WIPE_EXPAND_TO_TEXT", True))  
    RASTER_LOGO_WIPE_MERGE_GAP_PT = float(globals().get("RASTER_LOGO_WIPE_MERGE_GAP_PT", 8.0))  
    RASTER_LOGO_WIPE_MAX_MERGED_AREA_RATIO = float(globals().get("RASTER_LOGO_WIPE_MAX_MERGED_AREA_RATIO", 0.24))  
    RASTER_LOGO_WIPE_NEUTRAL_COLOR_THR = int(globals().get("RASTER_LOGO_WIPE_NEUTRAL_COLOR_THR", 32))  
  
    ############## Confirmation/guard thresholds  ##########
    RASTER_STRIPE_CONFIRM_PARALLEL_MIN = int(globals().get("RASTER_STRIPE_CONFIRM_PARALLEL_MIN", 3))  
    RASTER_ORI_HIST_PEAK_MIN = float(globals().get("RASTER_ORI_HIST_PEAK_MIN", 0.33))  
    RASTER_BIG_RED_ONE_MAX = float(globals().get("RASTER_BIG_RED_ONE_MAX", 0.86))  
    RASTER_BIG_RED_TWO_MAX = float(globals().get("RASTER_BIG_RED_TWO_MAX", 0.80))  
    RASTER_CONF_SCORE_MIN = float(globals().get("RASTER_CONF_SCORE_MIN", 0.66))  
    RASTER_GRAD_DIAG_MIN = float(globals().get("RASTER_GRAD_DIAG_MIN", 0.30))  
    RASTER_GRAD_STRONG = float(globals().get("RASTER_GRAD_STRONG", 0.50))  
    RASTER_MAX_RED_AREA = float(globals().get("RASTER_MAX_RED_AREA", 0.22))  
    RASTER_STRONG_DIAG_FALLBACK = bool(globals().get("RASTER_STRONG_DIAG_FALLBACK", False))  
    ANGLE_CLUSTER_STD_MAX = float(globals().get("ANGLE_CLUSTER_STD_MAX", 10.0))  
    RASTER_STRIPE_MIN_COUNT = int(globals().get("RASTER_STRIPE_MIN_COUNT", 3))  
    RASTER_STRIPE_MIN_AREA_RATIO = float(globals().get("RASTER_STRIPE_MIN_AREA_RATIO", 0.010))  
  
     
    def _render_clip_bgr(page: "fitz.Page", clip: "fitz.Rect", scale: int = 3) -> Optional[np.ndarray]:  
        try:  
            pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=clip, alpha=False)  
            img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)  
            return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)  
        except Exception:  
            return None  
  
    def _xref_image_to_np_bgr(doc: "fitz.Document", xref: int) -> Optional[np.ndarray]:  
        try:  
            info = doc.extract_image(xref)  
            data = info.get("image", None)  
            if data:  
                arr = np.frombuffer(data, np.uint8)  
                img = cv2.imdecode(arr, cv2.IMREAD_COLOR)  
                if img is not None:  
                    return img  
        except Exception:  
            pass  
        try:  
            pix = fitz.Pixmap(doc, xref)  
            if pix.n not in (3, 4):  
                pix = fitz.Pixmap(fitz.csRGB, pix)  
            arr = np.frombuffer(pix.samples, np.uint8)  
            if pix.n == 4:  
                npimg = arr.reshape(pix.h, pix.w, 4)  
                return cv2.cvtColor(npimg, cv2.COLOR_RGBA2BGR)  
            else:  
                npimg = arr.reshape(pix.h, pix.w, 3)  
                return cv2.cvtColor(npimg, cv2.COLOR_RGB2BGR)  
        except Exception:  
            return None  
  
    def _detect_raster_inspire_on_cover(page: "fitz.Page", xref: int, bbox: "fitz.Rect") -> Tuple[bool, int, dict]:  
        best = (False, 0, {"source": "none", "conf_score": 0.0})  
        img_bgr = _xref_image_to_np_bgr(page.parent, xref)  
        if img_bgr is not None:  
            ok, cnt, m = _detect_raster_inspire_info(img_bgr)  
            m = dict(m or {}); m["source"] = "xref"  
            if (m.get("conf_score", 0.0) or 0.0) >= best[2].get("conf_score", 0.0):  
                best = (ok, cnt, m)  
        clip_bgr = _render_clip_bgr(page, bbox, scale=int(globals().get("PDF_RASTER_INSP_DET_SCALE", 2)))  
        if clip_bgr is not None:  
            ok, cnt, m = _detect_raster_inspire_info(clip_bgr)  
            m = dict(m or {}); m["source"] = "clip"  
            if (m.get("conf_score", 0.0) or 0.0) >= best[2].get("conf_score", 0.0):  
                best = (ok, cnt, m)  
        return best  
  
    def _analyze_inspire_metrics(drawings: List[dict]) -> Tuple[int, float, float, bool]:  
        REF_ANGLE = float(globals().get("REF_ANGLE", 45.0))  
        ANGLE_TOLERANCE = float(globals().get("ANGLE_TOLERANCE", 8.0))  
        MIN_STRIPE_LENGTH = float(globals().get("MIN_STRIPE_LENGTH", 20.0))  
        MIN_STRIPES_IN_CLUSTER = int(globals().get("MIN_STRIPES_IN_CLUSTER", 3))  
        MIN_TOTAL_LEN = float(globals().get("MIN_TOTAL_LEN", 120.0))  
        MAX_HV_RATIO = float(globals().get("MAX_HV_RATIO", 0.4))  
  
        diag_len = hv_len = 0.0  
        diag_cnt = hv_cnt = 0  
  
        for d in drawings:  
            stroke_clr, fill_clr = _stroke_fill_colors(d)  
            if not (_color_is_red(stroke_clr) or _color_is_red(fill_clr)):  
                continue  
            if d.get("do_stroke", False) and d.get("width", 0) < 0.4:  
                continue  
            for p1, p2 in _segments_from_drawing(d):  
                seg_len = math.hypot(p2[0] - p1[0], p2[1] - p1[1])  
                if seg_len < MIN_STRIPE_LENGTH:  
                    continue  
                ang = _seg_angle(p1, p2)  
                if ang is None:  
                    continue  
                if abs(ang - REF_ANGLE) <= ANGLE_TOLERANCE:  
                    diag_cnt += 1  
                    diag_len += seg_len  
                elif ang < 10 or ang > 80:  
                    hv_cnt += 1  
                    hv_len += seg_len  
  
        is_inspire = (  
            diag_cnt >= MIN_STRIPES_IN_CLUSTER  
            and diag_len >= MIN_TOTAL_LEN  
            and (not hv_len or (hv_len / diag_len) <= MAX_HV_RATIO)  
        )  
        return diag_cnt, diag_len, hv_len, is_inspire  
  
    def _non_inspire_cover_clusters(page: "fitz.Page", cover_bbox: "fitz.Rect") -> List["fitz.Rect"]:  
        clusters = page.cluster_drawings()  
        drawings = page.get_drawings()  
        keep: List[fitz.Rect] = []  
        for crect in clusters:  
            rc = fitz.Rect(crect)  
            if not rc.intersects(cover_bbox):  
                continue  
            cl_dr = [d for d in drawings if fitz.Rect(d.get("rect") or fitz.Rect()).intersects(rc)]  
            dcnt, dlen, hlen, is_inspire = _analyze_inspire_metrics(cl_dr)  
            if (not is_inspire) and (dcnt == 0):  
                keep.append(rc)  
        return keep  
  
    def _rasterize_rect_without_images_and_text(page: "fitz.Page", rect: "fitz.Rect", scale: int = NON_INSPIRE_OVERLAY_SCALE) -> bytes:  
        try:  
            doc_tmp = fitz.open()  
            try:  
                doc_tmp.insert_pdf(page.parent, from_page=page.number, to_page=page.number)  
            except Exception:  
                doc_tmp.insert_pdf(page.parent, page.number, page.number)  
            p2 = doc_tmp[0]  
  
            for (xref, *_) in p2.get_images(full=True):  
                try:  
                    rects_img = p2.get_image_rects(xref)  
                except Exception:  
                    rects_img = []  
                if any(fitz.Rect(r).intersects(rect) for r in rects_img):  
                    try:  
                        p2.replace_image(xref, stream=_transparent_png_bytes(2, 2))  
                    except Exception:  
                        pass  
  
            for b in p2.get_text("dict")["blocks"]:  
                if b["type"]:  
                    continue  
                for ln in b["lines"]:  
                    for sp in ln["spans"]:  
                        rb = fitz.Rect(sp["bbox"])  
                        if rb.intersects(rect) and sp.get("text", "").strip():  
                            rb.x0, rb.y0, rb.x1, rb.y1 = rb.x0 + 0.5, rb.y0 + 0.5, rb.x1 - 0.5, rb.y1 - 0.5  
                            try:  
                                p2.add_redact_annot(rb, fill=None)  
                            except Exception:  
                                pass  
  
            try:  
                p2.apply_redactions(images=getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0))  
            except Exception:  
                try:  
                    p2.apply_redactions()  
                except Exception:  
                    pass  
            try:  
                p2.clean_contents()  
            except Exception:  
                pass  
  
            pix = p2.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=rect, alpha=True)  
            out = pix.tobytes(output="png")  
            doc_tmp.close()  
            return out  
        except Exception:  
            try:  
                pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=rect, alpha=True)  
                return pix.tobytes(output="png")  
            except Exception:  
                return _transparent_png_bytes(max(1, int(rect.width)), max(1, int(rect.height)))  
  
    def _remove_images_in_rect(page: "fitz.Page", rect: "fitz.Rect") -> None:  
        try:  
            page.add_redact_annot(rect, fill=None)  
        except Exception:  
            pass  
        try:  
            images_remove_const = getattr(fitz, "PDF_REDACT_IMAGE_REMOVE", 1)  
            _apply_redactions_safe(page, images_opt=images_remove_const, graphics_opt=0)  
        except Exception:  
            try:  
                page.apply_redactions()  
            except Exception:  
                pass  
        try:  
            page.clean_contents()  
        except Exception:  
            pass  
  
    def _remove_xobjects_in_rects(page: "fitz.Page", rects: list["fitz.Rect"]) -> None:  
        if not rects:  
            return  
        try:  
            doc = page.parent  
            for xo in page.get_xobjects():  
                xref, name, bbox, subtype = _xo_info(page, xo)  
                if not bbox or subtype not in ("/Form", "/Pattern"):  
                    continue  
                rb = fitz.Rect(bbox)  
                if any((rb & r) == rb for r in rects):  
                    _del_resource(page, name)  
            try:  
                page.clean_contents()  
            except Exception:  
                pass  
        except Exception:  
            pass  
  
    def _expand_logo_wipe_rects(  
        page: "fitz.Page",  
        cover_bbox: "fitz.Rect",  
        wipe_rects: list["fitz.Rect"],  
        *,  
        extra_pad_pct: float = float(RASTER_LOGO_WIPE_EXTRA_PAD_PCT),  
        max_pad_pt: float = float(RASTER_LOGO_WIPE_MAX_PAD_PT),  
        merge_gap_pt: float = float(RASTER_LOGO_WIPE_MERGE_GAP_PT),  
        max_area_ratio: float = float(RASTER_LOGO_WIPE_MAX_MERGED_AREA_RATIO),  
        use_text: bool = bool(RASTER_LOGO_WIPE_EXPAND_TO_TEXT),  
        use_drawings: bool = bool(RASTER_LOGO_WIPE_EXPAND_TO_DRAWINGS),  
    ) -> list["fitz.Rect"]:  
        if not wipe_rects:  
            return wipe_rects  
  
        cover_area = max(abs(cover_bbox), 1e-6)  
        text_blocks = page.get_text("dict").get("blocks", []) if use_text else []  
        drawings = page.get_drawings() if use_drawings else []  
  
        def _merge_close_rects(rects: list["fitz.Rect"], gap_pt: float = float(RASTER_LOGO_WIPE_MERGE_GAP_PT), clip: "fitz.Rect" | None = None) -> list["fitz.Rect"]:  
            if not rects:  
                return []  
            expanded = [fitz.Rect(r.x0 - gap_pt, r.y0 - gap_pt, r.x1 + gap_pt, r.y1 + gap_pt) for r in rects]  
            used = [False] * len(expanded)  
            out: list[fitz.Rect] = []  
            for i, ri in enumerate(expanded):  
                if used[i]:  
                    continue  
                base = fitz.Rect(rects[i])  
                used[i] = True  
                changed = True  
                while changed:  
                    changed = False  
                    for j in range(i + 1, len(expanded)):  
                        if used[j]:  
                            continue  
                        if ri.intersects(expanded[j]):  
                            base = base | rects[j]  
                            ri = ri | expanded[j]  
                            used[j] = True  
                            changed = True  
                if clip is not None:  
                    base = base & clip  
                if not base.is_empty:  
                    out.append(base)  
            return out  
  
        results: list[fitz.Rect] = []  
  
        for wr in wipe_rects:  
            wr_pad = _expand_rect_pct(wr, extra_pad_pct, max_pad_pt, clip=cover_bbox)  
            group_rects = [fitz.Rect(wr_pad)]  
  
            if use_text:  
                for b in text_blocks:  
                    if b.get("type", 1) != 0:  
                        continue  
                    for ln in b.get("lines", []):  
                        for sp in ln.get("spans", []):  
                            s = (sp.get("text") or "").lower()  
                            if not s.strip():  
                                continue  
                            if not any(k in s for k in KEYWORDS_HITACHI):  
                                continue  
                            rb = fitz.Rect(sp.get("bbox"))  
                            if rb.intersects(wr_pad):  
                                group_rects.append(rb)  
  
            if use_drawings:  
                for d in drawings:  
                    r = d.get("rect")  
                    if not r:  
                        continue  
                    dr = fitz.Rect(r)  
                    if not dr.intersects(cover_bbox):  
                        continue  
                    if not dr.intersects(wr_pad):  
                        continue  
                    if abs(dr) / cover_area > 0.25:  
                        continue  
  
                    stroke_rgb, fill_rgb = _stroke_fill_colors(d)  
  
                    def _to_255(rgb01: tuple[float, float, float]) -> tuple[int, int, int]:  
                        r, g, b = rgb01  
                        if max(r, g, b) <= 1.0:  
                            return int(round(r * 255)), int(round(g * 255)), int(round(b * 255))  
                        return int(round(r)), int(round(g)), int(round(b))  
  
                    def _is_near_black(rgb01: tuple[float, float, float], thr: int = int(RASTER_LOGO_WIPE_NEUTRAL_COLOR_THR)) -> bool:  
                        r, g, b = _to_255(rgb01); return max(r, g, b) <= thr  
  
                    def _is_near_white(rgb01: tuple[float, float, float], thr: int = 255 - int(RASTER_LOGO_WIPE_NEUTRAL_COLOR_THR)) -> bool:  
                        r, g, b = _to_255(rgb01); return min(r, g, b) >= thr  
  
                    def _is_near_gray(rgb01: tuple[float, float, float], spread_thr: int = 28, lo: int = 30, hi: int = 225) -> bool:  
                        r, g, b = _to_255(rgb01)  
                        if min(r, g, b) < lo or max(r, g, b) > hi:  
                            return False  
                        return max(abs(r - g), abs(g - b), abs(r - b)) <= spread_thr  
  
                    def _is_logo_neutral_colour(stroke_rgb01: tuple[float, float, float], fill_rgb01: tuple[float, float, float]) -> bool:  
                        return (  
                            _is_near_black(stroke_rgb01) or _is_near_white(stroke_rgb01) or _is_near_gray(stroke_rgb01)  
                            or _is_near_black(fill_rgb01) or _is_near_white(fill_rgb01) or _is_near_gray(fill_rgb01)  
                        )  
  
                    if _is_logo_neutral_colour(stroke_rgb, fill_rgb):  
                        group_rects.append(dr)  
  
            merged_list = _merge_close_rects(group_rects, gap_pt=merge_gap_pt, clip=cover_bbox)  
            if not merged_list:  
                continue  
            merged = merged_list[0]  
            for i in range(1, len(merged_list)):  
                merged = merged | merged_list[i]  
            if abs(merged) / cover_area > max_area_ratio:  
                merged = wr_pad  
            results.append(merged)  
  
        results = _merge_close_rects(results, gap_pt=merge_gap_pt, clip=cover_bbox)  
        return results  
  
    def _get_logo_overlays_and_wipe_rects_from_cover_clip(  
        page: "fitz.Page",  
        cover_bbox: "fitz.Rect",  
        *,  
        scale: int = RENDER_SCALE,  
    ) -> tuple[list[tuple["fitz.Rect", bytes]], list["fitz.Rect"]]:  
        overlays: list[tuple[fitz.Rect, bytes]] = []  
        wipe_rects: list[fitz.Rect] = []  
        try:  
            pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=cover_bbox, alpha=False)  
            pil_clip = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)  
  
            detections = final_logo_boxes(pil_clip)  
            if not any("hitachi energy" in d["label"].lower() for d in detections):  
                detections.extend(detect_logo_only_page(pil_clip))  
  
            for d in detections:  
                x1, y1, x2, y2 = map(int, d["box"])  
                dest = fitz.Rect(  
                    cover_bbox.x0 + (x1 / float(scale)),  
                    cover_bbox.y0 + (y1 / float(scale)),  
                    cover_bbox.x0 + (x2 / float(scale)),  
                    cover_bbox.y0 + (y2 / float(scale)),  
                )  
                if dest.is_empty:  
                    continue  
  
                if "energy" in d["label"].lower():  
                    logo_rgba = _prep_logo("hitachi_energy", int(dest.width), int(dest.height))  
                else:  
                    fg_rgb = _dominant_text_colour_simplified(pil_clip, (x1, y1, x2, y2))  
                    logo_rgba = _prep_logo("hitachi_inspire", int(dest.width), int(dest.height))  
                    if fg_rgb is not None:  
                        logo_rgba = _recolour_logo(logo_rgba, fg_rgb)  
  
                ok, buf = cv2.imencode(".png", logo_rgba, [int(cv2.IMWRITE_PNG_COMPRESSION), 3])  
                if ok:  
                    overlays.append((dest, buf.tobytes()))  
  
                wr = _expand_rect_pct(dest, RASTER_LOGO_WIPE_PAD_PCT, RASTER_LOGO_WIPE_MAX_PAD_PT, clip=cover_bbox)  
                if _is_reasonable_logo_wipe_rect(wr, cover_bbox):  
                    wipe_rects.append(wr)  
  
            if RASTER_LOGO_UNDERLAY_STRICT_CLEAN and wipe_rects:  
                wipe_rects = _expand_logo_wipe_rects(page, cover_bbox, wipe_rects)  
        except Exception:  
            pass  
        return overlays, wipe_rects  
  
      
    if cover_pages is None:  
        cover_pages = [0, 1]  
  
    doc = fitz.open(stream=pdf_stream, filetype="pdf")  
  
    prepared: Dict[int, Tuple[fitz.Rect, Optional[bytes]]] = {}  
    cover_clusters_map: Dict[int, list[fitz.Rect]] = {}  
    cover_preserve_overlays_map: Dict[int, List[Tuple[fitz.Rect, bytes]]] = {}  
    cover_insert_on_top_map: Dict[int, bool] = {}  
    cover_logo_overlays_map: Dict[int, List[Tuple[fitz.Rect, bytes]]] = {}  
    prepared_xref_map: Dict[int, int] = {}  
    raster_detection_summary: Dict[int, Tuple[bool, int, dict]] = {}  
    cover_logo_wipe_rects_map: Dict[int, List[fitz.Rect]] = {}  
    prepared_cover_img_map: Dict[int, Optional[np.ndarray]] = {}  
    vector_cluster_summary: Dict[int, Dict[str, float]] = {}  
    vector_inspire_on_cover_map: Dict[int, bool] = {}              ######## new flag per page  
    prepared_reason_map: Dict[int, Set[str]] = {}                  ######### {'vector','raster'}  
    cover_replaced_map: Dict[int, bool] = {}                       ######### did we replace?  
    cover_replaced_due_vector_map: Dict[int, bool] = {}            ######### replaced because vector Inspire detected  
  
    ###### PASS 0: Inspect cover pages ######### 
    for pno in cover_pages:  
        if pno >= len(doc):  
            continue  
        page = doc[pno]  
        info = cover_image_xref_bbox(page, area_ratio_thr=area_ratio, width_ratio_thr=0.90, height_ratio_thr=0.90)  
        if not info:  
            continue  
        xref, bbox = info  
        prepared_xref_map[pno] = xref  
  
        ########## Vector clusters in cover  ##########
        clusters_in_cover = inspire_clusters(page, restrict_to=bbox)  
        cover_clusters_map[pno] = clusters_in_cover  
        vector_inspire_on_cover_map[pno] = bool(clusters_in_cover)  
  
        ######### Vector metrics for summary  ###########
        try:  
            drawings_all = page.get_drawings()  
            v_diag_total = 0.0  
            v_hv_total = 0.0  
            v_stripe_cnt_total = 0  
            for crect in clusters_in_cover:  
                cl_dr = [d for d in drawings_all if fitz.Rect(d.get("rect") or fitz.Rect()).intersects(crect)]  
                dcnt, dlen, hlen, _ = _analyze_inspire_metrics(cl_dr)  
                v_stripe_cnt_total += int(dcnt)  
                v_diag_total += float(dlen)  
                v_hv_total += float(hlen)  
            vector_cluster_summary[pno] = {  
                "clusters": float(len(clusters_in_cover)),  
                "v_stripes": float(v_stripe_cnt_total),  
                "v_diag_len": float(v_diag_total),  
                "v_hv_len": float(v_hv_total),  
                "v_hv_ratio": float(v_hv_total / v_diag_total) if v_diag_total > 0 else 0.0,  
            }  
        except Exception:  
            vector_cluster_summary[pno] = {  
                "clusters": float(len(clusters_in_cover)),  
                "v_stripes": 0.0,  
                "v_diag_len": 0.0,  
                "v_hv_len": 0.0,  
                "v_hv_ratio": 0.0,  
            }  
  
        ############ Raster detection when no vector clusters##############  
        raster_inspire_found, stripe_cnt, metrics = (False, 0, {})  
        if not clusters_in_cover and PDF_DETECT_RASTER:  
            try:  
                raster_inspire_found, stripe_cnt, metrics = _detect_raster_inspire_on_cover(page, xref, bbox)  
            except Exception:  
                raster_inspire_found, stripe_cnt, metrics = (False, 0, {"error": "exception"})  
  
        ############# Confidence override for false-negatives  ###############
        min_replace_stripes = int(globals().get("RASTER_STRIPE_REPLACE_MIN_COUNT", RASTER_STRIPE_MIN_COUNT))  
        diag_ok = metrics.get("diag_ratio", 0.0) >= RASTER_GRAD_DIAG_MIN  
        strong_diag = metrics.get("diag_ratio", 0.0) >= RASTER_GRAD_STRONG  
        par_ok = (metrics.get("parallel_lines", 0) >= RASTER_STRIPE_CONFIRM_PARALLEL_MIN) or (metrics.get("ori_peak", 0.0) >= RASTER_ORI_HIST_PEAK_MIN)  
        conf_ok = metrics.get("conf_score", 0.0) >= RASTER_CONF_SCORE_MIN  
        big2_ok = metrics.get("big_red2", 1.0) <= (RASTER_BIG_RED_TWO_MAX + 0.02)  
        use_big1 = metrics.get("stripes_src", "cc") == "cc"  
        big1_ok = (metrics.get("big_red1", 1.0) <= RASTER_BIG_RED_ONE_MAX) if use_big1 else True  
        area_ok = metrics.get("stripe_area", 0.0) >= RASTER_STRIPE_MIN_AREA_RATIO  
        red_area_ratio = metrics.get("red_area", 0.0)  
        angle_std_ok = metrics.get("angle_std", ANGLE_CLUSTER_STD_MAX) <= ANGLE_CLUSTER_STD_MAX  
  
        conf_override = bool(  
            (stripe_cnt >= max(1, min_replace_stripes))  
            and conf_ok  
            and (diag_ok or strong_diag)  
            and area_ok  
            and big2_ok and big1_ok  
            and angle_std_ok  
            and (red_area_ratio <= (RASTER_MAX_RED_AREA + 0.04))  
        )  
  
        effective_inspire_found = raster_inspire_found or conf_override  
        raster_detection_summary[pno] = (effective_inspire_found, stripe_cnt, metrics)  
  
        ############ Replacement gate using effective flag  ############
        raster_replace_ok = bool(  
            effective_inspire_found  
            and (stripe_cnt >= max(1, min_replace_stripes))  
            and diag_ok and big2_ok and big1_ok  
            and (par_ok or conf_ok)  
        )  
  
        ############  strong-diagonal fallback ########### 
        if (  
            (not raster_replace_ok)  
            and effective_inspire_found  
            and (stripe_cnt >= min_replace_stripes)  
            and strong_diag  
            and big2_ok  
            and big1_ok  
            and RASTER_STRONG_DIAG_FALLBACK  
            and par_ok  
        ):  
            raster_replace_ok = True  
            if PRINT_FLAGS:  
                print(f"Cover p{pno+1}: raster_inspire strong-diagonal fallback (orientation confirmed) → replace_ok=True")  
  
        ########### Extra guard: huge red coverage with weak orientation -> block replacement ######### 
        if raster_replace_ok and (red_area_ratio > RASTER_MAX_RED_AREA) and (not par_ok):  
            raster_replace_ok = False  
  
        ########### Track reasons we prepare a new cover image ###########
        reasons: Set[str] = set()  
        if clusters_in_cover:  
            reasons.add("vector")  
        if raster_replace_ok:  
            reasons.add("raster")  
        prepared_reason_map[pno] = reasons  
  
        ########## If no vector clusters AND raster gate fails -> leave cover untouched  ##########
        if not clusters_in_cover and not raster_replace_ok:  
            prepared_cover_img_map[pno] = None  
            continue  
  
        ########## Non-Inspire clusters overlapped with cover -> rasterize overlays (no text)  ##########
        try:  
            preserve_clusters_in_cover = _non_inspire_cover_clusters(page, cover_bbox=bbox)  
        except Exception:  
            preserve_clusters_in_cover = []  
        if preserve_clusters_in_cover:  
            overlays: List[Tuple[fitz.Rect, bytes]] = []  
            for rc in preserve_clusters_in_cover:  
                dest = fitz.Rect(rc) & bbox  
                if dest.is_empty:  
                    continue  
                png_bytes = _rasterize_rect_without_images_and_text(page, dest, NON_INSPIRE_OVERLAY_SCALE)  
                overlays.append((dest, png_bytes))  
            if overlays:  
                cover_preserve_overlays_map[pno] = overlays  
  
        ########## (raster cover) prepare rebrand overlays + wipe rectangles for old logos  ##########
        if raster_replace_ok and RASTER_COVER_KILL_OLD_LOGOS:  
            overlays, wipe_rects = _get_logo_overlays_and_wipe_rects_from_cover_clip(page, bbox, scale=RENDER_SCALE)  
            if overlays:  
                cover_logo_overlays_map[pno] = overlays  
            if wipe_rects:  
                cover_logo_wipe_rects_map[pno] = wipe_rects  
        elif raster_replace_ok:  
            try:  
                cover_logo_overlays_map[pno] = _get_logo_overlays_and_wipe_rects_from_cover_clip(page, bbox, scale=RENDER_SCALE)[0]  
            except Exception:  
                cover_logo_overlays_map[pno] = []  
  
        ########## Prepare replacement cover bytes (template or blank) if needed ##########
        if clusters_in_cover or raster_replace_ok:  
            tw, th = int(bbox.width), int(bbox.height)  
            if template_cover:  
                if template_img is not None:  
                    fitted = resize_template_exact(template_img, tw, th)  
                    prepared_cover_img_map[pno] = fitted.copy()  
                    cover_bytes = cv2.imencode(".png", fitted, [int(cv2.IMWRITE_PNG_COMPRESSION), 3])[1].tobytes()  
                    prepared[pno] = (bbox, cover_bytes)  
                else:  
                    blank_np, blank_bytes = _blank_cover_png_for_bbox(bbox)  
                    prepared_cover_img_map[pno] = blank_np.copy()  
                    prepared[pno] = (bbox, blank_bytes)  
            else:  
                prepared_cover_img_map[pno] = None  
  
            cover_insert_on_top_map[pno] = True if clusters_in_cover else False  
            cover_replaced_map[pno] = False  
            cover_replaced_due_vector_map[pno] = False  
  
    ########## PASS 1: Global vector cleanup + precise cleanup in cover area ##########
    for page in doc:  
        pno = page.number  
  
        clusters = inspire_clusters(page, restrict_to=None)  
        for crect in clusters:  
            try:  
                page.add_redact_annot(fitz.Rect(crect), fill=None)  
            except Exception:  
                pass  
        if clusters:  
            _apply_redactions_safe(  
                page,  
                images_opt=getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0),  
                graphics_opt=getattr(  
                    fitz, "PDF_REDACT_LINE_ART_REMOVE_IF_COVERED",  
                    getattr(fitz, "PDF_REDACT_REMOVE_GRAPHICS_IF_COVERED", 0)  
                ),  
            )  
            try:  
                page.clean_contents()  
            except Exception:  
                pass  
  
        if pno in prepared or pno in cover_clusters_map:  
            cover_bbox = prepared[pno][0] if pno in prepared else None  
            if cover_bbox is None:  
                info2 = cover_image_xref_bbox(page, area_ratio_thr=area_ratio, width_ratio_thr=0.90, height_ratio_thr=0.90)  
                if info2:  
                    cover_bbox = info2[1]  
            if cover_bbox is not None:  
                _cover_vector_cleanup(page, cover_bbox, cover_clusters_map.get(pno, []))  
  
            raster_ok = raster_detection_summary.get(pno, (False, 0, {}))[0]  
            if raster_ok and RASTER_COVER_KILL_OLD_LOGOS:  
                wipe_rects = cover_logo_wipe_rects_map.get(pno, [])  
                if wipe_rects:  
                    try:  
                        _remove_text_in_rects(page, wipe_rects)  
                    except Exception:  
                        pass  
                    try:  
                        _remove_graphics_in_rects(page, wipe_rects)  
                    except Exception:  
                        pass  
                    try:  
                        _remove_xobjects_in_rects(page, wipe_rects)  
                    except Exception:  
                        pass  
  
    ########## PASS 2: Insert new cover + overlays ##########
    for pno, tup in prepared.items():  
        if pno >= len(doc):  
            continue  
        page = doc[pno]  
  
        if not tup or tup[1] is None:  
            continue  
  
        bbox, img_bytes = tup  
        raster_ok = raster_detection_summary.get(pno, (False, 0, {}))[0]  
  
        did_replace = False  
        if pno in prepared_xref_map:  
            try:  
                page.insert_image(bbox, stream=img_bytes, overlay=True)  
                did_replace = True  
                if PRINT_FLAGS:  
                    print(f"Cover p{pno+1}: replaced original cover image by xref={prepared_xref_map[pno]}")  
            except Exception:  
                did_replace = False  
  
        if not did_replace:  
            if raster_ok:  
                _remove_images_in_rect(page, bbox)  
                try:  
                    page.insert_image(bbox, stream=img_bytes, overlay=False)  
                    did_replace = True  
                    if PRINT_FLAGS:  
                        print(f"Cover p{pno+1}: inserted new cover after hard image removal (background)")  
                except Exception:  
                    info2 = cover_image_xref_bbox(page, area_ratio_thr=area_ratio, width_ratio_thr=0.90, height_ratio_thr=0.90)  
                    if info2:  
                        try:  
                            page.replace_image(info2[0], stream=img_bytes)  
                            did_replace = True  
                            if PRINT_FLAGS:  
                                print(f"Cover p{pno+1}: replaced cover via fallback xref={info2[0]}")  
                        except Exception:  
                            pass  
            else:  
                try:  
                    page.insert_image(bbox, stream=img_bytes, overlay=cover_insert_on_top_map.get(pno, True))  
                    did_replace = True  
                    if PRINT_FLAGS:  
                        print(f"Cover p{pno+1}: inserted replacement cover (overlay={cover_insert_on_top_map.get(pno, True)})")  
                except Exception:  
                    pass  
  
        ########## Track replacement flags (overall and due to vector detection) ########## 
        cover_replaced_map[pno] = bool(did_replace)  
        cover_replaced_due_vector_map[pno] = bool(did_replace and ("vector" in prepared_reason_map.get(pno, set())))  
  
        ########## Re-overlay preserved non-Inspire drawings (pre-rendered without text) ########## 
        overlay_rects: List[fitz.Rect] = []  
        for (dest_rect, png_bytes) in cover_preserve_overlays_map.get(pno, []):  
            try:  
                page.insert_image(dest_rect, stream=png_bytes, overlay=True)  
                overlay_rects.append(fitz.Rect(dest_rect))  
            except Exception:  
                pass  
  
        fitted_cover_np = prepared_cover_img_map.get(pno)  
        if raster_ok and fitted_cover_np is not None and cover_logo_overlays_map.get(pno):  
            tw, th = int(bbox.width), int(bbox.height)  
            for (dest_rect, _logo_png) in cover_logo_overlays_map.get(pno, []):  
                rx0 = max(0, int(round(dest_rect.x0 - bbox.x0)))  
                ry0 = max(0, int(round(dest_rect.y0 - bbox.y0)))  
                rx1 = min(tw, int(round(dest_rect.x1 - bbox.x0)))  
                ry1 = min(th, int(round(dest_rect.y1 - bbox.y0)))  
                if rx1 <= rx0 or ry1 <= ry0:  
                    continue  
                patch = fitted_cover_np[ry0:ry1, rx0:rx1]  
                ok, patch_buf = cv2.imencode(".png", patch, [int(cv2.IMWRITE_PNG_COMPRESSION), 3])  
                if ok:  
                    try:  
                        page.insert_image(dest_rect, stream=patch_buf.tobytes(), overlay=True)  
                        overlay_rects.append(fitz.Rect(dest_rect))  
                    except Exception:  
                        pass  
  
        for (dest_rect, png_bytes) in cover_logo_overlays_map.get(pno, []):  
            try:  
                page.insert_image(dest_rect, stream=png_bytes, overlay=True)  
                overlay_rects.append(fitz.Rect(dest_rect))  
            except Exception:  
                pass  
  
        try:  
            if overlay_rects:  
                _re_font_in_rects(page, "HZ", overlay_rects)  
        except Exception:  
            pass  
  
        if globals().get("FORCE_BLACK_TEXT_ON_COVER", False) and bbox is not None:  
            try:  
                _re_font_in_rects(page, "HZ", [bbox], force_rgb=(0.0, 0.0, 0.0))  
            except Exception:  
                pass  
  
    ########## Summary prints (raster + vector flags + replacement cause) ########## 
    if PRINT_FLAGS and raster_detection_summary:  
        for pno, (ok, cnt, metrics) in raster_detection_summary.items():  
            src = metrics.get("source", "?")  
            print(  
                f"[SUMMARY] p{pno+1}: Raster Inspire={ok} | stripes={cnt} | src={src} | "  
                f"score={metrics.get('conf_score',0.0):.3f} | red={metrics.get('red_area',0.0):.3f} | "  
                f"diag={metrics.get('diag_ratio',0.0):.3f} | parallel={metrics.get('parallel_lines',0)} | "  
                f"ori_peak={metrics.get('ori_peak',0.0):.3f}"  
            )  
            vstat = vector_cluster_summary.get(pno, {})  
            v_flag = vector_inspire_on_cover_map.get(pno, False)  
            print(  
                f"[SUMMARY] p{pno+1}: Vector Inspire on cover={v_flag} | "  
                f"vector_clusters={int(vstat.get('clusters',0))} | "  
                f"v_stripes={int(vstat.get('v_stripes',0))} | "  
                f"v_diag_len={vstat.get('v_diag_len',0.0):.1f} | "  
                f"v_hv_len={vstat.get('v_hv_len',0.0):.1f} | "  
                f"v_hv_ratio={vstat.get('v_hv_ratio',0.0):.3f}"  
            )  
            replaced = cover_replaced_map.get(pno, False)  
            replaced_vec = cover_replaced_due_vector_map.get(pno, False)  
            reasons = ",".join(sorted(prepared_reason_map.get(pno, set()))) or "none"  
            print(  
                f"[SUMMARY] p{pno+1}: Cover replaced={replaced} | "  
                f"replaced_due_to_vector={replaced_vec} | reason={reasons}"  
            )  
  
      
    out = io.BytesIO()  
    doc.save(out, garbage=4, deflate=True, clean=True)  
    doc.close()  
    out.seek(0)  
    return out  
  
# ################# LOGO OVERLAY (images) #################  
def _overlay_logo_on_image(  
    img: np.ndarray,  
    logo_path: str,  
    position: str = "top-right",  
    margin: int = 20,  
    logo_size: tuple = (120, 40),  
) -> np.ndarray:  
    logger.info(f"🔄 Overlaying logo from {logo_path} at {position}")  
    try:  
        logo = cv2.imread(logo_path, cv2.IMREAD_UNCHANGED)  
        if logo is None:  
            logger.error(f"❌ Could not load logo from {logo_path}")  
            if DEBUG:  
                print(f"⚠ Could not load logo from {logo_path}")  
            return img  
        logger.info(f"✅ Logo loaded: {logo.shape}")  
        logo = cv2.resize(logo, logo_size, interpolation=cv2.INTER_LANCZOS4)  
  
        if logo.shape[2] == 4:  
            logo_rgb = logo[:, :, :3]  
            alpha = logo[:, :, 3]  
        else:  
            logo_rgb = logo  
            gray = cv2.cvtColor(logo, cv2.COLOR_BGR2GRAY)  
            _, alpha = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)  
  
        logo_black = np.zeros_like(logo_rgb)  
        logo_black[alpha > 0] = [0, 0, 0]  
  
        img_h, img_w = img.shape[:2]  
        logo_h, logo_w = logo_black.shape[:2]  
  
        if position == "top-right":  
            start_y = margin  
            start_x = img_w - logo_w - margin  
        elif position == "top-left":  
            start_y = margin  
            start_x = margin  
        elif position == "bottom-right":  
            start_y = img_h - logo_h - margin  
            start_x = img_w - logo_w - margin  
        else:  #### bottom-left  
            start_y = img_h - logo_h - margin  
            start_x = margin  
  
        end_y = min(start_y + logo_h, img_h)  
        end_x = min(start_x + logo_w, img_w)  
        actual_logo_h = end_y - start_y  
        actual_logo_w = end_x - start_x  
  
        if actual_logo_h <= 0 or actual_logo_w <= 0:  
            logger.warning("⚠️ Logo doesn't fit in image bounds")  
            if DEBUG:  
                print("⚠ Logo doesn't fit in image")  
            return img  
  
        img_roi = img[start_y:end_y, start_x:end_x]  
        logo_roi = logo_black[:actual_logo_h, :actual_logo_w]  
        alpha_roi = alpha[:actual_logo_h, :actual_logo_w]  
  
        alpha_norm = alpha_roi.astype(np.float32) / 255.0  
        alpha_norm = np.expand_dims(alpha_norm, axis=2)  
  
        blended = img_roi.astype(np.float32) * (1 - alpha_norm) + logo_roi.astype(np.float32) * alpha_norm  
        img[start_y:end_y, start_x:end_x] = blended.astype(np.uint8)  
  
        logger.info(f"✅ Logo overlayed successfully at {position}")  
        if DEBUG:  
            print(f"✓ Logo overlayed at {position} position on cover image")  
  
        return img  
    except Exception as e:  
        logger.error(f"❌ Error overlaying logo: {e}")  
        if DEBUG:  
            print(f"⚠ Error overlaying logo: {e}")  
        return img  
  
# ################# DOCX: Step-1 (cover/pattern) #################  
  
def process_docx_pipeline_inspire_new(  
    docx_bytes: bytes,  
    template_cover: bool = False,  
    template_img: Optional[np.ndarray] = None,  
) -> bytes:  
    logger.info("🚀 Starting DOCX pipeline for Inspire pattern processing (new version)")  
    logger.info(f"📋 Parameters: template_cover={template_cover}, template_img={'provided' if template_img is not None else 'None'}")  
  
    ####### Fallback to transparent template when requested but missing ####### 
    tpl_img = template_img  
    if template_cover and (tpl_img is None or tpl_img is False):  
        fb = _fallback_transparent_template()  
        if fb is not None:  
            tpl_img = fb  
            logger.info("→ Using transparent fallback template (transparent1.png)")  
  
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as zin:  
        names = zin.namelist()  
        original_bytes = {n: zin.read(n) for n in names}  
        logger.info(f"📄 DOCX contains {len(names)} files")  
  
    replacements: dict[str, bytes] = {}  
    first_image_processed = False  
    media_files = [n for n in names if n.startswith("word/media/")]  
    logger.info(f"📷 Found {len(media_files)} media files")  
  
    for name in media_files:  
        ext = os.path.splitext(name)[1].lower()  
        if ext not in (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff"):  
            logger.info(f"⏭️ Skipping non-image file: {name}")  
            continue  
  
        logger.info(f"🔍 Processing image: {name}")  
        img_arr = np.frombuffer(original_bytes[name], np.uint8)  
        img = cv2.imdecode(img_arr, cv2.IMREAD_COLOR)  
        if img is None:  
            logger.warning(f"⚠️ Could not decode image: {name}")  
            continue  
  
        logger.info(f"📊 Image {name}: {img.shape}")  
        is_cover_image = False  
        if not first_image_processed:  
            img_h, img_w = img.shape[:2]  
            img_area = img_h * img_w  
            logger.info(f"📏 Image area: {img_area}")  
            if img_area > 100000:  
                is_cover_image = True  
                first_image_processed = True  
                logger.info(f"✅ Identified as cover image: {name}")  
  
        has_pattern = _detect_red_diagonal_pattern(img)  
        if has_pattern:  
            logger.info(f"🎯 Red diagonal pattern detected in {name}")  
            if template_cover and tpl_img is not None:  
                logger.info(f"🔄 Replacing with template image (fallback used if needed)")  
                h, w = img.shape[:2]  
                fitted = cv2.resize(  
                    tpl_img,  
                    (w, h),  
                    interpolation=cv2.INTER_AREA if (w < tpl_img.shape[1] or h < tpl_img.shape[0]) else cv2.INTER_LINEAR,  
                )  
                if is_cover_image and ADD_COVER_LOGO_DOCX:  
                    logger.info("🏷️ Adding logo to cover page")  
                    logo_file = REPLACEMENT_LOGOS.get("hitachi_inspire")  
                    if logo_file:  
                        logo_paths = [Path(logo_file), Path.cwd() / logo_file]  
                        if "__file__" in globals():  
                            logo_paths.append(Path(__file__).parent / logo_file)  
                        for logo_path in logo_paths:  
                            if logo_path.exists():  
                                logger.info(f"✅ Found logo at: {logo_path}")  
                                fitted = _overlay_logo_on_image(  
                                    fitted,  
                                    str(logo_path),  
                                    position="top-right",  
                                    margin=COVER_LOGO_MARGIN_RIGHT,  
                                    logo_size=COVER_LOGO_SIZE,  
                                )  
                                break  
                        else:  
                            logger.error("❌ Logo file not found for cover page")  
                replacements[name] = _encode_img(fitted, ext)  
                logger.info(f"✅ Template replacement completed for {name}")  
            else:  
                logger.info(f"🔄 Replacing with blank image")  
                blank = np.full_like(img, 255)  
                if is_cover_image and ADD_COVER_LOGO_DOCX:  
                    logger.info("🏷️ Adding logo to blank cover page")  
                    logo_file = REPLACEMENT_LOGOS.get("hitachi_inspire")  
                    if logo_file:  
                        logo_paths = [Path(logo_file), Path.cwd() / logo_file]  
                        if "__file__" in globals():  
                            logo_paths.append(Path(__file__).parent / logo_file)  
                        for logo_path in logo_paths:  
                            if logo_path.exists():  
                                logger.info(f"✅ Found logo at: {logo_path}")  
                                blank = _overlay_logo_on_image(  
                                    blank,  
                                    str(logo_path),  
                                    position="top-right",  
                                    margin=COVER_LOGO_MARGIN_RIGHT,  
                                    logo_size=COVER_LOGO_SIZE,  
                                )  
                                break  
                        else:  
                            logger.error("❌ Logo file not found for blank cover page")  
                replacements[name] = _encode_img(blank, ext)  
                logger.info(f"✅ Blank replacement completed for {name}")  
        elif is_cover_image and ADD_COVER_LOGO_DOCX:  
            logger.info(f"🏷️ Adding logo to cover image without red pattern: {name}")  
            logo_file = REPLACEMENT_LOGOS.get("hitachi_inspire")  
            if logo_file:  
                logo_paths = [Path(logo_file), Path.cwd() / logo_file]  
                if "__file__" in globals():  
                    logo_paths.append(Path(__file__).parent / logo_file)  
                for logo_path in logo_paths:  
                    if logo_path.exists():  
                        logger.info(f"✅ Found logo at: {logo_path}")  
                        img_with_logo = _overlay_logo_on_image(  
                            img,  
                            str(logo_path),  
                            position="top-right",  
                            margin=COVER_LOGO_MARGIN_RIGHT,  
                            logo_size=COVER_LOGO_SIZE,  
                        )  
                        replacements[name] = _encode_img(img_with_logo, ext)  
                        break  
                else:  
                    logger.error("❌ Logo file not found for cover image")  
        else:  
            logger.info(f"⏭️ No processing needed for {name}")  
  
    logger.info(f"🔄 Rebuilding DOCX with {len(replacements)} replaced files")  
    output_buffer = io.BytesIO()  
    with zipfile.ZipFile(output_buffer, "w", compression=zipfile.ZIP_DEFLATED) as zout:  
        for n in names:  
            zout.writestr(n, replacements.get(n, original_bytes[n]))  
        logger.info("✅ DOCX pipeline completed successfully")  
    return output_buffer.getvalue()  
 
  
# ################# Utilities #################  
def ensure_dir(p: Path | str) -> None:  
    Path(p).mkdir(parents=True, exist_ok=True)  
  
def pil2bytes(img: Image.Image, fmt: str = "PNG") -> bytes:  
    buf = io.BytesIO()  
    img.save(buf, fmt)  
    return buf.getvalue()  
  
def resize_for_azure(img: Image.Image) -> Tuple[Image.Image, float]:  
    w, h = img.size  
    if w < MIN_DIM or h < MIN_DIM:  
        s = float(MIN_DIM) / min(w, h)  
    elif w > MAX_DIM or h > MAX_DIM:  
        s = float(MAX_DIM) / max(w, h)  
    else:  
        return img, 1.0  
    return img.resize((int(w * s), int(h * s)), Image.LANCZOS), s  
  
def _iou(a, b) -> float:  
    xa1, ya1, xa2, ya2 = a  
    xb1, yb1, xb2, yb2 = b  
    iw = max(0, min(xa2, xb2) - max(xa1, xb1))  
    ih = max(0, min(ya2, yb2) - max(ya1, yb1))  
    inter = iw * ih  
    if inter == 0:  
        return 0.0  
    return inter / (((xa2 - xa1) * (ya2 - ya1)) + ((xb2 - xb1) * (yb2 - yb1)) - inter)  
  
def _expand_box(  
    box: Tuple[int, int, int, int], pad: int, max_w: int, max_h: int  
) -> Tuple[int, int, int, int]:  
    x1, y1, x2, y2 = box  
    return (  
        max(0, x1 - pad),  
        max(0, y1 - pad),  
        min(max_w, x2 + pad),  
        min(max_h, y2 + pad),  
    )  
  
def _load_logo(key: str) -> np.ndarray:  
    logger.info(f"🔍 Loading logo for key: {key}")  
    filename = REPLACEMENT_LOGOS[key]  
    candidates: list[Path] = []  
    p = Path(filename)  
    if p.is_absolute():  
        candidates.append(p)  
    else:  
        here = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()  
        azure = Path("/home/site/wwwroot")  
        candidates.extend([here / filename, Path.cwd() / filename, azure / filename])  
  
    logger.info(f"🔍 Searching for logo file '{filename}' in locations:")  
    for i, path in enumerate(candidates, 1):  
        logger.info(f"  {i}. {path}")  
  
    for path in candidates:  
        if path.exists():  
            logger.info(f"✅ Found logo file at: {path}")  
            img = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)  
            if img is not None:  
                logger.info(f"✅ Logo loaded successfully: {img.shape}")  
                return img  
            else:  
                logger.warning(f"⚠️ Could not decode image at: {path}")  
  
    error_msg = (  
        f"❌ Replacement logo '{filename}' not found.\n"  
        f"🔍 Searched locations:\n" + "\n".join(f"  - {path}" for path in candidates)  
    )  
    logger.error(error_msg)  
    raise FileNotFoundError(error_msg)  
  
# ################# LOGO DETECTION BACKENDS #################  
def azure_detect(img: Image.Image) -> List[dict]:  
    logger.info(f"🔍 Starting Azure logo detection on image {img.size}")  
    try:  
        from azure.ai.vision.imageanalysis import ImageAnalysisClient  
        from azure.ai.vision.imageanalysis.models import VisualFeatures  
        from azure.core.credentials import AzureKeyCredential  
  
        client = ImageAnalysisClient(  
            endpoint=AZURE_VISION_ENDPOINT,  
            credential=AzureKeyCredential(AZURE_VISION_KEY),  
        )  
  
        detections: List[dict] = []  
  
        logger.info("🎯 Running Azure object detection")  
        objs = client.analyze(image_data=pil2bytes(img), visual_features=[VisualFeatures.OBJECTS])  
        if objs.objects:  
            logger.info(f"📦 Found {len(objs.objects.list)} objects")  
            for i, o in enumerate(objs.objects.list):  
                tag = o.tags[0]  
                logger.info(f"  Object {i}: {tag.name} (conf: {tag.confidence:.3f})")  
                if float(tag.confidence or 0) < LOGO_CONF_THRESHOLD:  
                    logger.info(f"    ⏭️ Skipped - confidence too low")  
                    continue  
                if not any(k in tag.name.lower() for k in KEYWORDS_HITACHI):  
                    logger.info(f"    ⏭️ Skipped - not a Hitachi keyword")  
                    continue  
                bb = o.bounding_box  
                detection = dict(  
                    label=tag.name,  
                    source="object",  
                    conf=float(tag.confidence or 0),  
                    box=(bb.x, bb.y, bb.x + bb.w, bb.y + bb.h),  
                )  
                detections.append(detection)  
                logger.info(f"    ✅ Added object detection: {detection}")  
  
        def _append(read_res, y_shift, scale, want_energy):  
            if not read_res.read or not getattr(read_res.read, "blocks", None):  
                return  
            for blk in read_res.read.blocks:  
                for ln in blk.lines:  
                    txt = (ln.text or "").strip()  
                    if not any(k in txt.lower() for k in KEYWORDS_HITACHI):  
                        continue  
                    if ("energy" in txt.lower()) != want_energy:  
                        continue  
                    xs = [p.x / scale for p in ln.bounding_polygon]  
                    ys = [p.y / scale + y_shift for p in ln.bounding_polygon]  
                    detection = dict(  
                        label=txt,  
                        source="ocr",  
                        conf=1.0,  
                        box=(min(xs), min(ys), max(xs), max(ys)),  
                    )  
                    detections.append(detection)  
                    logger.info(f"    ✅ Added OCR detection: {detection}")  
  
        scaled, sc = resize_for_azure(img)  
        logger.info("📝 Running Azure OCR on full page")  
        ocr_full = client.analyze(image_data=pil2bytes(scaled), visual_features=[VisualFeatures.READ])  
        _append(ocr_full, 0, sc, want_energy=False)  
  
        logger.info("📝 Running Azure OCR on footer region")  
        y0 = int(img.height * (1 - FOOTER_OCR_PCT))  
        foot, sc2 = resize_for_azure(img.crop((0, y0, img.width, img.height)))  
        ocr_foot = client.analyze(image_data=pil2bytes(foot), visual_features=[VisualFeatures.READ])  
        _append(ocr_foot, y0, sc2, want_energy=True)  
  
        _append(ocr_full, 0, sc, want_energy=True)  
  
        logger.info(f"✅ Azure detection completed: {len(detections)} detections")  
        return detections  
    except Exception as exc:  
        logger.error(f"❌ Azure detect error: {exc}")  
        if DEBUG:  
            print("Azure detect error – continuing without Azure:", exc)  
        return []  
  
def template_detect_single(gray_full: np.ndarray, tmpl: np.ndarray, thr: float, sc: float) -> List[Tuple[int, int]]:  
    if gray_full.shape[0] < tmpl.shape[0] or gray_full.shape[1] < tmpl.shape[1]:  
        return []  
    res = cv2.matchTemplate(gray_full, tmpl, cv2.TM_CCOEFF_NORMED)  
    ys, xs = np.where(res >= thr)  
    return [(int(y / sc), int(x / sc)) for y, x in zip(ys, xs)]  
  
def template_detect(img: Image.Image) -> List[dict]:  
    logger.info(f"🔍 Starting template detection on image {img.size}")  
    if not USE_TEMPLATE_DET or not Path(TEMPLATE_DIR).exists():  
        logger.warning(f"⚠️ Template detection disabled or directory '{TEMPLATE_DIR}' not found")  
        return []  
  
    hits: List[dict] = []  
    pil_rots = [(img, 0)]  
    for deg in (90, 270):  
        pil_rots.append((img.rotate(deg, expand=True), deg))  
    for pil_rot, deg in pil_rots:  
        logger.info(f"🔄 Processing rotation: {deg}°")  
        gray_full = cv2.cvtColor(np.asarray(pil_rot.convert("RGB")), cv2.COLOR_RGB2GRAY)  
        template_files = list(Path(TEMPLATE_DIR).glob("*"))  
        logger.info(f"📁 Found {len(template_files)} template files")  
        for tpath in template_files:  
            stem = tpath.stem.lower()  
            logger.info(f"🔍 Processing template: {stem}")  
            if "hitachi_inspire" in stem:  
                lbl = "hitachi inspire the next"  
            elif "hitachi_energy" in stem:  
                lbl = "hitachi energy"  
            else:  
                logger.info(f"  ⏭️ Skipped - not a recognized template")  
                continue  
            tmpl = cv2.imread(str(tpath), cv2.IMREAD_GRAYSCALE)  
            if tmpl is None:  
                logger.warning(f"  ⚠️ Could not load template: {tpath}")  
                continue  
            th, tw = tmpl.shape[:2]  
            thr = TEMPLATE_THRESHOLDS.get(lbl, 0.63)  
            logger.info(f"  📊 Template: {th}x{tw}, threshold: {thr}")  
            for sc in (1.0, 0.9, 0.8, 0.7, 0.6):  
                gray = (gray_full if sc == 1.0 else cv2.resize(gray_full, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA))  
                xy_hits = template_detect_single(gray, tmpl, thr, sc)  
                logger.info(f"    Scale {sc}: {len(xy_hits)} matches")  
                for top, left in xy_hits:  
                    detection = dict(  
                        label=lbl,  
                        source="tmpl",  
                        conf=1.0,  
                        box=(left, top, left + int(tw / sc), top + int(th / sc)),  
                    )  
                    hits.append(detection)  
                    logger.info(f"      ✅ Added template match: {detection}")  
    logger.info(f"✅ Template detection completed: {len(hits)} matches")  
    return hits  
  
def tesseract_detect(img: Image.Image) -> list[dict]:  
    logger.info(f"🔍 Starting Tesseract OCR on image {img.size}")  
    if not ENABLE_TESSERACT:  
        logger.warning("⚠️ Tesseract OCR disabled")  
        return []  
    try:  
        data = pytesseract.image_to_data(img, output_type=Output.DICT, lang="eng")  
        out = []  
        logger.info(f"📝 Tesseract found {len(data['text'])} text elements")  
        for i, word in enumerate(data["text"]):  
            if data["conf"][i] < TESS_MIN_CONF:  
                continue  
            word_lc = word.strip().lower()  
            if not any(k in word_lc for k in KEYWORDS_HITACHI):  
                continue  
            x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]  
            detection = dict(  
                label=word_lc,  
                source="tess",  
                conf=data["conf"][i] / 100,  
                box=(x, y, x + w, y + h),  
            )  
            out.append(detection)  
            logger.info(f"  ✅ Added Tesseract detection: {detection}")  
        logger.info(f"✅ Tesseract completed: {len(out)} detections")  
        return out  
    except Exception as e:  
        logger.error(f"❌ Tesseract error: {e}")  
        if DEBUG:  
            print(f"Tesseract error: {e}")  
        return []  
  
# ################# Logo Analysis #################  
def _ocr_roi(pil_img: Image.Image, box: tuple) -> str:  
    if not ENABLE_TESSERACT:  
        return ""  
    try:  
        x1, y1, x2, y2 = map(int, box)  
        roi = pil_img.crop((x1, y1, x2, y2))  
        txt = pytesseract.image_to_string(roi, lang="eng", config="--psm 6")  
        logger.info(f"🔍 OCR ROI result: '{txt.strip()}'")  
        return txt.lower()  
    except Exception as e:  
        logger.warning(f"⚠️ OCR ROI error: {e}")  
        return ""  
  
def is_old_hitachi_logo(pil_img: Image.Image, box: tuple) -> bool:  
    logger.info(f"🔍 Checking if logo is old Hitachi style: {box}")  
    txt = _ocr_roi(pil_img, box)  
    is_old = "inspire" in txt or "next" in txt  
    logger.info(f"📊 Old Hitachi logo check: text='{txt}', is_old={is_old}")  
    return is_old  
  
def _ink_ratio(img: Image.Image, box) -> float:  
    x1, y1, x2, y2 = map(int, box)  
    arr = np.asarray(img.crop((x1, y1, x2, y2)).convert("L"))  
    return (arr < 240).sum() / arr.size  
  
def _looks_like_logo(img: Image.Image, box) -> bool:  
    x1, y1, x2, y2 = map(int, box)  
    h, w = y2 - y1, x2 - x1  
    ink_r = _ink_ratio(img, box)  
    looks_like = h >= MIN_LOGO_HEIGHT_PX and w / h >= 2.0 and ink_r >= 0.07  
    logger.info(f"📊 Logo check: h={h}, w={w}, ratio={w/h:.2f}, ink={ink_r:.3f}, looks_like={looks_like}")  
    return looks_like  
  
def _red_mask(pil_img: Image.Image, roi_box) -> np.ndarray:  
    x1, y1, x2, y2 = map(int, roi_box)  
    x1 = max(0, min(x1, pil_img.width))  
    x2 = max(0, min(x2, pil_img.width))  
    y1 = max(0, min(y1, pil_img.height))  
    y2 = max(0, min(y2, pil_img.height))  
    if x2 <= x1 or y2 <= y1:  
        return np.zeros((1, 1), dtype=np.uint8)  
    hsv = cv2.cvtColor(np.asarray(pil_img.crop((x1, y1, x2, y2))), cv2.COLOR_RGB2HSV)  
    return (  
        cv2.inRange(hsv, (0, 100, 50), (10, 255, 255)) |  
        cv2.inRange(hsv, (160, 100, 50), (180, 255, 255))  
    )  
  
def _red_ratio(img: Image.Image, box) -> float:  
    mask = _red_mask(img, box)  
    ratio = (mask > 0).sum() / mask.size  
    logger.info(f"🔴 Red ratio in box {box}: {ratio:.4f}")  
    return ratio  
  
def _left_red_ratio(img: Image.Image, box, pct: float = 0.35) -> float:  
    x1, y1, x2, y2 = map(int, box)  
    split = x1 + int((x2 - x1) * pct)  
    left_box = (x1, y1, split, y2)  
    ratio = _red_ratio(img, left_box)  
    logger.info(f"🔴 Left red ratio (left {pct*100:.0f}%): {ratio:.4f}")  
    return ratio  
  
def _has_logo_symbol(  
    img: Image.Image,  
    box,  
    left_pct: float = 0.35,  
    min_px: int = MIN_SYMBOL_AREA_PX,  
    min_ratio: float = MIN_SYMBOL_AREA_RATIO,  
    asp_lo: float = MIN_SYMBOL_ASPECT,  
    asp_hi: float = MAX_SYMBOL_ASPECT,  
) -> bool:  
    logger.info(f"🔍 Checking for logo symbol in box: {box}")  
    x1, y1, x2, y2 = map(int, box)  
    split = x1 + int((x2 - x1) * left_pct)  
    roi_box = (x1, y1, split, y2)  
    mask = _red_mask(img, roi_box)  
    red_pixels = cv2.countNonZero(mask)  
    logger.info(f"🔴 Red pixels in symbol area: {red_pixels}")  
    if red_pixels < min_px:  
        logger.info(f"❌ Not enough red pixels (min: {min_px})")  
        return False  
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=2)  
    num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)  
    if num <= 1:  
        logger.info("❌ No connected components found")  
        return False  
    stats = stats[1:]  
    areas = stats[:, cv2.CC_STAT_AREA]  
    idx = int(np.argmax(areas))  
    area = int(areas[idx])  
    x, y, w, h = stats[idx, :4]  
    logger.info(f"📊 Largest symbol: area={area}, size={w}x{h}")  
    roi_area = mask.size  
    area_ratio = area / roi_area  
    logger.info(f"📊 Area ratio: {area_ratio:.4f} (min: {min_ratio})")  
    if area < min_px or area_ratio < min_ratio:  
        logger.info("❌ Symbol too small or low ratio")  
        return False  
    aspect = w / h if h else 0  
    logger.info(f"📊 Symbol aspect ratio: {aspect:.2f} (range: {asp_lo}-{asp_hi})")  
    has_symbol = asp_lo <= aspect <= asp_hi  
    logger.info(f"✅ Has logo symbol: {has_symbol}")  
    return has_symbol  
  
def _is_energy_logo(img: Image.Image, box) -> bool:  
    logger.info(f"🔍 Checking if box is Hitachi Energy logo: {box}")  
    looks_like = _looks_like_logo(img, box)  
    red_ratio = _red_ratio(img, box)  
    left_red_ratio = _left_red_ratio(img, box)  
    has_symbol = _has_logo_symbol(img, box)  
    is_energy = (looks_like and red_ratio >= MIN_RED_RATIO and left_red_ratio >= MIN_LEFT_RED_RATIO and has_symbol)  
    logger.info(  
        f"📊 Energy logo analysis: looks_like={looks_like}, red_ratio={red_ratio:.4f}>={MIN_RED_RATIO}, left_red_ratio={left_red_ratio:.4f}>={MIN_LEFT_RED_RATIO}, has_symbol={has_symbol} → is_energy={is_energy}"  
    )  
    return is_energy  
  
def _extend_hitachi_energy_box(box, img: Image.Image, max_ratio: float = 1.6) -> Tuple[int, int, int, int]:  
    logger.info(f"🔍 Extending Hitachi Energy box: {box}")  
    fallback_pad_ratio = 0.001  
    x1, y1, x2, y2 = map(int, box)  
    h = y2 - y1  
    search = int(h * max_ratio)  
    logger.info(f"📏 Search distance: {search} pixels")  
    left_roi = (max(0, x1 - search), y1, x1, y2)  
    right_roi = (x2, y1, min(img.width, x2 + search), y2)  
  
    def _symbol_bounds(roi):  
        if roi[2] <= roi[0] or roi[3] <= roi[1]:  
            return None  
        mask = _red_mask(img, roi)  
        red_pixels = cv2.countNonZero(mask)  
        logger.info(f"  ROI {roi}: {red_pixels} red pixels")  
        if red_pixels < 150:  
            return None  
        n, _, stats, _ = cv2.connectedComponentsWithStats(mask, 8)  
        if n <= 1:  
            return None  
        stats = stats[1:]  
        rx, ry, rw, rh, _ = stats[np.argmax(stats[:, cv2.CC_STAT_AREA])]  
        bounds = roi[0] + rx, roi[0] + rx + rw  
        logger.info(f"  Found symbol bounds: {bounds}")  
        return bounds  
  
    PAD = 2  
    lbounds = _symbol_bounds(left_roi)  
    rbounds = _symbol_bounds(right_roi)  
  
    original_box = (x1, y1, x2, y2)  
    if lbounds:  
        x1 = min(x1, lbounds[0] - PAD)  
        logger.info(f"📏 Extended left to include symbol")  
    elif rbounds:  
        x2 = max(x2, rbounds[1] + PAD)  
        logger.info(f"📏 Extended right to include symbol")  
    else:  
        pad = int(h * fallback_pad_ratio)  
        x1 = max(0, x1 - pad)  
        x2 = min(img.width, x2 + pad)  
        logger.info(f"📏 Applied fallback padding: {pad} pixels")  
    extended_box = (x1, y1, x2, y2)  
    logger.info(f"📏 Box extension: {original_box} → {extended_box}")  
    return extended_box  
  
def detect_logo_only_page(img: Image.Image) -> List[dict]:  
    logger.info(f"🔍 Detecting logo-only page on image {img.size}")  
    gray = cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2GRAY)  
    _, bw = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)  
    ink_ratio = np.count_nonzero(bw) / bw.size  
    logger.info(f"📊 Ink ratio: {ink_ratio:.4f} (range: {MIN_SOLO_INK_RATIO}-{MAX_SOLO_INK_RATIO})")  
    if not (MIN_SOLO_INK_RATIO < ink_ratio < MAX_SOLO_INK_RATIO):  
        logger.info("❌ Ink ratio outside acceptable range")  
        return []  
    bw = cv2.morphologyEx(bw, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))  
    cnts, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  
    if not cnts:  
        logger.info("❌ No contours found")  
        return []  
    x, y, w, h = cv2.boundingRect(max(cnts, key=cv2.contourArea))  
    box = (x, y, x + w, y + h)  
    logger.info(f"📊 Main contour: {w}x{h}, ratio: {w/h:.2f}")  
    if h < MIN_LOGO_HEIGHT_PX or w / h < 2.0:  
        logger.info("❌ Contour too small or wrong aspect ratio")  
        return []  
    if not _is_energy_logo(img, box):  
        logger.info("❌ Does not look like energy logo")  
        return []  
    detection = {"label": "hitachi energy", "box": box}  
    logger.info(f"✅ Detected logo-only page: {detection}")  
    return [detection]  
  
def final_logo_boxes(img: Image.Image) -> List[dict]:  
    logger.info(f"🚀 Starting comprehensive logo detection on image {img.size}")  
    scaled, sc = resize_for_azure(img)  
    logger.info(f"📏 Image scaling: {sc:.3f}")  
    cand: List[dict] = []  
    if DETECTION_BACKEND == "azure":  
        logger.info("🔍 Running Azure detection")  
        cand.extend(azure_detect(scaled))  
    logger.info("🔍 Running template detection")  
    cand.extend(template_detect(scaled))  
  
    logger.info(f"📊 Initial candidates: {len(cand)}")  
    if sc != 1.0:  
        logger.info(f"📏 Rescaling {len(cand)} candidates by factor {1/sc:.3f}")  
        for c in cand:  
            x1, y1, x2, y2 = c["box"]  
            c["box"] = (int(x1 / sc), int(y1 / sc), int(x2 / sc), int(y2 / sc))  
  
    footer_y = int(img.height * (1 - FOOTER_OCR_PCT))  
    logger.info(f"📊 Footer boundary at y={footer_y}")  
  
    before_filter = len(cand)  
    cand = [  
        c  
        for c in cand  
        if not (  
            "energy" in c["label"].lower()  
            and (c["box"][1] + c["box"][3]) / 2 < footer_y  
            and not (_looks_like_logo(img, c["box"]) or _is_energy_logo(img, c["box"]))  
        )  
    ]  
    after_filter = len(cand)  
    logger.info(f"🧹 Filtered body energy words: {before_filter} → {after_filter}")  
  
    used: Set[int] = set()  
    final: List[dict] = []  
  
    def h_overlap(a, b):  
        return max(0, min(a[2], b[2]) - max(a[0], b[0]))  
  
    idx_hitachi = [i for i, c in enumerate(cand) if c["label"].lower() == "hitachi"]  
    idx_tagline = [i for i, c in enumerate(cand) if any(w in c["label"].lower() for w in ("inspire", "next"))]  
    idx_energy_word = [i for i, c in enumerate(cand) if c["label"].strip().lower() == "energy"]  
  
    logger.info(f"📊 Candidate groups: Hitachi={len(idx_hitachi)}, Tagline={len(idx_tagline)}, Energy={len(idx_energy_word)}")  
  
    logger.info("🔍 Processing Hitachi + Inspire combinations")  
    for hi in idx_hitachi:  
        if hi in used:  
            continue  
        hx1, hy1, hx2, hy2 = cand[hi]["box"]  
        hh = hy2 - hy1  
        union, grp = list(cand[hi]["box"]), [hi]  
        logger.info(f"  Hitachi candidate {hi}: box={cand[hi]['box']}")  
        for ti in idx_tagline:  
            if ti in used:  
                continue  
            tx1, ty1, tx2, ty2 = cand[ti]["box"]  
            logger.info(f"    Checking tagline {ti}: box={cand[ti]['box']}")  
            if not (hy1 <= ty1 <= hy2 + 3 * hh):  
                logger.info(f"      ❌ Vertical alignment check failed")  
                continue  
            if (h_overlap(cand[hi]["box"], cand[ti]["box"]) >= 0.3 * (tx2 - tx1) or hx1 <= (tx1 + tx2) / 2 <= hx2):  
                logger.info(f"      ✅ Horizontal alignment check passed")  
                union[0] = min(union[0], tx1)  
                union[1] = min(union[1], ty1)  
                union[2] = max(union[2], tx2)  
                union[3] = max(union[3], ty2)  
                grp.append(ti)  
  
        if len(grp) == 1:  
            union[3] = min(img.height, union[3] + int(1.5 * hh))  
            logger.info(f"    Extended single Hitachi box vertically")  
  
        if _looks_like_logo(img, union):  
            logo = {"label": "hitachi inspire the next", "box": tuple(map(int, union))}  
            final.append(logo)  
            used.update(grp)  
            logger.info(f"    ✅ Added Hitachi Inspire logo: {logo}")  
        else:  
            logger.info(f"    ❌ Union does not look like a logo")  
  
    logger.info("🔍 Processing Hitachi + Energy (footer) combinations")  
    for hi in idx_hitachi:  
        if hi in used or cand[hi]["box"][1] < footer_y:  
            continue  
        hx1, hy1, hx2, hy2 = cand[hi]["box"]  
        hh, union, grp, merged = hy2 - hy1, list(cand[hi]["box"]), [hi], False  
        logger.info(f"  Footer Hitachi candidate {hi}: box={cand[hi]['box']}")  
        for ei in idx_energy_word:  
            if ei in used:  
                continue  
            ex1, ey1, ex2, ey2 = cand[ei]["box"]  
            if ey1 < footer_y or not (hy1 <= ey1 <= hy2 + 2.5 * hh):  
                continue  
            if (h_overlap(cand[hi]["box"], cand[ei]["box"]) >= 0.25 * (ex2 - ex1) or hx1 <= (ex1 + ex2) / 2 <= hx2):  
                union[0] = min(union[0], ex1)  
                union[1] = min(union[1], ey1)  
                union[2] = max(union[2], ex2)  
                union[3] = max(union[3], ey2)  
                grp.append(ei)  
                merged = True  
                logger.info(f"    ✅ Merged with energy word {ei}")  
        if merged and _is_energy_logo(img, union):  
            logo = {"label": "hitachi energy", "box": tuple(map(int, union))}  
            final.append(logo)  
            used.update(grp)  
            logger.info(f"    ✅ Added footer Hitachi Energy logo: {logo}")  
  
    logger.info("🔍 Processing Hitachi + Energy (body) combinations")  
    for hi in idx_hitachi:  
        if hi in used:  
            continue  
        hx1, hy1, hx2, hy2 = cand[hi]["box"]  
        if not (HEADER_FOOTER_PCT * img.height < hy1 < (1 - FOOTER_OCR_PCT) * img.height):  
            continue  
        hh, union, grp, merged = hy2 - hy1, list(cand[hi]["box"]), [hi], False  
        logger.info(f"  Body Hitachi candidate {hi}: box={cand[hi]['box']}")  
        for ei in idx_energy_word:  
            if ei in used:  
                continue  
            ex1, ey1, ex2, ey2 = cand[ei]["box"]  
            if not (HEADER_FOOTER_PCT * img.height < ey1 < (1 - FOOTER_OCR_PCT) * img.height):  
                continue  
            if not (hy1 <= ey1 <= hy2 + 3 * hh):  
                continue  
            if (h_overlap(cand[hi]["box"], cand[ei]["box"]) >= 0.25 * (ex2 - ex1) or hx1 <= (ex1 + ex2) / 2 <= hx2):  
                union[0] = min(union[0], ex1)  
                union[1] = min(union[1], ey1)  
                union[2] = max(union[2], ex2)  
                union[3] = max(union[3], ey2)  
                grp.append(ei)  
                merged = True  
                logger.info(f"    ✅ Merged with energy word {ei}")  
        if merged and _is_energy_logo(img, union):  
            logo = {"label": "hitachi energy", "box": tuple(map(int, union))}  
            final.append(logo)  
            used.update(grp)  
            logger.info(f"    ✅ Added body Hitachi Energy logo: {logo}")  
  
    logger.info("🔍 Processing single-box Hitachi Energy")  
    for i, c in enumerate(cand):  
        if i in used:  
            continue  
        if "hitachi" in c["label"].lower() and "energy" in c["label"].lower() and _is_energy_logo(img, c["box"]):  
            logo = {"label": "hitachi energy", "box": tuple(map(int, c["box"]))}  
            final.append(logo)  
            used.add(i)  
            logger.info(f"    ✅ Added single-box Hitachi Energy: {logo}")  
  
    logger.info("🔍 Processing template leftovers")  
    for i, c in enumerate(cand):  
        if i in used or c["source"] != "tmpl" or "energy" in c["label"].lower():  
            continue  
        if _looks_like_logo(img, c["box"]):  
            logo = {"label": c["label"], "box": tuple(map(int, c["box"]))}  
            final.append(logo)  
            used.add(i)  
            logger.info(f"    ✅ Added template leftover: {logo}")  
  
    logger.info("🔍 Processing stand-alone Hitachi")  
    for i, c in enumerate(cand):  
        if i in used or c["label"].lower() != "hitachi":  
            continue  
        x1, y1, x2, y2 = c["box"]  
        h, w = y2 - y1, x2 - x1  
        if h < MIN_LOGO_HEIGHT_PX or w / h < MIN_HITACHI_WIDTH_RATIO:  
            continue  
        if HEADER_FOOTER_PCT * img.height <= y2 <= (1 - HEADER_FOOTER_PCT) * img.height:  
            continue  
        union = (x1, y1, x2, min(img.height, y2 + int(1.5 * h)))  
        if _looks_like_logo(img, union):  
            logo = {"label": "hitachi inspire the next", "box": union}  
            final.append(logo)  
            logger.info(f"    ✅ Added standalone Hitachi: {logo}")  
  
    logger.info("🧹 Deduplicating final results")  
    dedup: List[dict] = []  
    for m in final:  
        if not any(_iou(m["box"], d["box"]) > IOU_DUP_THRESHOLD for d in dedup):  
            dedup.append(m)  
        else:  
            logger.info(f"    🗑️ Removed duplicate: {m}")  
  
    if SKIP_NEW_HITACHI:  
        logger.info("🔍 Filtering new Hitachi logos")  
        before_skip = len(dedup)  
        dedup = [  
            d for d in dedup  
            if not (  
                d["label"].startswith("hitachi")  
                and "energy" not in d["label"].lower()  
                and not is_old_hitachi_logo(img, d["box"])  
            )  
        ]  
        after_skip = len(dedup)  
        logger.info(f"    Filtered new logos: {before_skip} → {after_skip}")  
  
    logger.info(f"🎉 Final logo detection completed: {len(dedup)} logos found")  
    for i, logo in enumerate(dedup):  
        logger.info(f"  {i+1}. {logo}")  
    return dedup  
  
# ################# Inpainting & Logo Replacement #################  
def smart_inpaint(page_bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:  
    logger.info("🎨 Starting smart inpainting")  
    if _LAMA_MODEL is not None:  
        try:  
            logger.info("→ Using LaMa inpainting model")  
            if DEBUG:  
                print("→ LaMa in-paint …")  
            return _apply_lama_inpaint(page_bgr, mask)  
        except Exception as exc:  
            logger.warning(f"⚠ LaMa inpainting failed: {exc}")  
            if DEBUG:  
                print("⚠ LaMa failed:", exc)  
    logger.info("→ Using OpenCV Telea inpainting")  
    if DEBUG:  
        print("→ OpenCV Telea in-paint …")  
    return cv2.inpaint(page_bgr, mask, 7, cv2.INPAINT_TELEA)  
  
def _get_mask_center(mask: np.ndarray) -> Tuple[int, int]:  
    ys, xs = np.nonzero(mask)  
    if xs.size == 0 or ys.size == 0:  
        h, w = mask.shape[:2]  
        return w // 2, h // 2  
    return int(xs.mean()), int(ys.mean())  
  
def _apply_lama_inpaint(cv_bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:  
    logger.info("🎨 Applying LaMa inpainting")  
    rgb = cv2.cvtColor(cv_bgr, cv2.COLOR_BGR2RGB)  
    res = _LAMA_MODEL(rgb, mask, _LAMA_CFG_OBJ)  # type: ignore  
    if res.dtype != np.uint8:  
        res = np.clip(res, 0, 255).astype(np.uint8)  
    res_bgr = cv2.cvtColor(res, cv2.COLOR_RGB2BGR)  
    try:  
        centre = _get_mask_center(mask)  
        blended = cv2.seamlessClone(res_bgr, cv_bgr, mask, centre, cv2.NORMAL_CLONE)  
        logger.info("✅ LaMa inpainting with seamless clone completed")  
        return blended  
    except cv2.error:  
        logger.info("⚠️ Seamless clone failed, using raw LaMa result")  
        return res_bgr  
  
def _prep_logo(key: str, tw: int, th: int) -> np.ndarray:  
    logger.info(f"🔄 Preparing logo '{key}' for size {tw}x{th}")  
    logo = _load_logo(key)  
    if (th > tw) != (logo.shape[0] > logo.shape[1]):  
        logger.info("🔄 Rotating logo for orientation match")  
        logo = cv2.rotate(logo, cv2.ROTATE_90_COUNTERCLOCKWISE)  
    scale = max(1e-6, min(tw / logo.shape[1], th / logo.shape[0]) * SCALE_COVERAGE)  
    new_w = max(1, int(round(logo.shape[1] * scale)))  
    new_h = max(1, int(round(logo.shape[0] * scale)))  
    logger.info(f"📏 Logo scaling: {scale:.3f}, new size: {new_w}x{new_h}")  
    result = cv2.resize(logo, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)  
    logger.info("✅ Logo preparation completed")  
    return result  
  
def _dominant_text_colour_simplified(  
    pil_img: Image.Image,  
    box: tuple[int, int, int, int],  
) -> tuple[int, int, int]:  
    logger.info(f"🎨 Determining text color for logo in box: {box}")  
    if FORCE_BLACK_INSPIRE_LOGOS:  
        logger.info("  → Forcing black color for Hitachi Inspire logo")  
        if DEBUG:  
            print("  -> Forcing black color for Hitachi Inspire logo")  
        return (0, 0, 0)  
    x1, y1, x2, y2 = map(int, box)  
    x1 = max(0, x1); y1 = max(0, y1)  
    x2 = min(pil_img.width, x2)  
    y2 = min(pil_img.height, y2)  
    gray = cv2.cvtColor(np.asarray(pil_img.crop((x1, y1, x2, y2))).astype(np.uint8), cv2.COLOR_RGB2GRAY)  
    _, thr = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)  
    mask_dark = thr == 0  
    mask_brite = thr == 255  
    ink_mask = mask_dark if mask_dark.sum() < mask_brite.sum() else mask_brite  
    if not ink_mask.any():  
        logger.info("  → Using black as default")  
        return (0, 0, 0)  
    median_luma = float(np.median(gray[ink_mask]))  
    color = (255, 255, 255) if median_luma > 128 else (0, 0, 0)  
    logger.info(f"  → Chosen color: {color} (median luma: {median_luma:.1f})")  
    return color  
  
def _recolour_logo(rgba: np.ndarray, rgb: tuple[int, int, int]) -> np.ndarray:  
    logger.info(f"🎨 Recoloring logo to RGB: {rgb}")  
    col = np.array(rgb, dtype=np.uint8)  
    out = rgba.copy()  
    m = out[..., 3] > 20  
    out[m, :3] = col  
    return out  
  
def _shrink_vertically(pil_img: Image.Image, box: tuple, margin: int = 3) -> tuple:  
    logger.info(f"📏 Shrinking box vertically: {box}")  
    x1, y1, x2, y2 = map(int, box)  
    roi = cv2.cvtColor(np.asarray(pil_img.crop((x1, y1, x2, y2))), cv2.COLOR_RGB2GRAY)  
    _, bw = cv2.threshold(roi, 230, 255, cv2.THRESH_BINARY_INV)  
    ys = np.where(bw.sum(axis=1) > 0)[0]  
    if ys.size == 0:  
        logger.info("  → No content found, keeping original box")  
        return box  
    new_y1 = y1 + max(0, ys.min() - margin)  
    new_y2 = y1 + min(roi.shape[0], ys.max() + margin)  
    new_box = (x1, new_y1, x2, new_y2)  
    logger.info(f"  → Shrunk to: {new_box}")  
    return new_box  
  
def _kernel(side: int, pct: float, mx: int, odd=True) -> int:  
    k = max(3, min(mx, int(side * pct)))  
    return k + 1 if odd and k % 2 == 0 else k  
  
def _create_wipe_mask(cv: np.ndarray, box):  
    x1, y1, x2, y2 = map(int, box)  
    pad = _kernel(min(x2 - x1, y2 - y1), PAD_PCT, MAX_PAD_PX, odd=False)  
    wipe = _expand_box((x1, y1, x2, y2), pad, cv.shape[1], cv.shape[0])  
    mask = np.zeros(cv.shape[:2], np.uint8)  
    cv2.rectangle(mask, (wipe[0], wipe[1]), (wipe[2], wipe[3]), 255, -1)  
    dil = _kernel(min(x2 - x1, y2 - y1), DILATE_PCT, MAX_DILATE_PX)  
    mask = cv2.dilate(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (dil, dil)), 1)  
    rad = _kernel(min(x2 - x1, y2 - y1), INPAINT_PCT, MAX_INPAINT_RADIUS, odd=False)  
    return mask, wipe, rad  
  
def _alpha_overlay(dst: np.ndarray, src_rgba: np.ndarray, top: int, left: int):  
    top, left = int(top), int(left)  
    h, w = src_rgba.shape[:2]  
    if (top < 0 or left < 0 or top + h > dst.shape[0] or left + w > dst.shape[1]):  
        return dst  
    roi = dst[top: top + h, left: left + w].astype(np.float32)  
    src_rgb = src_rgba[..., :3].astype(np.float32)  
    alpha = src_rgba[..., 3].astype(np.float32) / 255.0  
    alpha = cv2.GaussianBlur(alpha, (5, 5), 0)  
    if alpha.ndim == 2:  
        alpha = alpha[..., None]  
    dst[top: top + h, left: left + w] = (alpha * src_rgb + (1 - alpha) * roi).astype(np.uint8)  
    return dst  
  
def wipe_and_paste_generic(pil_img: Image.Image, box, key: str, tint: tuple[int,int,int] | None = None) -> Image.Image:  
    cv = cv2.cvtColor(np.asarray(pil_img), cv2.COLOR_RGB2BGR)  
    mask, wipe, rad = _create_wipe_mask(cv, box)  
    cv = smart_inpaint(cv, mask)  
    x1, y1, x2, y2 = wipe  
    logo = _prep_logo(key, x2 - x1, y2 - y1)  
    if tint is not None:  
        logo = _recolour_logo(logo, tint)  
    lbgr, alpha = logo[..., :3], logo[..., 3]  
    if alpha.max() == 0:  
        g = cv2.cvtColor(lbgr, cv2.COLOR_BGR2GRAY)  
        alpha = cv2.threshold(g, 10, 255, cv2.THRESH_BINARY)[1]  
    cx, cy = x1 + (x2 - x1) // 2, y1 + (y2 - y1) // 2  
    ph, pw = cv.shape[:2]  
    cx = int(np.clip(cx, lbgr.shape[1] // 2, pw - (lbgr.shape[1] - lbgr.shape[1] // 2)))  
    cy = int(np.clip(cy, lbgr.shape[0] // 2, ph - (lbgr.shape[0] - lbgr.shape[0] // 2)))  
    blended = False  
    before = cv[y1:y2, x1:x2].copy()  
    for mode in SEAMLESS_CLONE_TRIES:  
        try:  
            trial = cv2.seamlessClone(lbgr, cv, alpha, (cx, cy), mode)  
            if np.mean(cv2.absdiff(trial[y1:y2, x1:x2], before)) > 5:  
                cv, blended = trial, True  
                break  
        except cv2.error:  
            pass  
    if not blended:  
        cv = _alpha_overlay(cv, logo, cy - lbgr.shape[0] // 2, cx - lbgr.shape[1] // 2)  
    return Image.fromarray(cv2.cvtColor(cv, cv2.COLOR_BGR2RGB))  
  
def wipe_and_paste(img: Image.Image, box):  
    fg = _dominant_text_colour_simplified(img, box)  
    return wipe_and_paste_generic(img, box, "hitachi_inspire", fg)  
  
def wipe_and_paste_energy(img: Image.Image, box):  
    return wipe_and_paste_generic(img, box, "hitachi_energy", None)  
  
# ################# DOCX & PDF Processing #################  
def _bytes2pil(data: bytes):  
    try:  
        im = Image.open(io.BytesIO(data))  
        im.load()  
        return im.convert("RGB")  
    except Exception:  
        return None  
def _transparent_png_bytes(w: int, h: int) -> bytes:  
    w = max(1, int(w))  
    h = max(1, int(h))  
    rgba = np.zeros((h, w, 4), dtype=np.uint8)  ######## fully transparent  
    ok, buf = cv2.imencode(".png", rgba, [int(cv2.IMWRITE_PNG_COMPRESSION), 3])  
    if not ok:  
        raise RuntimeError("Failed to encode transparent PNG")  
    return buf.tobytes()    
def _pil2bytes(img: Image.Image, ext: str) -> bytes:  
    fmt = {"png":"PNG","jpg":"JPEG","jpeg":"JPEG","bmp":"BMP","tif":"TIFF","tiff":"TIFF"}.get(ext.lstrip(".").lower(),"PNG")  
    buf = io.BytesIO()  
    params = {"quality":92} if fmt=="JPEG" else {}  
    img.save(buf, fmt, **params)  
    return buf.getvalue()  
  
def _scale_for_detection(pil: Image.Image, target_short_side: int = 800) -> tuple[list[Image.Image], list[float]]:  
    w, h = pil.size  
    short = min(w, h)  
    if short >= target_short_side:  
        return [pil], [1.0]  
    scales, imgs = [1.0], [pil]  
    factor = target_short_side / short  
    steps = max(1, int(math.log(factor, 2)))  
    for i in range(steps):  
        sc = 2 ** (i + 1)  
        new_w = int(w * sc)  
        new_h = int(h * sc)  
        big = pil.resize((new_w, new_h), Image.LANCZOS)  
        imgs.append(big)  
        scales.append(1.0 / sc)  
    return imgs, scales  
  
def _blank_bitmap(width: int, height: int, ext: str, style: str = DELETE_STYLE) -> bytes:  
    if style == "transparent":  
        mode = "RGBA"  
        colour = (0, 0, 0, 0)  
    else:  ###### "white"  
        mode = "RGB"  
        colour = (255, 255, 255)  
    img = Image.new(mode, (width, height), colour)  
    return _pil2bytes(img, ext)  
###########DOCX-only logo detector with OCR fallback###############  
def docx_final_logo_boxes(img: Image.Image) -> List[dict]:  
    ########## start with the same strong stack ##########  
    scaled, sc = resize_for_azure(img)  
    cand: List[dict] = []  
    if DETECTION_BACKEND == "azure":  
        cand.extend(azure_detect(scaled))  
    cand.extend(template_detect(scaled))  
  
    ########## If nothing yet, try Tesseract (DOCX-only fallback) ##########  
    if not cand:  
        cand.extend(tesseract_detect(scaled))  
  
    ########## logo-only page heuristic remains ##########  
    if not any("hitachi energy" in (c["label"].lower()) for c in cand):  
        cand.extend(detect_logo_only_page(scaled))  
  
    ######### rescale boxes back if we scaled  ##########
    if sc != 1.0:  
        for c in cand:  
            x1, y1, x2, y2 = c["box"]  
            c["box"] = (int(x1 / sc), int(y1 / sc), int(x2 / sc), int(y2 / sc))  
  
    footer_y = int(img.height * (1 - FOOTER_OCR_PCT))  
    ########## body-energy filter (same as final_logo_boxes) ##########  
    cand = [  
        c for c in cand  
        if not (  
            "energy" in c["label"].lower()  
            and (c["box"][1] + c["box"][3]) / 2 < footer_y  
            and not (_looks_like_logo(img, c["box"]) or _is_energy_logo(img, c["box"]))  
        )  
    ]  
  
    used: Set[int] = set()  
    final: List[dict] = []  
  
    def h_overlap(a, b):  
        return max(0, min(a[2], b[2]) - max(a[0], b[0]))  
  
    idx_hitachi = [i for i, c in enumerate(cand) if c["label"].lower() == "hitachi"]  
    idx_tagline = [i for i, c in enumerate(cand) if any(w in c["label"].lower() for w in ("inspire", "next"))]  
    idx_energy_word = [i for i, c in enumerate(cand) if c["label"].strip().lower() == "energy"]  
  
    ########### Hitachi + Inspire/Next grouping  ##########
    for hi in idx_hitachi:  
        if hi in used:  
            continue  
        hx1, hy1, hx2, hy2 = cand[hi]["box"]  
        hh = hy2 - hy1  
        union, grp = list(cand[hi]["box"]), [hi]  
        for ti in idx_tagline:  
            if ti in used:  
                continue  
            tx1, ty1, tx2, ty2 = cand[ti]["box"]  
            if not (hy1 <= ty1 <= hy2 + 3 * hh):  
                continue  
            if (h_overlap(cand[hi]["box"], cand[ti]["box"]) >= 0.3 * (tx2 - tx1) or hx1 <= (tx1 + tx2) / 2 <= hx2):  
                union[0] = min(union[0], tx1); union[1] = min(union[1], ty1)  
                union[2] = max(union[2], tx2); union[3] = max(union[3], ty2)  
                grp.append(ti)  
        if len(grp) == 1:  
            union[3] = min(img.height, union[3] + int(1.5 * hh))  
        if _looks_like_logo(img, union):  
            final.append({"label": "hitachi inspire the next", "box": tuple(map(int, union))})  
            used.update(grp)  
  
    ########### Footer: Hitachi + Energy grouping  ##########
    for hi in idx_hitachi:  
        if hi in used or cand[hi]["box"][1] < footer_y:  
            continue  
        hx1, hy1, hx2, hy2 = cand[hi]["box"]  
        hh, union, grp, merged = hy2 - hy1, list(cand[hi]["box"]), [hi], False  
        for ei in idx_energy_word:  
            if ei in used:  
                continue  
            ex1, ey1, ex2, ey2 = cand[ei]["box"]  
            if ey1 < footer_y or not (hy1 <= ey1 <= hy2 + 2.5 * hh):  
                continue  
            if (h_overlap(cand[hi]["box"], cand[ei]["box"]) >= 0.25 * (ex2 - ex1) or hx1 <= (ex1 + ex2) / 2 <= hx2):  
                union[0] = min(union[0], ex1); union[1] = min(union[1], ey1)  
                union[2] = max(union[2], ex2); union[3] = max(union[3], ey2)  
                grp.append(ei); merged = True  
        if merged and _is_energy_logo(img, union):  
            final.append({"label": "hitachi energy", "box": tuple(map(int, union))})  
            used.update(grp)  
  
    ########### Body: Hitachi + Energy grouping  ###########
    for hi in idx_hitachi:  
        if hi in used:  
            continue  
        hx1, hy1, hx2, hy2 = cand[hi]["box"]  
        if not (HEADER_FOOTER_PCT * img.height < hy1 < (1 - FOOTER_OCR_PCT) * img.height):  
            continue  
        hh, union, grp, merged = hy2 - hy1, list(cand[hi]["box"]), [hi], False  
        for ei in idx_energy_word:  
            if ei in used:  
                continue  
            ex1, ey1, ex2, ey2 = cand[ei]["box"]  
            if not (HEADER_FOOTER_PCT * img.height < ey1 < (1 - FOOTER_OCR_PCT) * img.height):  
                continue  
            if not (hy1 <= ey1 <= hy2 + 3 * hh):  
                continue  
            if (h_overlap(cand[hi]["box"], cand[ei]["box"]) >= 0.25 * (ex2 - ex1) or hx1 <= (ex1 + ex2) / 2 <= hx2):  
                union[0] = min(union[0], ex1); union[1] = min(union[1], ey1)  
                union[2] = max(union[2], ex2); union[3] = max(union[3], ey2)  
                grp.append(ei); merged = True  
        if merged and _is_energy_logo(img, union):  
            final.append({"label": "hitachi energy", "box": tuple(map(int, union))})  
            used.update(grp)  
  
    ########### Single-box energy  ###########
    for i, c in enumerate(cand):  
        if i in used:  
            continue  
        if "hitachi" in c["label"].lower() and "energy" in c["label"].lower() and _is_energy_logo(img, c["box"]):  
            final.append({"label": "hitachi energy", "box": tuple(map(int, c["box"]))})  
            used.add(i)  
  
    ########### Template leftovers  ###########
    for i, c in enumerate(cand):  
        if i in used or c.get("source") != "tmpl" or "energy" in c["label"].lower():  
            continue  
        if _looks_like_logo(img, c["box"]):  
            final.append({"label": c["label"], "box": tuple(map(int, c["box"]))})  
            used.add(i)  
  
    ########### Stand-alone Hitachi in header/footer bands  ###########
    for i, c in enumerate(cand):  
        if i in used or c["label"].lower() != "hitachi":  
            continue  
        x1, y1, x2, y2 = c["box"]  
        h, w = y2 - y1, x2 - x1  
        if h < MIN_LOGO_HEIGHT_PX or w / h < MIN_HITACHI_WIDTH_RATIO:  
            continue  
        if HEADER_FOOTER_PCT * img.height <= y2 <= (1 - HEADER_FOOTER_PCT) * img.height:  
            continue  
        union = (x1, y1, x2, min(img.height, y2 + int(1.5 * h)))  
        if _looks_like_logo(img, union):  
            final.append({"label": "hitachi inspire the next", "box": union})  
  
    ######### deduplication ##########  
    dedup: List[dict] = []  
    for m in final:  
        if not any(_iou(m["box"], d["box"]) > IOU_DUP_THRESHOLD for d in dedup):  
            dedup.append(m)  
  
    ########## Filter new HITACHI wordmark if SKIP_NEW_HITACHI is enabled ##########  
    if SKIP_NEW_HITACHI:  
        dedup = [  
            d for d in dedup  
            if not (  
                d["label"].startswith("hitachi")  
                and "energy" not in d["label"].lower()  
                and not is_old_hitachi_logo(img, d["box"])  
            )  
        ]  
    return dedup  
def _process_bitmap(data: bytes, ext: str, dbg_name: str | None = None) -> bytes:  
    pil_orig = _bytes2pil(data)  
    if pil_orig is None:  
        return data  
  
    imgs, inv_scales = _scale_for_detection(pil_orig)  
    detections: list[dict] = []  
    for img, inv_sc in zip(imgs, inv_scales):  
        ########## DOCX-only detection with OCR fallback ##########  
        detections = docx_final_logo_boxes(img)  
        if not any("energy" in d["label"].lower() for d in detections):  
            detections.extend(detect_logo_only_page(img))  
        if detections:  
            for d in detections:  
                x1, y1, x2, y2 = d["box"]  
                d["box"] = (int(x1 * inv_sc), int(y1 * inv_sc), int(x2 * inv_sc), int(y2 * inv_sc))  
            break  
    if not detections:  
        return data  
  
    for d in detections:  
        if "energy" in d["label"].lower():  
            d["box"] = _extend_hitachi_energy_box(d["box"], pil_orig)  
  
    pil = pil_orig  
    for d in detections:  
        d["box"] = _shrink_vertically(pil, d["box"])  
        if "energy" in d["label"].lower():  
            if DOCX_FORCE_DELETE_ENERGY:  
                blank = _blank_bitmap(pil_orig.width, pil_orig.height, ext)  
                if DEBUG:  
                    print(f"   ↻  {dbg_name} – bitmap removed")  
                return blank  
            else:  
                pil = wipe_and_paste_energy(pil, d["box"])  
        else:  
            pil = wipe_and_paste(pil, d["box"])  
    return _pil2bytes(pil, ext)
        
def _process_bitmap_old(data: bytes, ext: str, dbg_name: str | None = None) -> bytes:  
    pil_orig = _bytes2pil(data)  
    if pil_orig is None:  
        return data  
  
    imgs, inv_scales = _scale_for_detection(pil_orig)  
    detections: list[dict] = []  
    for img, inv_sc in zip(imgs, inv_scales):  
        detections = final_logo_boxes(img)  
        if not any("energy" in d["label"].lower() for d in detections):  
            detections.extend(detect_logo_only_page(img))  
        if detections:  
            for d in detections:  
                x1, y1, x2, y2 = d["box"]  
                d["box"] = (int(x1 * inv_sc), int(y1 * inv_sc), int(x2 * inv_sc), int(y2 * inv_sc))  
            break  
  
    if not detections:  
        return data  
  
    for d in detections:  
        if "energy" in d["label"].lower():  
            d["box"] = _extend_hitachi_energy_box(d["box"], pil_orig)  
  
    pil = pil_orig  
    for d in detections:  
        d["box"] = _shrink_vertically(pil, d["box"])  
        if "energy" in d["label"].lower():  
            if DOCX_FORCE_DELETE_ENERGY:  
                blank = _blank_bitmap(pil_orig.width, pil_orig.height, ext)  
                if DEBUG:  
                    print(f"   ↻  {dbg_name} – bitmap removed")  
                return blank  
            else:  
                pil = wipe_and_paste_energy(pil, d["box"])  
        else:  
            pil = wipe_and_paste(pil, d["box"])  
    return _pil2bytes(pil, ext)  
  
def process_docx_step2(docx_bytes: bytes) -> bytes:  
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as zin:  
        names = zin.namelist()  
        original_bytes = {n: zin.read(n) for n in names}  
    output_buffer = io.BytesIO()  
    with zipfile.ZipFile(output_buffer, "w", compression=zipfile.ZIP_DEFLATED) as zout:  
        for item_name in names:  
            data = original_bytes[item_name]  
            if item_name.startswith("word/media/"):  
                ext = Path(item_name).suffix.lower()  
                try:  
                    if ext in DOCX_BITMAP_EXTS:  
                        data = _process_bitmap(data, ext, item_name)  
                except Exception as exc:  
                    if DEBUG:  
                        print("   ⚠ media processing error:", exc)  
            zout.writestr(item_name, data)  
    if DEBUG:  
        print("✓ Step 2 completed - logo embedding handled in Step 1")  
    return output_buffer.getvalue()  
  
# ################# PDF FONT Rebranding #################  
TOL = 1  ##### rounding error in degrees  
_TJ = re.compile(rb"$(?:[^]]+?)$\s*TJ|$.*?$\s*Tj", re.S)  
  
def cw(dir_tuple):  
    cos_v, sin_v = dir_tuple  
    raw = (-math.degrees(math.atan2(sin_v, cos_v))) % 360  
    snap = (round(raw / 90) * 90) % 360  
    if abs(raw - snap) > TOL:  
        return None  
    if snap in (90, 270):  
        snap = (snap + 180) % 360  
    return int(snap)  
  
def strip_ops(p: fitz.Page):  
    doc = p.parent  
    for xref in p.get_contents():  
        doc.update_stream(xref, _TJ.sub(b"", doc.xref_stream(xref)), compress=1)  
def _rect_intersects_any(r: "fitz.Rect", rects: List["fitz.Rect"]) -> bool:  
        return any(r.intersects(rr) for rr in rects)  

  
def _re_font_in_rects(  
    page: "fitz.Page",  
    tag: str,  
    rects: list,  
    *,  
    force_rgb=None,  
    enabled: bool = None,  
    inset: float = 0.5,  
    **kwargs,  
) -> None:  
      
    import math  
    import fitz  
  
    ##### Resolve the gate  ##########
    gate_global = bool(globals().get("REFONT_COVER_TO_BLACK_ENABLED", False))  
    gate = gate_global if enabled is None else bool(enabled)  
  
    ####### If gate off, or no target color, or no rects -> do nothing ########  
    if not gate or force_rgb is None or not rects:  
        return  
  
    ####### Normalize and validate rects  #######
    norm_rects = []  
    for r in rects:  
        try:  
            rr = fitz.Rect(r)  
            if rr and not rr.is_empty:  
                norm_rects.append(rr)  
        except Exception:  
            continue  
    if not norm_rects:  
        return  
  
    ####### Normalize color to 0..1 floats ####### 
    def _norm_rgb01(c_any):  
        if c_any is None:  
            return (0.0, 0.0, 0.0)  
        if isinstance(c_any, (tuple, list)) and len(c_any) >= 3:  
            r, g, b = float(c_any[0]), float(c_any[1]), float(c_any[2])  
            if max(r, g, b) > 1.0:  
                return (r / 255.0, g / 255.0, b / 255.0)  
            return (r, g, b)  
        if isinstance(c_any, int):  
            r = (c_any >> 16) & 255  
            g = (c_any >> 8) & 255  
            b = c_any & 255  
            return (r / 255.0, g / 255.0, b / 255.0)  
        return (0.0, 0.0, 0.0)  
  
    force_rgb01 = _norm_rgb01(force_rgb)  
  
    ###### Direction vector to clockwise degrees  #######
    def _cw(dir_tuple):  
        dx, dy = (dir_tuple or (1.0, 0.0))  
        ang = math.degrees(math.atan2(dy, dx))  
        if ang < 0:  
            ang += 360.0  
        return ang  
  
    ####### Collect target spans ###### 
    targets = []  
    tdict = page.get_text("dict")  
    for blk in tdict.get("blocks", []):  
        if blk.get("type"):  
            continue  ###### skip image or drawing blocks ##### 
        for ln in blk.get("lines", []):  
            ln_dir = ln.get("dir", (1.0, 0.0))  
            for sp in ln.get("spans", []):  
                txt = (sp.get("text") or "")  
                if not txt.strip():  
                    continue  
                try:  
                    sp_rect = fitz.Rect(sp.get("bbox"))  
                except Exception:  
                    continue  
                ####### Intersects any target rect?  #########
                hit = False  
                for rr in norm_rects:  
                    if sp_rect.intersects(rr):  
                        hit = True  
                        break  
                if not hit:  
                    continue  
  
                ######### Keep required data for reinsertion  #######
                try:  
                    ox, oy = sp["origin"]  
                    targets.append({  
                        "bbox": sp_rect,  
                        "origin": (ox, oy),  
                        "dir": ln_dir,  
                        "size": float(sp.get("size", 10.0)),  
                        "text": txt,  
                    })  
                except Exception:  
                    continue  
  
    if not targets:  
        return  
  
    ########### Redact only the text spans we will reinsert ############
    for t in targets:  
        r = fitz.Rect(t["bbox"])  
        if inset:  
            ######### Slight inset to avoid edge artifacts from redaction ########### 
            r = fitz.Rect(r.x0 + inset, r.y0 + inset, r.x1 - inset, r.y1 - inset)  
        try:  
            page.add_redact_annot(r, fill=None)  
        except Exception:  
            pass  
  
    try:  
        page.apply_redactions(images=getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0))  
    except Exception:  
        try:  
            page.apply_redactions()  
        except Exception:  
            pass  
  
    ######### Ensure the desired font tag exists ######### 
    fontfile = None  
    try:  
        fontfile = str(globals().get("FONT_FILE")) if globals().get("FONT_FILE") else None  
    except Exception:  
        fontfile = None  
    try:  
        if fontfile:  
            page.insert_font(fontname=tag, fontfile=fontfile)  
        else:  
            page.insert_font(fontname=tag)  
    except Exception:  
        pass  
  
    try:  
        page.clean_contents()  
    except Exception:  
        pass  
  
    ######## Reinsert spans with the forced colour  ########
    for t in targets:  
        x, y = t["origin"]  
        try:  
            if fontfile:  
                page.insert_text(  
                    (x, y),  
                    t["text"],  
                    fontname=tag,  
                    fontsize=t["size"],  
                    fontfile=fontfile,  
                    color=force_rgb01,  
                    rotate=_cw(t["dir"]),  
                    overlay=True,  
                )  
            else:  
                page.insert_text(  
                    (x, y),  
                    t["text"],  
                    fontname=tag,  
                    fontsize=t["size"],  
                    color=force_rgb01,  
                    rotate=_cw(t["dir"]),  
                    overlay=True,  
                )  
        except Exception:  
            ########### Last-resort fallback without a specified font ############  
            page.insert_text(  
                (x, y),  
                t["text"],  
                fontsize=t["size"],  
                color=force_rgb01,  
                rotate=_cw(t["dir"]),  
                overlay=True,  
            )  
 
  
def re_font(page: fitz.Page, tag: str):  
    spans: List[dict] = []  
    for b in page.get_text("dict")["blocks"]:  
        if b["type"]:  
            continue  
        for ln in b["lines"]:  
            for sp in ln["spans"]:  
                sp["dir"] = ln.get("dir", (1.0, 0.0))  
                spans.append(sp)  
    if REMOVE_STRATEGY == "stream":  
        strip_ops(page)  
    else:  
        for sp in spans:  
            if not sp["text"].strip():  
                continue  
            r = fitz.Rect(sp["bbox"])  
            r.x0, r.y0, r.x1, r.y1 = r.x0 + 0.5, r.y0 + 0.5, r.x1 - 0.5, r.y1 - 0.5  
            page.add_redact_annot(r, fill=None)  
        page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)  
  
    if tag not in page.get_fonts():  
        try:  
            page.insert_font(fontname=tag, fontfile=str(FONT_FILE))  
        except Exception:  
            pass  
  
    page.clean_contents()  
    rgb = lambda c: ((c >> 16 & 255) / 255, (c >> 8 & 255) / 255, (c & 255) / 255)  
    for sp in spans:  
        if not sp["text"].strip():  
            continue  
        x, y = sp["origin"]  
        try:  
            page.insert_text(  
                (x, y),  
                sp["text"],  
                fontname=tag,  
                # fontsize=max(sp["size"] + SIZE_DELTA, 1), 
                fontsize=sp["size"]-1.2, 
                fontfile=str(FONT_FILE),  
                color=rgb(sp["color"]),  
                rotate=cw(sp["dir"]),  
                overlay=True,  
            )  
        except Exception:  
            page.insert_text(  
                (x, y),  
                sp["text"],  
                # fontsize=max(sp["size"] + SIZE_DELTA, 1), 
                fontsize=sp["size"]-1.2, 
                color=rgb(sp["color"]),  
                rotate=cw(sp["dir"]),  
                overlay=True,  
            )  
# process_pdf_step2 (force black text on cover after global re-font)  
def process_pdf_step2(pdf_stream: io.BytesIO) -> io.BytesIO:  
    doc = fitz.open(stream=pdf_stream, filetype="pdf")  
    for pno, page in enumerate(doc):  
        if ENABLE_PDF_FONT_REBRAND:  
            ###### Global re-font ############  
            re_font(page, "HZ")  
            ########### Make cover text black ############  
            if FORCE_BLACK_TEXT_ON_COVER:  
                try:  
                    cover_bbox = cover_image_bbox_pdf(page)  
                except Exception:  
                    cover_bbox = None  
                if cover_bbox:  
                    try:  
                        _re_font_in_rects(page, "HZ", [cover_bbox], force_rgb=(0.0, 0.0, 0.0))  
                    except Exception:  
                        pass  
  
        pix = page.get_pixmap(dpi=300, alpha=False)  
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)  
  
        detections = final_logo_boxes(img)  
        if not any("hitachi energy" in d["label"].lower() for d in detections):  
            detections.extend(detect_logo_only_page(img))  
  
        for d in detections:  
            if d["label"].lower() == "hitachi energy":  
                d["box"] = _extend_hitachi_energy_box(d["box"], img)  
  
        for d in detections:  
            d["box"] = _shrink_vertically(img, d["box"])  
            if "energy" in d["label"].lower():  
                img = wipe_and_paste_energy(img, d["box"])  
            else:  
                img = wipe_and_paste(img, d["box"])  
  
        buf = io.BytesIO()  
        img.save(buf, "PNG")  
        page.clean_contents()  
        page.insert_image(page.rect, stream=buf.getvalue())  
  
    output_stream = io.BytesIO()  
    doc.save(output_stream, garbage=4, deflate=True, clean=True)  
    doc.close()  
    output_stream.seek(0)  
    return output_stream    
def process_pdf_step2_old(pdf_stream: io.BytesIO) -> io.BytesIO:  
    doc = fitz.open(stream=pdf_stream, filetype="pdf")  
    for pno, page in enumerate(doc):  
        if ENABLE_PDF_FONT_REBRAND:  
            re_font(page, "HZ")  
  
        pix = page.get_pixmap(dpi=300, alpha=False)  
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)  
  
        detections = final_logo_boxes(img)  
        if not any("hitachi energy" in d["label"].lower() for d in detections):  
            detections.extend(detect_logo_only_page(img))  
  
        for d in detections:  
            if d["label"].lower() == "hitachi energy":  
                d["box"] = _extend_hitachi_energy_box(d["box"], img)  
  
        for d in detections:  
            d["box"] = _shrink_vertically(img, d["box"])  
            if "energy" in d["label"].lower():  
                img = wipe_and_paste_energy(img, d["box"])  
            else:  
                img = wipe_and_paste(img, d["box"])  
  
        buf = io.BytesIO()  
        img.save(buf, "PNG")  
        page.clean_contents()  
        page.insert_image(page.rect, stream=buf.getvalue())  
  
    output_stream = io.BytesIO()  
    doc.save(output_stream, garbage=4, deflate=True, clean=True)  
    doc.close()  
    output_stream.seek(0)  
    return output_stream  
  
################## DOCX TYPOGRAPHY Rebranding #################  
def is_valid_docx(path: Path | str) -> bool:  
    if not zipfile.is_zipfile(path):  
        return False  
    try:  
        with zipfile.ZipFile(path) as z:  
            return "[Content_Types].xml" in z.namelist()  
    except zipfile.BadZipFile:  
        return False  
  
def _check_license(ttf: pathlib.Path) -> None:  
    try:  
        if TTFont and TTFont(str(ttf))["OS/2"].fsType & 0b10:  
            print(f"Warning: Font license may restrict embedding: {ttf}")  
    except Exception:  
        pass  
  
def _obfuscate(ttf: pathlib.Path) -> tuple[bytes, str]:  
    guid, rev = uuid.uuid4(), bytes.fromhex(uuid.uuid4().hex)[::-1]  
    buf = bytearray(ttf.read_bytes())  
    for i in range(16):  
        buf[i] ^= rev[i]  
        buf[i + 16] ^= rev[i]  
    return bytes(buf), str(guid).upper()  
  
def _iter_parts(pkg: pathlib.Path):  
    patterns = (  
        "document.xml", "styles.xml", "numbering.xml",  
        "comments*.xml", "footnotes.xml", "endnotes.xml",  
        "header*.xml", "footer*.xml", "settings.xml",  
    )  
    for pat in patterns:  
        yield from (pkg / "word").glob(pat)  
  
def _half_points(pt: float) -> int:  
    return int(round(pt * 2))  
  
def _points_from_half_points(half_pts: int) -> float:  
    return half_pts / 2.0  
  
def _should_reduce_size(rpr) -> bool:  
    sz_el = rpr.find("w:sz", namespaces=NS)  
    if sz_el is None:  
        return False  
    try:  
        half_pts = int(sz_el.get(qn("w:val")))  
        current_pt = _points_from_half_points(half_pts)  
        return current_pt >= MIN_SIZE_THRESHOLD_PT  
    except (TypeError, ValueError):  
        return False  
  
def _get_reduction_amount(current_pt: float) -> float:  
    if current_pt < MIN_SIZE_THRESHOLD_PT:  
        return 0.0  
    elif current_pt > REDUCE_THRESHOLD_PT:  
        return REDUCE_BY_PT_LARGE  
    else:  
        return REDUCE_BY_PT_SMALL  
  
def _apply_smart_size_reduction(rpr) -> None:  
    sz_el = rpr.find("w:sz", namespaces=NS)  
    szcs_el = rpr.find("w:szCs", namespaces=NS)  
    for node in (sz_el, szcs_el):  
        if node is None:  
            continue  
        try:  
            old_half_pts = int(node.get(qn("w:val")))  
            current_pt = _points_from_half_points(old_half_pts)  
            reduction_pt = _get_reduction_amount(current_pt)  
            if reduction_pt > 0:  
                new_pt = max(MIN_SIZE_THRESHOLD_PT, current_pt - reduction_pt)  
                new_half_pts = _half_points(new_pt)  
                node.set(qn("w:val"), str(new_half_pts))  
        except (TypeError, ValueError):  
            continue  
  
def _is_bullet_font(rpr) -> bool:  
    if rpr is None:  
        return False  
    rf = rpr.find("w:rFonts", namespaces=NS)  
    if rf is None:  
        return False  
    for attr in ("ascii", "hAnsi", "cs", "eastAsia"):  
        if rf.get(qn(f"w:{attr}")) in PRESERVE_BULLET_FONTS:  
            return True  
    return False  
  
def _touch_rfonts(rpr, *, preserve_special: bool = False) -> None:  
    if rpr is None or (preserve_special and _is_bullet_font(rpr)):  
        return  
    rf = rpr.find("w:rFonts", namespaces=NS)  
    if rf is None:  
        rf = etree.SubElement(rpr, qn("w:rFonts"))  
    for theme_attr in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):  
        rf.attrib.pop(qn(f"w:{theme_attr}"), None)  
    for attr in ("ascii", "hAnsi", "cs", "eastAsia"):  
        if preserve_special and rf.get(qn(f"w:{attr}")) in PRESERVE_BULLET_FONTS:  
            continue  
        rf.set(qn(f"w:{attr}"), TARGET_NAME)  
  
def _patch_part(xml: pathlib.Path) -> None:  
    tree = etree.parse(str(xml), etree.XMLParser(remove_blank_text=True))  
    for run in tree.xpath(".//w:r", namespaces=NS):  
        rpr = run.find("w:rPr", namespaces=NS)  
        text_content = "".join(run.xpath("./w:t/text()", namespaces=NS))  
        bullet_like = any(ch in UNICODE_BULLETS for ch in text_content)  
        preserve_flag = bullet_like or (rpr is not None and _is_bullet_font(rpr))  
        _touch_rfonts(rpr, preserve_special=preserve_flag)  
        if rpr is not None and not preserve_flag and _should_reduce_size(rpr):  
            _apply_smart_size_reduction(rpr)  
    tree.write(str(xml), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _patch_styles(xml: pathlib.Path) -> None:  
    tree = etree.parse(str(xml), etree.XMLParser(remove_blank_text=True))  
    root = tree.getroot()  
    dd = root.find(".//w:docDefaults/w:rPrDefault/w:rPr", namespaces=NS)  
    if dd is not None:  
        _touch_rfonts(dd)  
        if _should_reduce_size(dd):  
            _apply_smart_size_reduction(dd)  
    for rpr in root.xpath(".//w:style//w:rPr", namespaces=NS):  
        _touch_rfonts(rpr)  
        if _should_reduce_size(rpr):  
            _apply_smart_size_reduction(rpr)  
    tree.write(str(xml), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _patch_numbering(xml: pathlib.Path) -> None:  
    tree = etree.parse(str(xml), etree.XMLParser(remove_blank_text=True))  
    for lvl in tree.xpath(".//w:lvl", namespaces=NS):  
        numfmt = lvl.find("w:numFmt", namespaces=NS)  
        pic = lvl.find("w:lvlPicBulletId", namespaces=NS)  
        is_bullet = numfmt is not None and numfmt.get(qn("w:val")) == "bullet"  
        if pic is not None:  
            continue  
        for rpr in lvl.xpath(".//w:rPr", namespaces=NS):  
            if is_bullet or _is_bullet_font(rpr):  
                continue  
            _touch_rfonts(rpr, preserve_special=True)  
            if _should_reduce_size(rpr):  
                _apply_smart_size_reduction(rpr)  
    tree.write(str(xml), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _ensure_mime(pkg: pathlib.Path) -> None:  
    ct = pkg / "[Content_Types].xml"  
    tree = etree.parse(str(ct))  
    root = tree.getroot()  
    tag = f"{{{CT}}}Default"  
    if not any(n.get("Extension") == "odttf" for n in root.findall(tag)):  
        etree.SubElement(root, tag, Extension="odttf", ContentType="application/vnd.ms-package.obfuscated-opentype")  
        tree.write(str(ct), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _write_font(pkg: pathlib.Path, blob: bytes, guid: str) -> str:  
    p = pkg / "word" / "fonts"  
    p.mkdir(parents=True, exist_ok=True)  
    (p / f"{guid}.odttf").write_bytes(blob)  
    return f"fonts/{guid}.odttf"  
  
def _add_font_rel(pkg: pathlib.Path, tgt: str) -> str:  
    rels = pkg / "word" / "_rels" / "fontTable.xml.rels"  
    rels.parent.mkdir(exist_ok=True)  
    if rels.exists():  
        tree = etree.parse(str(rels)); root = tree.getroot()  
    else:  
        root = etree.Element("Relationships", xmlns="http://schemas.openxmlformats.org/package/2006/relationships")  
    rid = f"rId{uuid.uuid4().int >> 112}"  
    etree.SubElement(  
        root, "Relationship",  
        Id=rid,  
        Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/font",  
        Target=tgt,  
    )  
    etree.ElementTree(root).write(str(rels), encoding="utf-8", xml_declaration=True, standalone="yes")  
    return rid  
  
def _update_font_table(pkg: pathlib.Path, rid: str, guid: str) -> None:  
    ftab = pkg / "word" / "fontTable.xml"  
    if ftab.exists():  
        tree = etree.parse(str(ftab)); root = tree.getroot()  
    else:  
        root = etree.Element(qn("w:fonts"), nsmap=NS)  
    for old in root.xpath(f".//w:font[@w:name='{TARGET_NAME}']", namespaces=NS):  
        root.remove(old)  
    font = etree.SubElement(root, qn("w:font"), **{qn("w:name"): TARGET_NAME})  
    etree.SubElement(  
        font, qn("w:embedRegular"),  
        **{f"{{{R}}}id": rid, qn("w:fontKey"): f"{{{guid}}}"}  
    )  
    for tag, val in (("charset","00"),("family","auto"),("pitch","variable")):  
        etree.SubElement(font, qn(f"w:{tag}"), **{qn("w:val"): val})  
    etree.ElementTree(root).write(str(ftab), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def _flag_embed(pkg: pathlib.Path) -> None:  
    s = pkg / "word" / "settings.xml"  
    if not s.exists():  
        return  
    tree = etree.parse(str(s)); root = tree.getroot()  
    if root.find("w:embedTrueTypeFonts", namespaces=NS) is None:  
        etree.SubElement(root, qn("w:embedTrueTypeFonts"))  
        tree.write(str(s), encoding="utf-8", xml_declaration=True, standalone="yes")  
  
def process_docx_typography(docx_bytes: bytes) -> bytes:  
    if not ENABLE_DOCX_FONT_REBRAND or etree is None:  
        return docx_bytes  
    try:  
        with tempfile.TemporaryDirectory() as td:  
            pkg = pathlib.Path(td)  
            with zipfile.ZipFile(io.BytesIO(docx_bytes)) as z:  
                z.extractall(pkg)  
  
            for xml in _iter_parts(pkg):  
                {"styles.xml": _patch_styles, "numbering.xml": _patch_numbering}.get(xml.name, _patch_part)(xml)  
  
            if pathlib.Path(VERDANA_TTF).exists():  
                _check_license(pathlib.Path(VERDANA_TTF))  
                blob, guid = _obfuscate(pathlib.Path(VERDANA_TTF))  
                rid = _add_font_rel(pkg, _write_font(pkg, blob, guid))  
                _update_font_table(pkg, rid, guid)  
                _flag_embed(pkg)  
                _ensure_mime(pkg)  
  
            output_buffer = io.BytesIO()  
            with zipfile.ZipFile(output_buffer, "w", compression=zipfile.ZIP_DEFLATED) as zout:  
                for file_path in pkg.rglob("*"):  
                    if file_path.is_file():  
                        arcname = str(file_path.relative_to(pkg))  
                        zout.write(file_path, arcname)  
            output_buffer.seek(0)  
            return output_buffer.getvalue()  
    except Exception as e:  
        if DEBUG:  
            print(f"Typography processing error: {e}")  
        return docx_bytes  
  
################## Azure Blob Helpers #################  
def _download_inputs_from_blob(local_dir: Path) -> List[Path]:  
    downloaded: List[Path] = []  
    if BlobServiceClient is None:  
        logger.error("Azure Blob SDK not available. Please install azure-storage-blob.")  
        return downloaded  
    try:  
        service = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)  
        container = service.get_container_client(AZURE_CONTAINER_INPUT)  
        blobs = container.list_blobs()  
        for blob in blobs:  
            name = blob.name  
            if not name.lower().endswith((".pdf", ".docx")):  
                continue  
            target = local_dir / Path(name).name  
            ensure_dir(local_dir)  
            logger.info(f"⬇️ Downloading blob: {name} → {target}")  
            with open(target, "wb") as f:  
                stream = container.download_blob(name)  
                f.write(stream.readall())  
            downloaded.append(target)  
    except Exception as e:  
        logger.error(f"Failed to download from Azure Blob: {e}")  
    return downloaded  
  
def _upload_to_blob(file_path: Path) -> None:  
    if BlobServiceClient is None:  
        logger.error("Azure Blob SDK not available. Please install azure-storage-blob.")  
        return  
    try:  
        service = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)  
        container = service.get_container_client(AZURE_CONTAINER_OUTPUT)  
        try:  
            container.create_container()  
        except Exception:  
            pass  
        logger.info(f"⬆️ Uploading {file_path.name} to container {AZURE_CONTAINER_OUTPUT}")  
        content_settings = None  
        if ContentSettings is not None:  
            if file_path.suffix.lower() == ".pdf":  
                content_settings = ContentSettings(content_type="application/pdf")  
            elif file_path.suffix.lower() == ".docx":  
                content_settings = ContentSettings(  
                    content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"  
                )  
        with open(file_path, "rb") as f:  
            container.upload_blob(  
                name=file_path.name,  
                data=f,  
                overwrite=True,  
                content_settings=content_settings,  
            )  
    except Exception as e:  
        logger.error(f"Failed to upload to Azure Blob: {e}")  
  
################# Consolidated Processing Wrappers #################  
def _re_font_spans_pagewide_white_to_black(  
    page: "fitz.Page",  
    tag: str,  
    white_thr: int = COND_WHITE_THR,  
) -> None:  
    text_dict = page.get_text("dict")  
    spans_to_black: List[dict] = []  
  
    ########## Collect white-colored spans across the whole page  ############
    for b in text_dict["blocks"]:  
        if b["type"]:  
            continue  
        for ln in b["lines"]:  
            for sp in ln["spans"]:  
                if not (sp.get("text") or "").strip():  
                    continue  
                if _is_span_white(sp, thr_255=white_thr):  
                    sp["dir"] = ln.get("dir", (1.0, 0.0))  
                    spans_to_black.append(sp)  
  
    if not spans_to_black:  
        return  
  
    ########### Redact only those spans we will reinsert as black  #######
    for sp in spans_to_black:  
        r = fitz.Rect(sp["bbox"])  
        ####### slight inset to avoid edge artifacts ########  
        r.x0, r.y0, r.x1, r.y1 = r.x0 + 0.5, r.y0 + 0.5, r.x1 - 0.5, r.y1 - 0.5  
        try:  
            page.add_redact_annot(r, fill=None)  
        except Exception:  
            pass  
    try:  
        page.apply_redactions(images=getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0))  
    except Exception:  
        try:  
            page.apply_redactions()  
        except Exception:  
            pass  
  
    ######## Ensure the font tag (falls back if unavailable)###########  
    try:  
        page.insert_font(fontname=tag, fontfile=str(FONT_FILE))  
    except Exception:  
        pass  
  
    try:  
        page.clean_contents()  
    except Exception:  
        pass  
  
    ####### Reinsert spans with black color###########  
    for sp in spans_to_black:  
        if not sp["text"].strip():  
            continue  
        x, y = sp["origin"]  
        try:  
            page.insert_text(  
                (x, y),  
                sp["text"],  
                fontname=tag,  
                fontsize=sp["size"],  
                fontfile=str(FONT_FILE),  
                color=(0.0, 0.0, 0.0),  
                rotate=cw(sp["dir"]),  
                overlay=True,  
            )  
        except Exception:  
            page.insert_text(  
                (x, y),  
                sp["text"],  
                fontsize=sp["size"],  
                color=(0.0, 0.0, 0.0),  
                rotate=cw(sp["dir"]),  
                overlay=True,  
            )  
  
def shadow_white_text_to_black_fullpage(page: "fitz.Page", tag: str = "HZ", white_thr: int = WHITE_TEXT_THR_SHADOW) -> None:  
    text_dict = page.get_text("dict")  
    spans_to_black: List[dict] = []  
  
    ######## Collect white-coloured spans across the whole page  ###########
    for b in text_dict["blocks"]:  
        if b["type"]:  
            continue  
        for ln in b["lines"]:  
            for sp in ln["spans"]:  
                if not (sp.get("text") or "").strip():  
                    continue  
                if _shadow_is_span_white(sp, thr_255=white_thr):  
                    sp["dir"] = ln.get("dir", (1.0, 0.0))  
                    spans_to_black.append(sp)  
  
    if not spans_to_black:  
        return  
  
    ########### Redact only those spans we will reinsert as black  ###########
    for sp in spans_to_black:  
        r = fitz.Rect(sp["bbox"])  
        ####### slight inset to avoid edge artifacts ####### 
        r.x0, r.y0, r.x1, r.y1 = r.x0 + 0.5, r.y0 + 0.5, r.x1 - 0.5, r.y1 - 0.5  
        try:  
            page.add_redact_annot(r, fill=None)  
        except Exception:  
            pass  
    try:  
        page.apply_redactions(images=getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0))  
    except Exception:  
        try:  
            page.apply_redactions()  
        except Exception:  
            pass  
  
    ########### Ensure the font tag (falls back if unavailable)#############  
    try:  
        page.insert_font(fontname=tag, fontfile=str(FONT_FILE))  
    except Exception:  
        pass  
  
    try:  
        page.clean_contents()  
    except Exception:  
        pass  
  
    ######## Reinsert spans with black color  #########3
    for sp in spans_to_black:  
        if not sp["text"].strip():  
            continue  
        x, y = sp["origin"]  
        try:  
            page.insert_text(  
                (x, y),  
                sp["text"],  
                fontname=tag,  
                fontsize=sp["size"],  
                fontfile=str(FONT_FILE),  
                color=(0.0, 0.0, 0.0),  
                rotate=_shadow_cw(sp["dir"]),  
                overlay=True,  
            )  
        except Exception:  
            page.insert_text(  
                (x, y),  
                sp["text"],  
                fontsize=sp["size"],  
                color=(0.0, 0.0, 0.0),  
                rotate=_shadow_cw(sp["dir"]),  
                overlay=True,  
            )   

def process_pdf_consolidated(  
    pdf_path: Path,  
    output_path: Path,  
    *,  
    template_cover: bool = False,          
    template_img: Optional[np.ndarray] = None,  
    debug: bool = DEBUG,  
) -> None:  
    import io  
    import fitz  
  
    with open(pdf_path, "rb") as f:  
        in_stream = io.BytesIO(f.read())  
  
    if template_cover:  
        ########## TRUE PATH — UNTOUCHED (no recolor, no gates) ############# 
        interim = process_pdf_pipeline_inspire(  
            in_stream,  
            template_cover=True,  
            template_img=template_img,  
            debug=debug,  
        )  
        final_stream = process_pdf_step2(interim)  
  
    else:  
        ############ FALSE PATH — use transparent template + page-wide white -> black on cover pages only  ###########
        ######### Prepare transparent template  ###########3
        shadow_tpl = template_img  
        if shadow_tpl is None:  
            try:  
                if Path("transparent1.png").exists():  
                    shadow_tpl = cv2.imread("transparent1.png", cv2.IMREAD_COLOR)  
            except Exception:  
                shadow_tpl = None  
  
        ######## Enable gates only for the False path  #############
        old_refont_gate = globals().get("REFONT_COVER_TO_BLACK_ENABLED", False)  
        old_logo_gate = globals().get("FORCE_BLACK_INSPIRE_LOGOS", False)  
        globals()["REFONT_COVER_TO_BLACK_ENABLED"] = True  
        globals()["FORCE_BLACK_INSPIRE_LOGOS"] = True  
  
        try:  
            ########## Step 1: run like template mode but with transparent cover#############  
            interim = process_pdf_pipeline_inspire(  
                in_stream,  
                template_cover=True,  
                template_img=shadow_tpl,  
                debug=debug,  
            )  
  
            ######### Page-wide white→black on pages where the cover image is present ############# 
            try:  
                doc_mid = fitz.open(stream=interim, filetype="pdf")  
                for page in doc_mid:  
                    try:  
                        bbox = cover_image_bbox_pdf(page)  
                    except Exception:  
                        bbox = None  
                    if bbox and not bbox.is_empty:  
                        try:  
                            thr = globals().get("COND_WHITE_THR", 245)  
                            _re_font_spans_pagewide_white_to_black(page, tag="HZ", white_thr=thr)  
                        except Exception:  
                            if debug:  
                                try:  
                                    logger.exception("white→black page-wide recolor failed on a page.")  
                                except Exception:  
                                    print("white→black page-wide recolor failed on a page.")  
                mid_stream = io.BytesIO()  
                doc_mid.save(mid_stream, garbage=4, deflate=True, clean=True)  
                doc_mid.close()  
                mid_stream.seek(0)  
            except Exception:  
                ########### If anything fails, continue with interim ############## 
                mid_stream = interim  
  
            ############ Step 2: Logo detection & replacement########## 
            final_stream = process_pdf_step2(mid_stream)  
  
        finally:  
            ###### Restore gates ###### 
            globals()["REFONT_COVER_TO_BLACK_ENABLED"] = old_refont_gate  
            globals()["FORCE_BLACK_INSPIRE_LOGOS"] = old_logo_gate  
  
    with open(output_path, "wb") as out:  
        out.write(final_stream.getvalue())  
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file1 = Path(OUTPUT_DIR) / f"{Path(pdf_path).stem}_{timestamp}_rebranded.pdf"
    with open(output_file1, "wb") as out1:  
        out1.write(final_stream.getvalue())
    try:  
        logger.info(f"✅ PDF written: {output_path}")  
    except Exception:  
        print(f"✅ PDF written: {output_path}")   

############ DOCX pre-clean ################# 
import posixpath  
  
DOCX_DELETE_ALL_VECTOR_IN_HF: bool = True  
DOCX_INSERT_NEW_HEADER_LOGO: bool = True  
DOCX_HEADER_LOGO_ALIGN_RIGHT: bool = True  
DOCX_HEADER_LOGO_SIZE_PX: tuple[int, int] = (180, 60)  
DOCX_EMU_PER_PX: int = 9525  
DOCX_HF_VECTOR_MIN_W_H_RATIO: float = 2.2  
DOCX_HF_VECTOR_MAX_HEIGHT_EMU: int = int(914400 * 0.9)  # 0.9 in  
  
WP  = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"  
A   = "http://schemas.openxmlformats.org/drawingml/2006/main"  
PIC = "http://schemas.openxmlformats.org/drawingml/2006/picture"  
V   = "urn:schemas-microsoft-com:vml"  
NS_HF = {"w": W, "r": R, "wp": WP, "a": A, "pic": PIC, "v": V}  
############ DOCX vector/text logo actions (remove Energy, replace old HITACHI) ############  
W   = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"  
R   = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"  
WP  = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"  
A   = "http://schemas.openxmlformats.org/drawingml/2006/main"  
PIC = "http://schemas.openxmlformats.org/drawingml/2006/picture"  
V   = "urn:schemas-microsoft-com:vml"  
WPS = "http://schemas.microsoft.com/office/word/2010/wordprocessingShape"  
  
NS = {"w": W, "r": R, "wp": WP, "a": A, "pic": PIC, "v": V, "wps": WPS}  
  
DOCX_VECTOR_EXTS = {".emf", ".wmf", ".svg", ".eps"}  ####### extend as you wish  
DOCX_LOGO_MAX_HEIGHT_EMU = int(914400 * 0.95)        ######### ~0.95 inch tall  
DOCX_LOGO_MIN_W_H = 1.8                              ############# width/height ratio  
  
def _text_in_shape(el: etree._Element) -> str:  
    ######## w:pict -> w:txbxContent -> w:t  #########
    ts = []  
    for t in el.findall(".//w:txbxContent//w:t", namespaces=NS):  
        ts.append(t.text or "")  
    ######## DrawingML shapes: a:txBody -> a:t  #########3
    for t in el.findall(".//a:txBody//a:t", namespaces=NS):  
        ts.append(t.text or "")  
    return " ".join(ts).strip().lower()  
  
def _docpr_info(drawing_el: etree._Element) -> tuple[str, str]:  
    name = descr = ""  
    docpr = drawing_el.find(".//wp:docPr", namespaces=NS)  
    if docpr is not None:  
        name = docpr.get("name", "") or ""  
        descr = docpr.get("descr", "") or ""  
    return (name.lower(), descr.lower())  
  
def _inline_size_emu(drawing_el: etree._Element) -> tuple[int, int]:  
    inline = drawing_el.find(".//wp:inline", namespaces=NS)  
    if inline is None:  
        return (0, 0)  
    ext = inline.find("wp:extent", namespaces=NS)  
    if ext is None:  
        return (0, 0)  
    try:  
        return (int(ext.get("cx", "0")), int(ext.get("cy", "0")))  
    except Exception:  
        return (0, 0)  
  
def _vml_shape_size_emu(vshape: etree._Element) -> tuple[int, int]:  
    ####### v:shape style="width:123pt;height:45pt;..." -> convert pt to EMU (12700 EMU per pt)  #########
    style = vshape.get("style", "") or ""  
    w_pt = h_pt = 0.0  
    for part in style.split(";"):  
        p = part.strip().lower()  
        if p.startswith("width:") and "pt" in p:  
            try: w_pt = float(p.split("width:")[1].split("pt")[0])  
            except: pass  
        elif p.startswith("height:") and "pt" in p:  
            try: h_pt = float(p.split("height:")[1].split("pt")[0])  
            except: pass  
    w_emu = int(w_pt * 12700)  
    h_emu = int(h_pt * 12700)  
    return (w_emu, h_emu)  
  
def _is_logo_like_size(cx: int, cy: int) -> bool:  
    return cx and cy and (cx / max(1, cy) >= DOCX_LOGO_MIN_W_H) and (cy <= DOCX_LOGO_MAX_HEIGHT_EMU)  
  
def _rels_parse_list(rels_bytes: bytes) -> list[tuple[str, str, str]]:  
    out = []  
    try:  
        root = etree.fromstring(rels_bytes)  
        for rel in root.findall(".//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship"):  
            out.append((rel.get("Id"), rel.get("Target", ""), rel.get("TargetMode", "")))  
    except Exception:  
        pass  
    return out  
  
def _rels_map(rels_bytes: bytes) -> dict[str, tuple[str, str]]:  
    return {rid: (tgt, mode) for rid, tgt, mode in _rels_parse_list(rels_bytes) if rid}  
  
def _rels_update_target(rels_bytes: bytes, rid: str, new_target: str) -> bytes:  
    try:  
        root = etree.fromstring(rels_bytes) if rels_bytes else etree.Element(  
            "Relationships",  
            xmlns="http://schemas.openxmlformats.org/package/2006/relationships",  
        )  
    except Exception:  
        root = etree.Element("Relationships", xmlns="http://schemas.openxmlformats.org/package/2006/relationships")  
    for rel in root.findall(".//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship"):  
        if rel.get("Id") == rid:  
            rel.set("Target", new_target)  
    return etree.tostring(root, encoding="utf-8", xml_declaration=True)  
  
def _remove_shape_node(node: etree._Element) -> bool:  
    ####### remove nearest w:r or shape container ######## 
    p = node  
    while p is not None and p.tag not in {f"{{{WP}}}inline", f"{{{WP}}}anchor", qn("w:pict"), f"{{{V}}}shape"}:  
        p = p.getparent()  
    target = p  
    #########3 bubble to w:r if exists  ##########
    r = target  
    while r is not None and r.tag != qn("w:r"):  
        r = r.getparent()  
    target = r or target  
    gp = target.getparent()  
    if gp is not None:  
        try:  
            gp.remove(target)  
            return True  
        except Exception:  
            return False  
    return False  
  
def _scan_part_for_actions(part_xml: bytes, rels_bytes: bytes, in_header_or_footer: bool) -> tuple[bytes, bytes, dict]:  
     
    actions = {"removed_energy": 0, "replaced_old_hitachi": 0}  
    try:  
        root = etree.fromstring(part_xml)  
    except Exception:  
        return part_xml, rels_bytes, actions  
  
    rels = _rels_map(rels_bytes)  
  
    ########## 1) Remove “Hitachi Energy” logos in shapes/textboxes (no blip required)  #########
    ######## w:pict/v:shape with text  #########
    for vshape in list(root.findall(".//w:pict//v:shape", namespaces=NS)):  
        txt = _text_in_shape(vshape)  
        if not txt:  
            continue  
        if "hitachi" in txt and "energy" in txt:  
            if _remove_shape_node(vshape):  
                actions["removed_energy"] += 1  
  
    ######### wps shapes  #########
    for wsp in list(root.findall(".//wps:wsp", namespaces=NS)):  
        txt = _text_in_shape(wsp)  
        if txt and "hitachi" in txt and "energy" in txt:  
            if _remove_shape_node(wsp):  
                actions["removed_energy"] += 1  
  
    ########## 2) Images in drawing: classify by docPr text + size + ext -> remove Energy, replace old Hitachi  #########
    for drawing in list(root.findall(".//w:drawing", namespaces=NS)):  
        name, descr = _docpr_info(drawing)  
        cx, cy = _inline_size_emu(drawing)  
        rid = None  
        ######## PIC image  #########
        blip = drawing.find(".//pic:blipFill//a:blip", namespaces=NS)  
        if blip is not None:  
            rid = blip.get(f"{{{R}}}embed")  
        ######## VML image inside pict  #########
        if rid is None:  
            imd = drawing.find(".//w:pict//v:imagedata", namespaces=NS)  
            if imd is not None:  
                rid = imd.get(f"{{{R}}}id")  
        if not rid:  
            ######## If shape has text only  #########
            txt = _text_in_shape(drawing)  
            if txt and "hitachi" in txt and "energy" in txt and _remove_shape_node(drawing):  
                actions["removed_energy"] += 1  
            continue  
  
        tgt_mode = ""  
        tgt = ""  
        if rid in rels:  
            tgt, tgt_mode = rels[rid]  
        ext = Path(tgt).suffix.lower()  
  
        ####### Decide by docPr text or shape text  ###########
        txt = " ".join([name, descr, _text_in_shape(drawing)]).strip().lower()  
        is_logo_size = _is_logo_like_size(cx, cy) or (in_header_or_footer and ext in DOCX_VECTOR_EXTS)  
  
        ######## Remove Energy logos  #########
        if ("hitachi" in txt and "energy" in txt and is_logo_size) or (in_header_or_footer and ext in DOCX_VECTOR_EXTS and "energy" in txt):  
            ######## delete drawing node (keep rel id removal to pre-clean or leave rel; Word tolerates extra rels)  #########
            if _remove_shape_node(drawing):  
                actions["removed_energy"] += 1  
            continue  
  
        ######## Replace old HITACHI Inspire/Next logos by swapping target  #########
        if ("hitachi" in txt and ("inspire" in txt or "next" in txt or "brand" in txt)) and is_logo_size:  
            ######## Insert/ensure PNG, update rel target to rebranded logo  #########
            ######## Add media in replacements at calling site; here we just mark an attribute  #########
            drawing.set("_needs_replace_rid", rid)  # mark for caller  
            actions["replaced_old_hitachi"] += 1  
  
    ######### serialize updated part  ###########3
    new_part_xml = etree.tostring(root, encoding="utf-8", xml_declaration=True)  
    return new_part_xml, rels_bytes, actions  

 
def _docx_zip_read(docx_bytes: bytes) -> tuple[list[str], dict[str, bytes]]:  
    z = zipfile.ZipFile(io.BytesIO(docx_bytes), "r")  
    names = z.namelist()  
    data = {n: z.read(n) for n in names}  
    z.close()  
    return names, data  
  
def _docx_zip_write(original: dict[str, bytes],  
                    replacements: dict[str, bytes],  
                    removed: set[str]) -> bytes:  
    buf = io.BytesIO()  
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zout:  
        for n, b in original.items():  
            if n in removed:  
                continue  
            zout.writestr(n, replacements.get(n, b))  
        for n, b in replacements.items():  
            if n not in original:  
                zout.writestr(n, b)  
    return buf.getvalue()  
  
def _ensure_ct_png(ct_bytes: bytes) -> bytes:  
    try:  
        root = etree.fromstring(ct_bytes)  
        tag = f"{{{CT}}}Default"  
        for el in root.findall(tag):  
            if el.get("Extension", "").lower() == "png":  
                return ct_bytes  
        root.append(etree.Element(tag, Extension="png", ContentType="image/png"))  
        return etree.tostring(root, encoding="utf-8", xml_declaration=True)  
    except Exception:  
        return ct_bytes  
###########relationship target resolution (handles _rels/.rels) #############
import posixpath  
  
def _rels_base_part_from_rels_name(rels_name: str) -> str:  
    # word/_rels/header1.xml.rels -> word/header1.xml  
    rels_name = rels_name.replace("\\", "/")  
    if "/_rels/" in rels_name and rels_name.endswith(".rels"):  
        left, right = rels_name.split("/_rels/", 1)  
        return posixpath.normpath(f"{left}/{right[:-5]}")  
    return ""  
  
def _resolve_target_full(rels_name: str, target: str) -> str:  
     
    target = (target or "").replace("\\", "/")  
    if target.startswith(("http://", "https://", "file:", "mailto:", "ftp://")):  
        return target  # external, skip in validator/usage  
  
    base_part = _rels_base_part_from_rels_name(rels_name)  ###### e.g., word/header1.xml or "" for _rels/.rels  
    base_dir = posixpath.dirname(base_part)  # "" for root  
  
    ######## Join inside a virtual root so normpath can drop leading ".."  ########
    joined = posixpath.normpath(posixpath.join("/" + base_dir, target))  
    ######## Strip the leading slash to return a package-relative part name  ########
    return joined.lstrip("/")    
def _rels_parse(rels_bytes: bytes) -> list[tuple[str, str, str]]:  
     
    out = []  
    try:  
        root = etree.fromstring(rels_bytes)  
        for rel in root.findall(".//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship"):  
            out.append((rel.get("Id"), rel.get("Target", ""), rel.get("TargetMode", "")))  
    except Exception:  
        pass  
    return out  
  
def _rels_remove_ids(rels_bytes: bytes, ids: set[str]) -> bytes:  
    try:  
        root = etree.fromstring(rels_bytes)  
        changed = False  
        for rel in list(root.findall(".//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship")):  
            if rel.get("Id") in ids:  
                root.remove(rel); changed = True  
        return etree.tostring(root, encoding="utf-8", xml_declaration=True) if changed else rels_bytes  
    except Exception:  
        return rels_bytes  
  
def _rels_base_part_from_rels_name(rels_name: str) -> str:  
    ######## word/_rels/header1.xml.rels -> word/header1.xml  ########
    rels_name = rels_name.replace("\\", "/")  
    if "/_rels/" in rels_name and rels_name.endswith(".rels"):  
        left, right = rels_name.split("/_rels/", 1)  
        return posixpath.normpath(f"{left}/{right[:-5]}")  
    return ""  
  
def _resolve_target_full(rels_name: str, target: str) -> str:  
    """  
    Resolve a relationship Target to a package-internal part path (no leading slash).  
    Handles ../, /, and backslashes.  
    """  
    target = (target or "").replace("\\", "/")  
    base_part = _rels_base_part_from_rels_name(rels_name)  # e.g., word/header1.xml  
    base_dir = posixpath.dirname(base_part) if base_part else "word"  
    if target.startswith("/"):  
        return target.lstrip("/")  
    return posixpath.normpath(posixpath.join(base_dir, target))  
  
def _collect_media_usage(original: dict[str, bytes]) -> dict[str, int]:  
    usage: dict[str, int] = {}  
    for rels_name, rels_bytes in original.items():  
        if not rels_name.endswith(".rels"):  
            continue  
        for rid, tgt, mode in _rels_parse(rels_bytes):  
            if mode == "External":  
                continue  
            full = _resolve_target_full(rels_name, tgt)  
            if "/media/" in full:  
                usage[full] = usage.get(full, 0) + 1  
    return usage  
  
def _guess_inline_size_emu(inline_el: etree._Element) -> tuple[int, int]:  
    try:  
        ext = inline_el.find("wp:extent", namespaces=NS_HF)  
        if ext is not None:  
            return int(ext.get("cx", "0")), int(ext.get("cy", "0"))  
    except Exception:  
        pass  
    return 0, 0  
  
def _remove_parent_run(node: etree._Element) -> None:  
    p = node  
    while p is not None and p.tag not in {qn("w:drawing"), qn("w:pict"), f"{{{V}}}shape"}:  
        p = p.getparent()  
    if p is None:  
        return  
    r = p  
    while r is not None and r.tag != qn("w:r"):  
        r = r.getparent()  
    target = r if r is not None else p  
    gp = target.getparent()  
    if gp is not None:  
        try:  
            gp.remove(target)  
        except Exception:  
            pass  
  
def _remove_blips_for_rids(hf_root: etree._Element, rids: set[str]) -> bool:  
    removed = False  
    for rid in list(rids):  
        for blip in hf_root.findall(f".//a:blip[@r:embed='{rid}']", namespaces=NS_HF):  
            _remove_parent_run(blip); removed = True  
        for im in hf_root.findall(f".//v:imagedata[@r:id='{rid}']", namespaces=NS_HF):  
            _remove_parent_run(im); removed = True  
    for p in list(hf_root.findall(".//w:p", namespaces=NS_HF)):  
        if not p.findall(".//w:t", namespaces=NS_HF) and not p.findall(".//w:drawing", namespaces=NS_HF) and not p.findall(".//w:pict", namespaces=NS_HF):  
            parent = p.getparent()  
            if parent is not None:  
                try:  
                    parent.remove(p); removed = True  
                except Exception:  
                    pass  
    return removed  
  
def _remove_glyph_logo_runs(hf_root: etree._Element) -> bool:  
    removed = False  
    keys = {"hitachi", "inspire", "next", "energy"}  
    for p in hf_root.findall(".//w:p", namespaces=NS_HF):  
        runs = p.findall(".//w:r", namespaces=NS_HF)  
        if not runs:  
            continue  
        score, del_runs = 0, []  
        for r in runs:  
            ts = r.findall(".//w:t", namespaces=NS_HF)  
            txt = "".join(t.text or "" for t in ts).strip().lower()  
            if not txt:  
                continue  
            if len(txt) <= 2:  
                score += 1; del_runs.append(r)  
            if any(k in txt for k in keys):  
                score += 2; del_runs.append(r)  
        if score >= max(2, len(runs) // 2):  
            for r in del_runs:  
                try:  
                    p.remove(r); removed = True  
                except Exception:  
                    pass  
            if not p.findall(".//w:r", namespaces=NS_HF):  
                parent = p.getparent()  
                if parent is not None:  
                    try:  
                        parent.remove(p); removed = True  
                    except Exception:  
                        pass  
    return removed  
  
def _build_header_logo_paragraph(new_rid: str, w_px: int, h_px: int,  
                                 align_right: bool = True,  
                                 name: str = "Hitachi New Brand Logo") -> etree._Element:  
    cx = int(w_px * DOCX_EMU_PER_PX)  
    cy = int(h_px * DOCX_EMU_PER_PX)  
  
    w_p = etree.Element(qn("w:p"))  
    w_pPr = etree.SubElement(w_p, qn("w:pPr"))  
    if align_right:  
        etree.SubElement(w_pPr, qn("w:jc"), **{qn("w:val"): "right"})  
  
    w_r = etree.SubElement(w_p, qn("w:r"))  
    w_drawing = etree.SubElement(w_r, qn("w:drawing"))  
    wp_inline = etree.SubElement(w_drawing, f"{{{WP}}}inline", distT="0", distB="0", distL="0", distR="0")  
    etree.SubElement(wp_inline, f"{{{WP}}}extent", cx=str(cx), cy=str(cy))  
    etree.SubElement(wp_inline, f"{{{WP}}}docPr", id="1", name=name)  
  
    a_graphic = etree.SubElement(wp_inline, f"{{{A}}}graphic")  
    a_graphicData = etree.SubElement(a_graphic, f"{{{A}}}graphicData", uri=PIC)  
  
    pic_pic = etree.SubElement(a_graphicData, f"{{{PIC}}}pic")  
    nv = etree.SubElement(pic_pic, f"{{{PIC}}}nvPicPr")  
    etree.SubElement(nv, f"{{{PIC}}}cNvPr", id="0", name=name)  
    etree.SubElement(nv, f"{{{PIC}}}cNvPicPr")  
  
    blipFill = etree.SubElement(pic_pic, f"{{{PIC}}}blipFill")  
    etree.SubElement(blipFill, f"{{{A}}}blip", **{f"{{{R}}}embed": new_rid})  
    stretch = etree.SubElement(blipFill, f"{{{A}}}stretch")  
    etree.SubElement(stretch, f"{{{A}}}fillRect")  
  
    spPr = etree.SubElement(pic_pic, f"{{{PIC}}}spPr")  
    etree.SubElement(spPr, f"{{{A}}}xfrm")  
    prst = etree.SubElement(spPr, f"{{{A}}}prstGeom", prst="rect")  
    etree.SubElement(prst, f"{{{A}}}avLst")  
  
    return w_p  
  
def _next_rel_id(rels: list[tuple[str, str, str]]) -> str:  
    i = 100  
    ids = {r[0] for r in rels if r[0]}  
    while True:  
        cand = f"rId{i}"  
        if cand not in ids:  
            return cand  
        i += 1  
  
  
#################DOCX brand fixer: removes Energy vectors, replaces old HITACHI vectors ----------------  
def _docx_brand_fix(docx_bytes: bytes,  
                    new_logo_png_bytes: bytes | None,  
                    *,  
                    debug: bool = False) -> bytes:  
    names, original = _docx_zip_read(docx_bytes)  
    replacements: dict[str, bytes] = {}  
  
    ########### Keep PNG content-type  #############
    if "[Content_Types].xml" in original:  
        replacements["[Content_Types].xml"] = _ensure_ct_png(original["[Content_Types].xml"])  
  
    ###### Place the PNG in package if provided ###### 
    logo_media_name = "word/media/rebr_header_logo.png"  
    if new_logo_png_bytes:  
        replacements[logo_media_name] = new_logo_png_bytes  
  
    parts = ["word/document.xml"] + [n for n in names if n.startswith("word/") and n.endswith(".xml") and ("header" in n or "footer" in n)]  
    removed_energy_total = 0  
    replaced_old_total = 0  
  
    for part_name in parts:  
        part_xml = replacements.get(part_name, original.get(part_name, b""))  
        if not part_xml:  
            continue  
        rels_name = f"word/_rels/{Path(part_name).name}.rels" if part_name.startswith("word/") else ""  
        rels_bytes = replacements.get(rels_name, original.get(rels_name, b""))  
        in_hf = ("header" in part_name) or ("footer" in part_name)  
  
        new_part_xml, new_rels_bytes, actions = _scan_part_for_actions(part_xml, rels_bytes, in_hf)  
        removed_energy_total += actions["removed_energy"]  
        replaced_old_total += actions["replaced_old_hitachi"]  
  
        ######### If we marked drawings for replace, swap their relationship targets to our PNG  #######
        if new_logo_png_bytes and actions["replaced_old_hitachi"] > 0:  
            try:  
                root = etree.fromstring(new_part_xml)  
                rels_list = _rels_parse_list(new_rels_bytes)  
                if not rels_list:  
                    rel_root = etree.Element("Relationships", xmlns="http://schemas.openxmlformats.org/package/2006/relationships")  
                    new_rels_bytes = etree.tostring(rel_root, encoding="utf-8", xml_declaration=True)  
                ###### Walk again to change rel targets ###### 
                changed_any = False  
                for drawing in root.findall(".//w:drawing", namespaces=NS):  
                    rid_mark = drawing.get("_needs_replace_rid")  
                    if rid_mark:  
                        ###### Update rel target to our PNG ###### 
                        new_rels_bytes = _rels_update_target(new_rels_bytes, rid_mark, "media/rebr_header_logo.png")  
                        ###### Clear marker ###### 
                        drawing.attrib.pop("_needs_replace_rid", None)  
                        changed_any = True  
                if changed_any:  
                    new_part_xml = etree.tostring(root, encoding="utf-8", xml_declaration=True)  
            except Exception as e:  
                if debug: print("Replace old HITACHI swap failed in", part_name, ":", e)  
    
        replacements[part_name] = new_part_xml  
        if rels_name:  
            replacements[rels_name] = new_rels_bytes  
  
    if debug:  
        print(f"Brand fix: removed Energy vectors={removed_energy_total}, replaced old HITACHI vectors={replaced_old_total}")  
  
    out_bytes = _docx_zip_write(original, replacements, removed=set())  
    return out_bytes  
def _docx_validate(docx_bytes: bytes, *, allow_missing_docprops: bool = True) -> tuple[bool, str]:  
    try:  
        with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as z:  
            names = z.namelist()  
            name_set = set(n.replace("\\", "/") for n in names)  
            if "[Content_Types].xml" not in name_set:  
                return False, "Missing [Content_Types].xml"  
  
            for rels_name in [n for n in names if n.endswith(".rels")]:  
                rels_bytes = z.read(rels_name)  
                root = etree.fromstring(rels_bytes)  
                for rel in root.findall(".//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship"):  
                    tgt = rel.get("Target", "")  
                    mode = rel.get("TargetMode", "")  
                    if mode == "External":  
                        continue  
                    full = _resolve_target_full(rels_name, tgt)  
                    ######## Tolerate missing docProps/* if requested (seen in many converted DOCX)  ########
                    if allow_missing_docprops and full.startswith("docProps/"):  
                        continue  
                    if full not in name_set:  
                        return False, f"Dangling target: {full} from {rels_name}"  
        return True, "ok"  
    except Exception as e:  
        return False, f"zip/xml error: {e}"   
  
def _docx_preclean_vector_and_glyphs_v3(docx_bytes: bytes,  
                                        *,  
                                        delete_unused_media: bool = True,  
                                        insert_header_logo: bool = True) -> bytes:  
    names, original = _docx_zip_read(docx_bytes)  
    replacements: dict[str, bytes] = {}  
    removed_files: set[str] = set()  
  
    if "[Content_Types].xml" in original:  
        replacements["[Content_Types].xml"] = _ensure_ct_png(original["[Content_Types].xml"])  
  
    usage_map = _collect_media_usage(original)  
    media_decrements: dict[str, int] = {}  
  
    hf_xmls = [n for n in names if n.startswith("word/") and n.endswith(".xml") and ("header" in n or "footer" in n)]  
    touched_headers: set[str] = set()  
  
    for hf in hf_xmls:  
        try:  
            root = etree.fromstring(replacements.get(hf, original[hf]))  
        except Exception:  
            replacements[hf] = original[hf]  
            continue  
  
        rels_name = f"word/_rels/{Path(hf).name}.rels"  
        rels_bytes = replacements.get(rels_name, original.get(rels_name, b""))  
        rels_list = _rels_parse(rels_bytes)  
  
        vector_rids: set[str] = set()  
        for rid, tgt, mode in rels_list:  
            if not rid or mode == "External":  
                continue  
            ext = Path(tgt).suffix.lower()  
            if ext not in DOCX_VECTOR_EXTS:  
                continue  
            ###### geometry check for headers; always remove in footers ###### 
            logo_like = False  
            for blip in root.findall(f".//a:blip[@r:embed='{rid}']", namespaces=NS_HF):  
                inline = blip  
                while inline is not None and inline.tag != f"{{{WP}}}inline":  
                    inline = inline.getparent()  
                if inline is not None:  
                    cx, cy = _guess_inline_size_emu(inline)  
                    if cx and cy:  
                        if (cx / max(1, cy)) >= DOCX_HF_VECTOR_MIN_W_H_RATIO and cy <= DOCX_HF_VECTOR_MAX_HEIGHT_EMU:  
                            logo_like = True  
                            break  
            if "footer" in hf or logo_like or DOCX_DELETE_ALL_VECTOR_IN_HF:  
                vector_rids.add(rid)  
  
        removed_nodes = _remove_blips_for_rids(root, vector_rids)  
        glyph_removed = _remove_glyph_logo_runs(root)  
  
        if removed_nodes or glyph_removed:  
            ###### update rels file by removing selected ids ###### 
            if rels_bytes:  
                replacements[rels_name] = _rels_remove_ids(rels_bytes, vector_rids)  
  
            ###### schedule media deletions using accurate path resolution ###### 
            for rid, tgt, mode in rels_list:  
                if rid in vector_rids and mode != "External":  
                    full = _resolve_target_full(rels_name, tgt)  
                    media_decrements[full] = media_decrements.get(full, 0) + 1  
  
            if "header" in hf:  
                touched_headers.add(hf)  
  
        replacements[hf] = etree.tostring(root, encoding="utf-8", xml_declaration=True)  
  
    ###### Remove unused media only when NO other part still references it ###### 
    if delete_unused_media and media_decrements:  
        for media_path, dec in media_decrements.items():  
            if usage_map.get(media_path, 0) <= dec and media_path in original:  
                removed_files.add(media_path)  
  
    ###### Insert new header logo if at least one header was touched ###### 
    if insert_header_logo and touched_headers:  
        ###### load PNG ###### 
        png_key = REPLACEMENT_LOGOS.get("hitachi_inspire")  
        png_bytes = None  
        if png_key:  
            for p in (Path(png_key),  
                      Path.cwd() / png_key,  
                      Path(__file__).resolve().parent / png_key if "__file__" in globals() else None,  
                      Path("/home/site/wwwroot") / png_key):  
                if p and p.exists():  
                    png_bytes = p.read_bytes()  
                    break  
        if png_bytes:  
            replacements["word/media/rebr_header_logo.png"] = png_bytes  
            try:  
                from PIL import Image as _PILImage  
                w_px, h_px = _PILImage.open(io.BytesIO(png_bytes)).size  
            except Exception:  
                w_px, h_px = DOCX_HEADER_LOGO_SIZE_PX  
  
            for hf in touched_headers:  
                root = etree.fromstring(replacements.get(hf, original[hf]))  
                rels_name = f"word/_rels/{Path(hf).name}.rels"  
                rels_bytes = replacements.get(rels_name, original.get(rels_name, b""))  
                rels_list = _rels_parse(rels_bytes)  
                  
                try:  
                    rel_root = etree.fromstring(rels_bytes) if rels_bytes else etree.Element(  
                        "Relationships",  
                        xmlns="http://schemas.openxmlformats.org/package/2006/relationships",  
                    )  
                except Exception:  
                    rel_root = etree.Element("Relationships",  
                                             xmlns="http://schemas.openxmlformats.org/package/2006/relationships")  
                new_rid = _next_rel_id(rels_list)  
                etree.SubElement(  
                    rel_root, "Relationship",  
                    Id=new_rid,  
                    Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",  
                    Target="media/rebr_header_logo.png",  
                )  
                replacements[rels_name] = etree.tostring(rel_root, encoding="utf-8", xml_declaration=True)  
  
                w_p_logo = _build_header_logo_paragraph(new_rid, w_px, h_px,  
                                                        align_right=DOCX_HEADER_LOGO_ALIGN_RIGHT)  
                root.append(w_p_logo)  
                replacements[hf] = etree.tostring(root, encoding="utf-8", xml_declaration=True)  
  
      
    return _docx_zip_write(original, replacements, removed_files)  
  
def process_docx_consolidated(  
    docx_path,  
    output_path,  
    *,  
    template_cover=False,  
    template_img=None,  
    debug=False,  
):  
      
    import io  
    import zipfile  
    import posixpath  
    from pathlib import Path  
    from lxml import etree  
  
    ####### Namespaces  #######
    W   = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"  
    R   = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"  
    WP  = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"  
    A   = "http://schemas.openxmlformats.org/drawingml/2006/main"  
    PIC = "http://schemas.openxmlformats.org/drawingml/2006/picture"  
    V   = "urn:schemas-microsoft-com:vml"  
    WPS = "http://schemas.microsoft.com/office/word/2010/wordprocessingShape"  
    NS = {"w": W, "r": R, "wp": WP, "a": A, "pic": PIC, "v": V, "wps": WPS}  
  
    IMAGE_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"  
    DOCX_VECTOR_EXTS = {".emf", ".wmf", ".svg", ".eps"}  
    DOCX_LOGO_MAX_HEIGHT_EMU = int(914400 * 0.95)  ###### ~0.95 inch tall  
    DOCX_LOGO_MIN_W_H = 1.8                        ###### width/height ratio  
  
    ############## 1x1 transparent PNG bytes############  
    BLANK_PNG = (  
        b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"  
        b"\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\x0bIDATx\xda\x63\x00"  
        b"\x01\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82"  
    )  
  
      
    def _zip_read(docx_bytes: bytes) -> dict[str, bytes]:  
        out = {}  
        with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as z:  
            for n in z.namelist():  
                out[n.replace("\\", "/")] = z.read(n)  
        return out  
  
    def _zip_write(original: dict[str, bytes], replacements: dict[str, bytes], removed: set[str]) -> bytes:  
        buf = io.BytesIO()  
        with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:    
            for name, data in original.items():  
                if name in removed:  
                    continue  
                if name in replacements:  
                    z.writestr(name, replacements[name])  
                else:  
                    z.writestr(name, data)    
            for name, data in replacements.items():  
                if name not in original:  
                    z.writestr(name, data)  
        return buf.getvalue()  
  
    def _rels_base_part_from_rels_name(rels_name: str) -> str:  
        rels_name = rels_name.replace("\\", "/")  
        if "/_rels/" in rels_name and rels_name.endswith(".rels"):  
            left, right = rels_name.split("/_rels/", 1)  
            return posixpath.normpath(f"{left}/{right[:-5]}")  
        return ""  
  
    def _resolve_target_full(rels_name: str, target: str) -> str:  
        target = (target or "").replace("\\", "/")  
        if target.startswith(("http://", "https://", "file:", "mailto:", "ftp://")):  
            return target  
        base_part = _rels_base_part_from_rels_name(rels_name)  
        base_dir = posixpath.dirname(base_part)  
        joined = posixpath.normpath(posixpath.join("/" + base_dir, target))  
        return joined.lstrip("/")  
  
    def _rels_parse(rels_bytes: bytes) -> etree._Element:  
        if rels_bytes:  
            try:  
                return etree.fromstring(rels_bytes)  
            except Exception:  
                pass  
        return etree.Element("Relationships", xmlns="http://schemas.openxmlformats.org/package/2006/relationships")  
  
    def _rels_to_map(rel_root: etree._Element) -> dict[str, tuple[str, str, str]]:  
        out = {}  
        for rel in rel_root.findall(".//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship"):  
            rid = rel.get("Id")  
            if not rid:  
                continue  
            out[rid] = (rel.get("Target", ""), rel.get("TargetMode", ""), rel.get("Type", ""))  
        return out  
  
    def _rels_update_target(rel_root: etree._Element, rid: str, new_target: str, *, type_hint: str | None = None):  
        for rel in rel_root.findall(".//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship"):  
            if rel.get("Id") == rid:  
                rel.set("Target", new_target)  
                if type_hint:  
                    rel.set("Type", type_hint)  
  
    def _serialize_xml(root: etree._Element) -> bytes:  
        return etree.tostring(root, encoding="utf-8", xml_declaration=True)  
  
    def _ensure_ct_png(ct_bytes: bytes, extra_png_names: list[str]) -> bytes:  
        try:  
            root = etree.fromstring(ct_bytes)  
        except Exception:  
            root = etree.Element("Types", xmlns="http://schemas.openxmlformats.org/package/2006/content-types")  
        ######## add Default extension=png if not present  ########
        has_default_png = any(  
            el.tag == "{http://schemas.openxmlformats.org/package/2006/content-types}Default"  
            and (el.get("Extension") or "").lower() == "png"  
            for el in root  
        )  
        if not has_default_png:  
            d = etree.Element("{http://schemas.openxmlformats.org/package/2006/content-types}Default")  
            d.set("Extension", "png")  
            d.set("ContentType", "image/png")  
            root.append(d)  
        ########### Optional overrides ##########  
        for n in sorted(set(extra_png_names)):  
            ov = etree.Element("{http://schemas.openxmlformats.org/package/2006/content-types}Override")  
            ov.set("PartName", "/" + n)  
            ov.set("ContentType", "image/png")  
            root.append(ov)  
        return _serialize_xml(root)  
  
    def _text_in_shape(el: etree._Element) -> str:  
        ts = []  
        for t in el.findall(".//w:txbxContent//w:t", namespaces=NS):  
            ts.append(t.text or "")  
        for t in el.findall(".//a:txBody//a:t", namespaces=NS):  
            ts.append(t.text or "")  
        return " ".join(ts).strip().lower()  
  
    def _docpr_info(drawing_el: etree._Element) -> tuple[str, str]:  
        name = descr = ""  
        docpr = drawing_el.find(".//wp:docPr", namespaces=NS)  
        if docpr is not None:  
            name = docpr.get("name", "") or ""  
            descr = docpr.get("descr", "") or ""  
        return name.lower(), descr.lower()  
  
    def _inline_size_emu(drawing_el: etree._Element) -> tuple[int, int]:  
        inline = drawing_el.find(".//wp:inline", namespaces=NS)  
        anchor = drawing_el.find(".//wp:anchor", namespaces=NS)  
        host = inline or anchor  
        if host is None:  
            return (0, 0)  
        ext = host.find("wp:extent", namespaces=NS)  
        if ext is None:  
            return (0, 0)  
        try:  
            return int(ext.get("cx", "0")), int(ext.get("cy", "0"))  
        except Exception:  
            return (0, 0)  
  
    def _is_logo_like(cx: int, cy: int, *, in_header_or_footer: bool) -> bool:  
        if not cx or not cy:  
            return False  
        ratio_ok = cx / max(1, cy) >= DOCX_LOGO_MIN_W_H  
        height_ok = cy <= DOCX_LOGO_MAX_HEIGHT_EMU or in_header_or_footer  
        return ratio_ok and height_ok  
  
    def _brand_fix_no_delete(docx_bytes: bytes,  
                         new_logo_png_bytes: bytes | None,  
                         *,  
                         debug_local: bool,  
                         pass_name: str) -> bytes:  
        from pathlib import Path  
        from lxml import etree  
        import struct  
    
         
        NS2 = dict(NS)  
        NS2.setdefault("asvg", "http://schemas.microsoft.com/office/drawing/2016/SVG/main")  
        NS2.setdefault("a14",  "http://schemas.microsoft.com/office/drawing/2010/main")  
    
        EMU_PER_IN = 914400  
        VECTOR_EXTS = {".emf", ".wmf", ".svg", ".eps"}  
    
        ###### Tuning ######## 
        HEADER_LOGO_MAX_H_IN = 0.30  
        FOOTER_LOGO_MAX_H_IN = 0.40  
        FOOTER_LOGO_MIN_RATIO = 0.7   ###### allow near-square stamps  
        PURE_VECTOR_MIN_H_IN   = 0.12 ###### ignore hairline rules  
        PURE_VECTOR_MAX_H_IN   = 0.60  
        PURE_VECTOR_MAX_RATIO  = 10.0 ###### avoid long lines  
    
        blank_name = "word/media/blank.png"  
        logo_name  = "word/media/rebr_header_logo.png"  
    
        ###### PNG size (aspect) for header replacement ####### 
        def _png_wh(png: bytes | None) -> tuple[int, int]:  
            if not png or len(png) < 24:  
                return (600, 120)  
            try:  
                return (int.from_bytes(png[16:20], "big") or 600,  
                        int.from_bytes(png[20:24], "big") or 120)  
            except Exception:  
                return (600, 120)  
    
        PNG_W, PNG_H = _png_wh(new_logo_png_bytes)  
        PNG_RATIO = PNG_W / max(1, PNG_H)  
    
        def _clear_pic_frame_fills(drawing_el: etree._Element):  
            for spPr in drawing_el.findall(".//pic:spPr", namespaces=NS2):  
                for tag in (f"{{{A}}}solidFill", f"{{{A}}}gradFill", f"{{{A}}}pattFill"):  
                    for n in spPr.findall(tag):  
                        n.getparent().remove(n)  
                if spPr.find(f"{{{A}}}noFill") is None:  
                    spPr.append(etree.Element(f"{{{A}}}noFill"))  
                for ln in spPr.findall(f"{{{A}}}ln", namespaces=NS2):  
                    ln.getparent().remove(ln)  
    
        def _clear_all_vector_shapes(container: etree._Element):  
            ###### Remove fills/lines from vector-only groups/shapes (a:spPr, a:grpSpPr, wps:spPr) ###### 
            for tag in (f"{{{A}}}spPr", f"{{{A}}}grpSpPr", f"{{{WPS}}}spPr"):  
                for spPr in container.findall(f".//{tag}", namespaces=NS2):  
                    for t in (f"{{{A}}}solidFill", f"{{{A}}}gradFill", f"{{{A}}}pattFill"):  
                        for n in spPr.findall(t):  
                            n.getparent().remove(n)  
                    if spPr.find(f"{{{A}}}noFill") is None:  
                        spPr.append(etree.Element(f"{{{A}}}noFill"))  
                    for ln in spPr.findall(f"{{{A}}}ln", namespaces=NS2):  
                        ln.getparent().remove(ln)  
    
        def _fit_wp_extent_to_png(drawing_el: etree._Element, max_h_in: float):  
            host = drawing_el.find(".//wp:inline", namespaces=NS2) or drawing_el.find(".//wp:anchor", namespaces=NS2)  
            if host is None:  
                return  
            ext = host.find("wp:extent", namespaces=NS2)  
            if ext is None:  
                ext = etree.Element(f"{{{WP}}}extent")  
                host.append(ext)  
            try:  
                old_cy = int(ext.get("cy", "0")) or int(max_h_in * EMU_PER_IN)  
            except Exception:  
                old_cy = int(max_h_in * EMU_PER_IN)  
            new_cy = min(old_cy, int(max_h_in * EMU_PER_IN))  
            new_cx = int(new_cy * PNG_RATIO)  
            ext.set("cy", str(new_cy))  
            ext.set("cx", str(new_cx))  
    
        def _collect_all_image_rids(container: etree._Element) -> set[str]:  
            rids = set()  
            ##### Standard blip  #######3
            for blip in container.findall(".//a:blip", namespaces=NS2):  
                r = blip.get(f"{{{R}}}embed") or blip.get(f"{{{R}}}link")  
                if r:  
                    rids.add(r)  
                #####3 SVG extension IDs ######## 
                for svg in blip.findall(".//a:extLst//a:ext//asvg:svgBlip", namespaces=NS2):  
                    rs = svg.get(f"{{{R}}}embed") or svg.get(f"{{{R}}}link")  
                    if rs:  
                        rids.add(rs)  
            ####### VML imagedata  #######
            for imd in container.findall(".//w:pict//v:imagedata", namespaces=NS2):  
                r = imd.get(f"{{{R}}}id")  
                if r:  
                    rids.add(r)  
            return rids  
    
        def _media_has_brand(rels_name_local: str, rels_map_local: dict, rid: str) -> bool:  
            try:  
                tgt = rels_map_local[rid][0]  
                full = _resolve_target_full(rels_name_local, tgt)  
                data = original.get(full, b"")  
                if not data:  
                    return False  
                low = data.lower()  
                return (b"hitachi" in low) or (b"energy" in low)  
            except Exception:  
                return False  
    
        def _is_footer_logo_by_size(cx: int, cy: int) -> bool:  
            if not cx or not cy:  
                return False  
            h_in = cy / EMU_PER_IN  
            ratio = cx / max(1, cy)  
            return (h_in <= FOOTER_LOGO_MAX_H_IN) and (ratio >= FOOTER_LOGO_MIN_RATIO)  
    
        def _is_pure_vector_logo(cx: int, cy: int) -> bool:  
            if not cx or not cy:  
                return False  
            h_in = cy / EMU_PER_IN  
            ratio = cx / max(1, cy)  
            return (PURE_VECTOR_MIN_H_IN <= h_in <= PURE_VECTOR_MAX_H_IN) and (ratio <= PURE_VECTOR_MAX_RATIO)  
    
        def _update_targets_to(rels_root_local: etree._Element, rids: set[str], new_target: str):  
            for rid in rids:  
                _rels_update_target(rels_root_local, rid, new_target, type_hint=IMAGE_REL_TYPE)  
    
          
        original = _zip_read(docx_bytes)  
        names = list(original.keys())  
        replacements: dict[str, bytes] = {}  
        removed: set[str] = set()  
    
        ###### Inject media + ensure content types ###### 
        replacements[blank_name] = BLANK_PNG  
        if new_logo_png_bytes:  
            replacements[logo_name] = new_logo_png_bytes  
        if "[Content_Types].xml" in original:  
            extra = [blank_name] + ([logo_name] if new_logo_png_bytes else [])  
            replacements["[Content_Types].xml"] = _ensure_ct_png(original["[Content_Types].xml"], extra)  
    
        parts = ["word/document.xml"] + [n for n in names if n.startswith("word/") and n.endswith(".xml") and ("header" in n or "footer" in n)]  
    
        removed_energy = 0  
        replaced_header = 0  
        text_cleared = 0  
        pure_vector_cleared = 0  
    
        for part_name in parts:  
            part_xml = replacements.get(part_name, original.get(part_name, b""))  
            if not part_xml:  
                continue  
            rels_name = f"word/_rels/{Path(part_name).name}.rels"  
            rels_root = _rels_parse(original.get(rels_name, b""))  
            rels_map = _rels_to_map(rels_root)  
            in_header = "header" in part_name  
            in_footer = "footer" in part_name  
    
            try:  
                root = etree.fromstring(part_xml)  
            except Exception as e:  
                if debug_local:  
                    print(f"[{pass_name}] XML parse error in {part_name}: {e}")  
                replacements[part_name] = part_xml  
                if rels_name in original:  
                    replacements[rels_name] = original[rels_name]  
                continue  
    
            ###### Clear "Hitachi Energy" text in textboxes ###### 
            for node in root.findall(".//w:txbxContent", namespaces=NS2):  
                txt = " ".join([t.text or "" for t in node.findall(".//w:t", namespaces=NS2)]).lower()  
                if "hitachi" in txt and "energy" in txt:  
                    for t in node.findall(".//w:t", namespaces=NS2):  
                        t.text = ""  
                    text_cleared += 1  
    
            ###### Process all drawings ###### 
            for drawing in root.findall(".//w:drawing", namespaces=NS2):   
                cx, cy = _inline_size_emu(drawing)  
                ########### Collect every potential image RID including SVG extension RIDs #############
                rids = _collect_all_image_rids(drawing)  
    
                ########### Header replacement (any image/vector or pure vector group) #############
                if in_header:  
                    looks_like_header = False  
                    if rids:  
                        ########### Check any target is vector or very wide #############
                        any_vector = False  
                        any_wide = False  
                        for rid in rids:  
                            if rid not in rels_map:  
                                continue  
                            ext = Path(rels_map[rid][0]).suffix.lower()  
                            if ext in VECTOR_EXTS:  
                                any_vector = True  
                            ########### width/height check #############
                        ratio = (cx / max(1, cy)) if (cx and cy) else 0  
                        any_wide = ratio >= 3.0  
                        looks_like_header = any_vector or any_wide  
                    else:  
                        ########### Pure vector group (no blip)  ###############
                        looks_like_header = _is_pure_vector_logo(cx, cy)  
    
                    if new_logo_png_bytes and looks_like_header:  
                        if rids:  
                            _update_targets_to(rels_root, rids, "media/rebr_header_logo.png")  
                        _clear_pic_frame_fills(drawing)  
                        _fit_wp_extent_to_png(drawing, HEADER_LOGO_MAX_H_IN)  
                        replaced_header += 1  
                        continue  
    
                ########### Footer removal – detect by multiple signals, then blank ALL rids; ################# 
                if in_footer:  
                    should_blank = False  
                    ################ Signals: small size, vector ext, bytes sniff, docPr/text  ###############
                    name, descr = _docpr_info(drawing)  
                    ctx = " ".join([name, descr, _text_in_shape(drawing)]).lower()  
                    size_hit = _is_footer_logo_by_size(cx, cy)  
                    bytes_hit = any(_media_has_brand(rels_name, rels_map, rid) for rid in rids)  
                    vector_hit = any(Path(rels_map[rid][0]).suffix.lower() in VECTOR_EXTS for rid in rids if rid in rels_map)  
                    text_hit = ("hitachi" in ctx and "energy" in ctx)  
    
                    if rids:  
                        should_blank = size_hit or vector_hit or bytes_hit or text_hit  
                    else:  
                        ########## Pure vector group (no blip) – blank by clearing fills/lines##############  
                        if _is_pure_vector_logo(cx, cy):  
                            _clear_all_vector_shapes(drawing)  
                            pure_vector_cleared += 1  
                            continue  
    
                    if should_blank:  
                        if rids:  
                            _update_targets_to(rels_root, rids, "media/blank.png")  
                        _clear_pic_frame_fills(drawing)  
                        removed_energy += 1  
                        continue  
    
            ############ VML pict fallback pass ############### 
            for vshape in root.findall(".//w:pict//v:shape", namespaces=NS2):  
                txt = _text_in_shape(vshape)  
                imd = vshape.find(".//v:imagedata", namespaces=NS2)  
                rid = imd.get(f"{{{R}}}id") if imd is not None else None  
                if rid and rid in rels_map:  
                    tgt = rels_map[rid][0]  
                    ext = Path(tgt).suffix.lower()  
                    if in_footer:  
                        ########### Size-based on VML style  #############
                        style = vshape.get("style", "") or ""  
                        w_pt = h_pt = 0.0  
                        for part in style.split(";"):  
                            p = part.strip().lower()  
                            if p.startswith("width:") and "pt" in p:  
                                try: w_pt = float(p.split("width:")[1].split("pt")[0])  
                                except: pass  
                            elif p.startswith("height:") and "pt" in p:  
                                try: h_pt = float(p.split("height:")[1].split("pt")[0])  
                                except: pass  
                        h_in = (h_pt or 0) / 72.0  
                        ratio = (w_pt / h_pt) if (w_pt and h_pt) else 0  
                        size_hit = (h_in and h_in <= FOOTER_LOGO_MAX_H_IN and ratio >= FOOTER_LOGO_MIN_RATIO)  
                        bytes_hit = _media_has_brand(rels_name, rels_map, rid)  
                        vector_hit = ext in VECTOR_EXTS  
                        text_hit = ("hitachi" in txt and "energy" in txt)  
                        if size_hit or vector_hit or bytes_hit or text_hit:  
                            _rels_update_target(rels_root, rid, "media/blank.png", type_hint=IMAGE_REL_TYPE)  
                            ######## make invisible ############# 
                            style2 = vshape.get("style", "") or ""  
                            parts = []  
                            for part in style2.split(";"):  
                                pl = part.strip().lower()  
                                if pl.startswith(("fillcolor:", "strokecolor:", "color:")):  
                                    continue  
                                parts.append(part.strip())  
                            vshape.set("style", ";".join(filter(None, parts)))  
                            vshape.set("filled", "f")  
                            vshape.set("stroked", "f")  
                            removed_energy += 1  
                            continue  
                    else:  
                        ############# Header vector -> replace  ############
                        if in_header and new_logo_png_bytes and ext in VECTOR_EXTS:  
                            _rels_update_target(rels_root, rid, "media/rebr_header_logo.png", type_hint=IMAGE_REL_TYPE)  
                            removed_energy += 0  
                            replaced_header += 1  
                            continue  
                else:  
                    ########## VML with no image: clear text if it contains words  ############
                    if "hitachi" in txt and "energy" in txt:  
                        for t in vshape.findall(".//w:txbxContent//w:t", namespaces=NS2):  
                            t.text = ""  
                        vstyle = vshape.get("style", "") or ""  
                        parts = []  
                        for part in vstyle.split(";"):  
                            pl = part.strip().lower()  
                            if pl.startswith(("fillcolor:", "strokecolor:", "color:")):  
                                continue  
                            parts.append(part.strip())  
                        vshape.set("style", ";".join(filter(None, parts)))  
                        vshape.set("filled", "f")  
                        vshape.set("stroked", "f")  
                        text_cleared += 1  
    
            ############## blank any remaining small pictures in footer ################### 
            if in_footer:  
                for drawing in root.findall(".//w:drawing", namespaces=NS2):  
                    rids = _collect_all_image_rids(drawing)  
                    if not rids:  
                        continue  
                    cx, cy = _inline_size_emu(drawing)  
                    if cy and (cy / EMU_PER_IN) <= FOOTER_LOGO_MAX_H_IN * 1.05:  
                        _update_targets_to(rels_root, rids, "media/blank.png")  
                        _clear_pic_frame_fills(drawing)  
                        removed_energy += 1  
    
             
            replacements[part_name] = _serialize_xml(root)  
            replacements[rels_name] = _serialize_xml(rels_root)  
    
        out_bytes = _zip_write(original, replacements, removed)  
    
        if debug_local:  
            print(f"[{pass_name}] brand-fix: removed Energy={removed_energy}, replaced header logos={replaced_header}, text cleared={text_cleared}, pure-vector-cleared={pure_vector_cleared}")  
    
        return out_bytes         
  
     
    docx_path = Path(docx_path)  
    output_path = Path(output_path)  
    with open(docx_path, "rb") as f:  
        orig_bytes = f.read()  
  
    #################### Pre-clean (A/B/C) with tolerant validation, no fallback to original#################### 
    in_for_step1 = orig_bytes  
    try:  
        preA = _docx_preclean_vector_and_glyphs_v3(orig_bytes, delete_unused_media=True, insert_header_logo=True)  
        okA, msgA = _docx_validate(preA, allow_missing_docprops=True)  
        if not okA and debug:  
            print("DOCX validate A warning:", msgA)  
        in_for_step1 = preA if okA else orig_bytes  
  
        if not okA:  
            preB = _docx_preclean_vector_and_glyphs_v3(orig_bytes, delete_unused_media=False, insert_header_logo=True)  
            okB, msgB = _docx_validate(preB, allow_missing_docprops=True)  
            if not okB and debug:  
                print("DOCX validate B warning:", msgB)  
            in_for_step1 = preB if okB else in_for_step1  
  
            if not okB:  
                preC = _docx_preclean_vector_and_glyphs_v3(orig_bytes, delete_unused_media=False, insert_header_logo=False)  
                okC, msgC = _docx_validate(preC, allow_missing_docprops=True)  
                if not okC and debug:  
                    print("DOCX validate C warning:", msgC)  
                if okC:  
                    in_for_step1 = preC  
    except Exception as e:  
        if debug:  
            print("DOCX pre-clean v3 exception:", e)  
        in_for_step1 = orig_bytes  
  
    ##################Load new HITACHI PNG (for replacement) #############  
    new_logo_png_bytes = None  
    try:  
        ######## Look up your configured logo path (adjust key if needed)  ########
        png_key = None  
        try:  
            png_key = REPLACEMENT_LOGOS.get("hitachi_inspire")  
        except Exception:  
            png_key = None  
        candidates = []  
        if png_key:  
            candidates = [  
                Path(png_key),  
                Path.cwd() / png_key,  
                ((Path(__file__).resolve().parent / png_key) if "__file__" in globals() else None),  
                Path("/home/site/wwwroot") / png_key,  
            ]  
        for p in candidates:  
            if p and p.exists():  
                new_logo_png_bytes = p.read_bytes()  
                break  
    except Exception as e:  
        if debug:  
            print("Logo PNG load warning:", e)  
  
    ##################Pre brand-fix (no-delete) BEFORE Step-1 to avoid in-paint patches ##################  
    try:  
        in_for_step1 = _brand_fix_no_delete(in_for_step1, new_logo_png_bytes, debug_local=debug, pass_name="pre")  
    except Exception as e:  
        if debug:  
            print("Pre brand-fix exception:", e)  
  
    ##################Step-1 cover/template pipeline ##################  
    if template_cover:  
        step1_bytes = process_docx_pipeline_inspire_new(in_for_step1, template_cover=True, template_img=template_img)  
    else:  
        shadow_tpl = None  
        try:  
            import cv2   
            if Path("transparent1.png").exists():  
                shadow_tpl = cv2.imread("transparent1.png", cv2.IMREAD_COLOR)  
        except Exception:  
            shadow_tpl = None  
        step1_bytes = process_docx_pipeline_inspire_new(in_for_step1, template_cover=True, template_img=shadow_tpl)  
  
    ##############Step-2 logo pipeline #################
    step2_bytes = process_docx_step2(step1_bytes)  
  
    ##################Typography pass ##################
    final_bytes = process_docx_typography(step2_bytes)  
  
    ##################Post brand-fix (no-delete) AFTER Step-2/typography ##################
    try:  
        final_bytes = _brand_fix_no_delete(final_bytes, new_logo_png_bytes, debug_local=debug, pass_name="post")  
    except Exception as e:  
        if debug:  
            print("Post brand-fix exception:", e)  
  
    ##############Final validation (warning only; do not revert) #################
    ok, msg = _docx_validate(final_bytes, allow_missing_docprops=True)  
    if not ok and debug:  
        print("Final DOCX validate warning:", msg)  
  
    ############Write output #############  
    with open(output_path, "wb") as out:  
        out.write(final_bytes)  
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file1 = Path(OUTPUT_DIR) / f"{Path(docx_path).stem}_{timestamp}_rebranded.docx"
    with open(output_file1, "wb") as out1:  
        out1.write(final_bytes)
    logger.info(f"✅ DOCX written: {output_path}")        
 
 
 
def main_consolidated() -> None:  
     
    print("=" * 80)  
    print("           CONSOLIDATED HITACHI REBRANDING PIPELINE")  
    print("    Step 1: Pattern Detection & Removal")  
    print("    Step 2: Logo Detection, Replacement & Typography")    
    print("=" * 80)  
  
    ensure_dir(OUTPUT_DIR)  
  
    ########## Select template image path based on template_flag ############ 
    ########### • True  -> keep original behaviour (new_cover.png if present) ########## 
    ########### • False -> shadow-mode template (transparent1.png)  ########## 
    template_flag =  False # Set to True when you want to overlay a clean cover (do not alter this path)  
    template_path = Path("new_cover.png") if template_flag else Path("transparent1.png")  
    template_img = cv2.imread(str(template_path), cv2.IMREAD_COLOR) if template_path.exists() else None  
  
    ##### Process all files from Azure Blob or local input directory  #####
    if USE_AZURE_BLOB:  
        tmp_in = Path(tempfile.mkdtemp(prefix="az_in_"))  
        local_inputs = _download_inputs_from_blob(tmp_in)  
        pdf_files = [p for p in local_inputs if p.suffix.lower() == ".pdf"]  
        docx_files = [p for p in local_inputs if p.suffix.lower() == ".docx"]  
    else:  
        inp = Path(INPUT_DIR)  
        if not inp.exists():  
            print(f"✘ Input directory not found: {INPUT_DIR}")  
            return  
        pdf_files = list(inp.glob("*.pdf"))  
        docx_files = list(inp.glob("*.docx"))  
  
    if not (pdf_files or docx_files):  
        print("✘ No PDF / DOCX files to process")  
        return  
  
    print(f"Found  {len(pdf_files)}  PDF   +   {len(docx_files)}  DOCX")  
    print()  
  
    ###### Process PDF files  ######
    for pdf_file in pdf_files:  
        output_file = Path(OUTPUT_DIR) / f"{pdf_file.stem}_rebranded.pdf"  
        try:  
            print(f"Started processing pdf file: {pdf_file.name}")  
            process_pdf_consolidated(  
                pdf_file,  
                output_file,  
                template_cover=template_flag,    
                template_img=template_img,      
                debug=DEBUG,  
            )  
            print(f"✓ Finished processing pdf file: {pdf_file.name}")  
        except Exception as e:  
            print(f"✘ Error processing {pdf_file.name}: {e}")  
            if DEBUG:  
                import traceback  
                traceback.print_exc()  
  
    ########## Process DOCX files  ###############
    for docx_file in docx_files:  
        output_file = Path(OUTPUT_DIR) / f"{docx_file.stem}_rebranded.docx"  
        try:  
            print(f"Started processing docx file: {docx_file.name}")  
            process_docx_consolidated(  
                docx_file,  
                output_file,  
                template_cover=template_flag,    
                template_img=template_img,      
                debug=DEBUG,  
            )  
            print(f"✓ Finished processing docx file: {docx_file.name}")  
        except Exception as e:  
            print(f"✘ Error processing {docx_file.name}: {e}")  
            if DEBUG:  
                import traceback  
                traceback.print_exc()  
  
      
    if USE_AZURE_BLOB:  
        for prod in Path(OUTPUT_DIR).glob("*_rebranded.*"):  
            _upload_to_blob(prod)  
            if not KEEP_LOCAL_COPY:  
                prod.unlink()  
  
    print()  
    print("=" * 80)  
    print("✓ FIXED PIPELINE COMPLETED!")  
    print(f"  • When template_flag=False: transparent cover + black Inspire + black cover text applied")  
    print(f"  • Cover page logo: {'ENABLED' if ADD_COVER_LOGO_DOCX else 'DISABLED'}")  
    if USE_AZURE_BLOB:  
        print(f"  Results uploaded to Azure container  “{AZURE_CONTAINER_OUTPUT}”.")  
    else:  
        print(f"  Results written to local folder  {OUTPUT_DIR}")  
    print("=" * 80)   
  
 
if __name__ == "__main__":  
    USE_AZURE_BLOB = False  
    KEEP_LOCAL_COPY = True  
    main_consolidated()  