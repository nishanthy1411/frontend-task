
  
from __future__ import annotations  
  
import io  
import shutil  
import tempfile  
from typing import List  
import numpy as np 
from pathlib import Path
  
import cv2  
from fastapi import FastAPI, File, UploadFile, HTTPException  
from fastapi.responses import FileResponse  
  

from hitachi_rebranding_final_improved_V10 import (             
    process_pdf_consolidated,  
    process_docx_consolidated,  
)  
# from hitachi_rebranding_final_V1 import (             
#     process_pdf_consolidated1,  
#     process_docx_consolidated1,  
# )
from fastapi.middleware.cors import CORSMiddleware
  
app = FastAPI(title="Hitachi Rebranding Pipeline API")  

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,  # Allows cookies and authorization headers
    allow_methods=["*"],     # Allows all HTTP methods (GET, POST, PUT, etc.)
    allow_headers=["*"],     # Allows all headers
)
  
############# utility helpers ############ 
def _save_uploaded_files(  
    uploads: List[UploadFile], workdir: tempfile.TemporaryDirectory  
) -> List[str]:  
    saved: List[str] = []  
    print("workdir:", workdir)
    for upl in uploads:  
        if upl.filename is None:  
            continue  
        data = upl.file.read()  
        if not data:  
            continue  
        dst = f"{Path(workdir)}/{upl.filename}"  
        print("saving to:", dst)
        with open(dst, "wb") as fh:  
            fh.write(data)  
        saved.append(dst)  
    return saved  
  
  
def _zip_folder(src_dir: str, zip_path: str) -> str:  
    print("src_dir: ", src_dir, " zip_path: ", zip_path)
    shutil.make_archive(base_name=zip_path, format="zip", root_dir=src_dir, base_dir=src_dir)  
    return f"{zip_path}.zip"  
  
  
############# ENDPOINTS ############ 
@app.post("/process/transparent", response_class=FileResponse)  
def process_transparent(files: List[UploadFile] = File(...)):   
    if not files:  
        raise HTTPException(status_code=400, detail="No files uploaded")  
  
    with tempfile.TemporaryDirectory(prefix="rebrand_") as tmp_in, tempfile.TemporaryDirectory(prefix="rebrand_out_") as tmp_out:  
  
        # 1. save uploads  
        local_inputs = _save_uploaded_files(files, tmp_in)  
  
        # 2. run pipeline (template_cover=False  → “transparent mode”)  
        for f in local_inputs:  
            try:  
                if f.lower().endswith(".pdf"):  
                    process_pdf_consolidated(  
                        pdf_path=f,  
                        output_path=f"{tmp_out}/{shutil.os.path.splitext(shutil.os.path.basename(f))[0]}_rebranded.pdf",  
                        template_cover=False,  
                        template_img=None,  
                        debug=False,      # reduce noise for REST API  
                    )  
                elif f.lower().endswith(".docx"):  
                    process_docx_consolidated(  
                        docx_path=f,  
                        output_path=f"{tmp_out}/{shutil.os.path.splitext(shutil.os.path.basename(f))[0]}_rebranded.docx",  
                        template_cover=False,  
                        template_img=None,  
                        debug=False,  
                    )  
            except Exception as exc:  
                raise HTTPException(status_code=500, detail=str(exc))  
  
        # 3. return ZIP  
        zip_file = _zip_folder(tmp_out, f"{Path(tmp_out).parent}/rebranded_results")  
        return FileResponse(  
            zip_file,  
            media_type="application/zip",  
            filename=f"{Path(tmp_out).parent}/rebranded_results.zip",  
        )  
  
  
@app.post("/process/template", response_class=FileResponse)  
def process_with_template(  
    files: List[UploadFile] = File(...),  
    template_image: UploadFile = File(...),  
):   
    if not files:  
        raise HTTPException(status_code=400, detail="No files uploaded")  
  
    # read template image once  
    tpl_bytes = template_image.file.read()  
    tpl_arr = cv2.imdecode(  
        np.frombuffer(tpl_bytes, dtype="uint8"), cv2.IMREAD_COLOR  
    )  
    if tpl_arr is None:  
        raise HTTPException(status_code=400, detail="Template image invalid")  
  
    with tempfile.TemporaryDirectory(prefix="rebrand_") as tmp_in, tempfile.TemporaryDirectory(prefix="rebrand_out_") as tmp_out:  
  
        local_inputs = _save_uploaded_files(files, tmp_in)  
  
        for f in local_inputs:  
            try:  
                if f.lower().endswith(".pdf"):  
                    process_pdf_consolidated(  
                        pdf_path=f,  
                        output_path=f"{tmp_out}/{shutil.os.path.splitext(shutil.os.path.basename(f))[0]}_rebranded.pdf",  
                        template_cover=True,  
                        template_img=tpl_arr,  
                        debug=False,  
                    )  
                elif f.lower().endswith(".docx"):  
                    process_docx_consolidated(  
                        docx_path=f,  
                        output_path=f"{tmp_out}/{shutil.os.path.splitext(shutil.os.path.basename(f))[0]}_rebranded.docx",  
                        template_cover=True,  
                        template_img=tpl_arr,  
                        debug=False,  
                    )  
            except Exception as exc:  
                raise HTTPException(status_code=500, detail=str(exc))  
  
        zip_file = _zip_folder(tmp_out, f"{Path(tmp_out).parent}/rebranded_results")  
        return FileResponse(  
            zip_file,  
            media_type="application/zip",  
            filename=f"{Path(tmp_out).parent}/rebranded_results.zip",  
        )  

   
# @app.post("/process/template", response_class=FileResponse)  
# def process_with_template(  
#     files: List[UploadFile] = File(...),  
#     template_image: UploadFile | None = File(  
#         None,  
#         description=(  
#             "Cover-template image (PNG / JPG). "  
#             "If omitted the API will immediately respond with 400 so that "  
#             "the frontend can prompt the user to pick a file."  
#         ),  
#     ),  
# ):    
#     if not files:  
#         raise HTTPException(status_code=400, detail="No PDF / DOCX files uploaded")  
  
#     # prompt user to choose a template image when they picked the template mode  
#     if template_image is None:  
#         raise HTTPException(  
#             status_code=400,  
#             detail="Template cover page image missing - please upload a file.",  
#         )  
  
#     tpl_bytes = template_image.file.read()  
#     tpl_arr = cv2.imdecode(np.frombuffer(tpl_bytes, dtype="uint8"), cv2.IMREAD_COLOR)  
#     if tpl_arr is None:  
#         raise HTTPException(status_code=400, detail="Template image is not a valid picture")  
  
#     with tempfile.TemporaryDirectory(prefix="rebrand_") as tmp_in, tempfile.TemporaryDirectory(prefix="rebrand_out_") as tmp_out:  
#         local_inputs = _save_uploaded_files(files, tmp_in)  
  
#         for f in local_inputs:  
#             try:  
#                 if f.lower().endswith(".pdf"):  
#                     process_pdf_consolidated(  
#                         pdf_path=f,  
#                         output_path=f"{tmp_out}/{shutil.os.path.splitext(shutil.os.path.basename(f))[0]}_rebranded.pdf",  
#                         template_cover=True,  
#                         template_img=tpl_arr,  
#                         debug=False,  
#                     )  
#                 elif f.lower().endswith(".docx"):  
#                     process_docx_consolidated(  
#                         docx_path=f,  
#                         output_path=f"{tmp_out}/{shutil.os.path.splitext(shutil.os.path.basename(f))[0]}_rebranded.docx",  
#                         template_cover=True,  
#                         template_img=tpl_arr,  
#                         debug=False,  
#                     )  
#             except Exception as exc:  
#                 raise HTTPException(status_code=500, detail=str(exc))  
  
#         zip_file = _zip_folder(tmp_out, f"{tmp_out}/rebranded_results")  
#         return FileResponse(  
#             zip_file,  
#             media_type="application/zip",  
#             filename="rebranded_results.zip",  
#         )    
  
@app.get("/health")  
def health_check():   
    return {"status": "ok"}  